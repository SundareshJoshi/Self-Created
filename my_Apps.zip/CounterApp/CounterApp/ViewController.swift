//
//  ViewController.swift
//  CounterApp
//
//  Created by Joshi on 10/11/14.
//  Copyright (c) 2014 Joshi. All rights reserved.
//

import UIKit

class ViewController: UIViewController{

    var timer = NSTimer()
    var counter = 0
    var running = false
    var curSpeed = 1.0
    override func viewDidLoad() {
        //running = true
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        theCounterlabel.text = String(counter)
        self.pause.enabled = false
        slider.value = Float (self.curSpeed)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }
    
    @IBOutlet weak var slider: UISlider!
    
    @IBOutlet weak var theCounterlabel: UILabel!
    
    @IBOutlet weak var label: UILabel!
    
    @IBAction func PlayPressed(sender: AnyObject) {
        
        self.pause.enabled = true
        self.play.enabled = false
//        if running == true {
//            let msg : UIAlertView = UIAlertView(title: "Excuse Me!!", message: "It is already running!😡", delegate: self, cancelButtonTitle: "Ok")
//            msg.show()
//        }
//        else {
            self.slider.enabled = false
        running = true
       // timer = NSTimer.scheduledTimerWithTimeInterval(curSpeed, target: self, selector: Selector ("update"), userInfo: nil, repeats: true)
        self.timer = NSTimer.scheduledTimerWithTimeInterval(self.curSpeed, target: self, selector: Selector ("update"), userInfo: nil, repeats: true)
//}
    }
    func update() {
        theCounterlabel.text = String(++counter)
        theCounterlabel.textColor = self.getRandomColor()
    }
    
    func getRandomColor() -> UIColor {
        var color: UIColor!
        var randomRed = CGFloat(drand48())
        var randomGreen = CGFloat(drand48())
        var randomBlue = CGFloat(drand48())
        color = UIColor(red: randomRed, green: randomGreen, blue: randomBlue, alpha: 1.0)
        return color
    }
    

   
    @IBOutlet weak var pause: UIBarButtonItem!
    @IBOutlet weak var play: UIBarButtonItem!
    @IBAction func PausePressed(sender: AnyObject) {
        self.play.enabled = true
        self.pause.enabled = false
        timer.invalidate()
        running = false
        theCounterlabel.textColor = UIColor.redColor()
        self.slider.enabled = true
    }
    
    @IBAction func ClearPressed(sender: AnyObject) {
        timer.invalidate()
        running = false
        counter = 0
        theCounterlabel.text = String(counter)
        //theCounterlabel.textColor = UIColor.blackColor()
        self.play.enabled = true
        self.pause.enabled = false
        self.slider.enabled = true
    }
    
    @IBAction func sliderValChanged(sender: AnyObject) {
        var i = slider.value
        self.label.text = (NSString(format: "%.0f", i) as String) + "X"
        if slider.value < 1.0 {
            self.curSpeed = 2
        }
        else if slider.value < 2.0 {
            self.curSpeed = 0.5
        }
        else if slider.value < 3.0 {
            self.curSpeed = 0.25
        }
        else if slider.value < 4.0 {
            self.curSpeed = 0.15
        }
        else {
            self.curSpeed = 0.05
        }
        
        speed()
    }
    
    func speed() -> Double {
        return self.curSpeed
    }
    
}

