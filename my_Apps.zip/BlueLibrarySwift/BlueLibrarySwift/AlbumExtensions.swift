//
//  AlbumExtensions.swift
//  BlueLibrarySwift
//
//  Created by Sundaresh Joshi on 8/21/15.
//  Copyright (c) 2015 Raywenderlich. All rights reserved.
//

import Foundation

extension Album {
    func ae_tableRepresentation() -> (titles:[String], values:[String]) {
        return (["Artist", "Album", "Genre", "Year"], [artist, title, genre, year])
    }
}