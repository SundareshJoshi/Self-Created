//
//  DischargeCheckListViewController.swift
//  HospitalPatient
//
//  Created by kamruddin on 5/20/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit
import MFNetworking
import HealthCareData

//This class is used to display the discharge checklist
class DischargeCheckListViewController: UIViewController, FooterViewDelegate, CareTeamInfoDelegate
{
    //MARK: - Variables
    var patientDetail: Patient2?
    
    //MARK: - Private Variables
    private var checkListArray:[DischargeCheckListModal] = []
    private var isFooterViewVisible = false
    private var mytimer : NSTimer = NSTimer()
    
    //MARK: - IBOutlets
    @IBOutlet weak var footerView: UIView!
    @IBOutlet weak var navigationBarItem: UINavigationItem!
    @IBOutlet weak var dischargeCheckListManager: DischargeCheckListManager!
    @IBOutlet weak var dischargeTableView: UITableView!
    @IBOutlet weak var footerViewConstraint: NSLayoutConstraint!
    @IBOutlet weak var offlineView: OfflineView!
    @IBOutlet weak var offlineViewHeightConstraint: NSLayoutConstraint!
    
    
    //MARK: - View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        resetTableViewFrame(false)
        self.dischargeCheckListService()
        
        dischargeCheckListManager.delegate = self
        self.offlineViewHeightConstraint.constant = 0
        offlineView.hidden = true
        self.footerView.hidden = true
        self.dischargeTableView.tableFooterView = UIView(frame: CGRectZero)
        self.automaticallyAdjustsScrollViewInsets = false
        
        //To check whether the internet connection is there or not
        if networkReachability.isReachable() {
            self.offlineViewHeightConstraint.constant = 0
        }
        else {
            self.animateOfflineView()
        }
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "notifyNetworkChange:", name: KEY_NETWORK_CHANGE, object: nil)
        
        //Custom NaviagtionBar Title
        var attributes = [
            NSForegroundColorAttributeName: UIColor.NAVIGATION_TITLE_COLOR(),
            NSFontAttributeName: (UIFont.CUSTOM_FONT(HELVETICA_MEDIUM, customFontSize: FONT_SIZE_17))]
        self.navigationController?.navigationBar.titleTextAttributes = attributes
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        self.dischargeTableView.editing = false
    }
    
    //MARK: - Private Methods
    private func dischargeCheckListService() {
        Request.DischargeCheckList().execute().validate().responseJSON{ (_, _, json, error) -> Void in
            if let error = error {
                self.checkListFailedWithError(error)
            } else {
                
                self.checkListArray = Response.dataForDischargeCheckList(json)
                self.dischargeCheckListManager.setDischargeCheckList(self.checkListArray)
                
                //Reload UI
                self.dischargeTableView.reloadData()
            }
        }
    }
    
    private func checkListFailedWithError(error: NSError) {
        // create the error message
        var message = error.code == 401 ? MESSAGE_WRONG : MESSAGE_NETWORKERROR
        self.presentViewController(AlertUtils.showErrorWith(message: message), animated: true, completion: nil)
    }
    
    //MARK: - reseting the tableView frame based on footer view visibility
    private func resetTableViewFrame(isFooterVisible: Bool) {
        
        self.footerViewConstraint.constant = isFooterVisible == false ? 0.0 : 52.0
    }
    
    //MARK:- Action
    @IBAction func addTask(sender: UIBarButtonItem) {
        self.showMessage()
    }
    
    //MARK: FooterViewDelegate
    func handleSelectedRow(isFooterVisible: Bool) {
        
        self.footerView.hidden = !isFooterVisible
        self.resetTableViewFrame(isFooterVisible)
    }
    
    //MARK: Care TeamInfoDelegate
    func careTeamInfo() {
        self.showMessage()
    }
    
    //MARK: Alert message
    func showMessage() {
        if networkReachability.isReachable() {
            var alert = AlertUtils.showErrorWith(message: MESSAGE_NOFUNCTIONALITY)
            self.presentViewController(alert, animated: false, completion: nil)
        }
        else {
            var alert = AlertUtils.showErrorWithoutTitle(message: MESSAGE_NOINTERNETCONNECTION)
            self.presentViewController(alert, animated: false, completion: nil)
        }
    }
    
    //MARK:- Notification method
    /**
    Reachability - Check the network connection
    
    :param: Notification - Notification object for which notification called
    */
    func notifyNetworkChange(Notification: NSNotification) {
        let reachability = Notification.object as! Reachability
        if reachability.isReachable() {
            self.removeOfflineView()
        }
        else {
            self.animateOfflineView()
        }
    }
    
    //MARK:- Show or hide offline view
    /**
    Show the offline view with animation in the controller while user is in offline
    */
    func animateOfflineView() {
        offlineView.hidden = false
        if self.offlineViewHeightConstraint.constant != 30 {
            mytimer = NSTimer .scheduledTimerWithTimeInterval(0.1, target: self, selector: "restart", userInfo: nil, repeats: false)
        }
    }
    /**
    Remove the offline view with animation from the controller
    */
    func removeOfflineView() {
        if self.offlineViewHeightConstraint.constant != 0 {
            mytimer = NSTimer .scheduledTimerWithTimeInterval(0.1, target: self, selector: "restartTimer", userInfo: nil, repeats: false)
        }
        else {
            self.offlineView.hidden = true
        }
    }
    
    //MARK:- Timer methods
    
    /**
    Restart the timer while showing offline view
    */
    func restart() {
        UIView.animateWithDuration(0.1, delay: 0.0, options: UIViewAnimationOptions.CurveEaseIn , animations: {  self.offlineViewHeightConstraint.constant += 5}, completion:  {(finished: Bool) in self.animateOfflineView() })
    }
    /**
    Restart the timer while hidding offline view
    */
    func restartTimer() {
        UIView.animateWithDuration(0.1, delay: 0.0, options: UIViewAnimationOptions.CurveEaseIn , animations: {  self.offlineViewHeightConstraint.constant -= 5}, completion:  {(finished: Bool) in self.removeOfflineView() })
    }
}
