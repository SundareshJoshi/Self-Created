//
//  Contract.swift
//  HospitalPatient
//
//  Created by Mike Wang on 2015-05-18.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import HealthCareData

@objc protocol ModelService {
    
    var patient: Patient2? {get set}
    var patients: [Patient2]? {get set}
    var informationBooklets: [InformationBooklet2]? {get set}
    var appoitments: [Appoitment2]? {get}
    var staffMembers: [String:StaffMember2]? {get set}

}

@objc class PatientModel: ModelService {
    var patient: Patient2?
    var patients: [Patient2]?

    var informationBooklets: [InformationBooklet2]?
    
    var appoitments: [Appoitment2]? {
        get {
            var aptms = [Appoitment2]()
            if patient != nil {
                for appoitment in patient!.recoveryPath.appoitments {
                    aptms.append(appoitment as! Appoitment2)
                }
            }
            return aptms
        }
    }
    
    var staffMembers: [String:StaffMember2]?
}

//MARK:- Extention for StaffMember2
extension StaffMember2: Printable {
    public override var description:String {
        get {
            var text = "\(self.staffId)\n"
            text += "\(self.firstName) \(self.lastName)\n"
            text += "role: \(self.role)\n"
            return text
        }
    }
}

//MARK:- Extention for Appoitment2
extension Appoitment2: Printable {
    public override var description:String {
        get {
            var text = "Date Time: \(self.dateTime)\n"
            text += "Short Description: \(self.shortDesc)\n"
            text += "Long Description: \(self.longDesc)\n"
            text += "Location: \(self.location)\n"
            return text
        }
    }
}
//MARK:- Extention for InformationBooklet2
extension InformationBooklet2: Printable {
    
    var categories:NSOrderedSet? {
        get {
            var categories = NSMutableOrderedSet()
            
            for section in self.sections {
                categories.addObject(section.category)
            }
            return categories
        }
    }
    
    public override var description:String {
        get {
            var info:String = ""
            if self.categories != nil {
                for category in self.categories! {
                    info += category as! String + "\n"
                }
            }
            
            return info
        }
    }
}
//MARK:- Extention for Patient2
extension Patient2 {

    var patientFullName:String? {
        get {
            return self.firstName + " " + self.lastName
        }
    }
}



