//
//  StringUtils.swift
//  HospitalPatient
//
//  Created by Das on 19/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import Foundation
import UIKit

//Added some string class functions
extension String{
    
    /**
    To get the size of the string object
    
    :param: text :  The string for which the size calculated
    :param: maxWidth : Maximum width of the string in which it needs to show
    :param: textFont : Font of the string

    :returns: Size of the string(both width and height)
    */

    static func getSizeOftext(#text: String, maxWidth:CGFloat, textFont:UIFont ) -> CGSize {
        // Get the height of the font
        let attributes = [NSFontAttributeName :textFont]
        
        let rect = text.boundingRectWithSize(CGSizeMake(maxWidth, CGFloat.max), options: NSStringDrawingOptions.UsesLineFragmentOrigin, attributes: attributes, context: nil)
        return rect.size
    }

}