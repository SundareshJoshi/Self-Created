//
//  ApplicationData.swift
//  HospitalMD
//
//  Created by Saurav on 18/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class ApplicationData {
    
    struct Static {
        static let DOCUMENT_NAME = "Database.sqlite"
        static let NOTIFICATION_SYNC_COMPLETE = "ApplicationData.syncComplete"
    }
    
    var document: UIManagedDocument!
    
    init(completionHandler callback: ((String?) -> Void)) {
        DocumentHelper.document(Static.DOCUMENT_NAME){
            (document, error) -> Void in
            if let d = document {
                //MFLog("Document: \(d.fileURL)")
                self.document = d
                callback(nil)
            }
            else{
                callback(error)
            }
        }
    }
}