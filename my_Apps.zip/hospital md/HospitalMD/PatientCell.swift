//
//  PatientCell.swift
//  HospitalMD
//
//  Created by Raja Pratap Singh on 27/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit

//Custom cell for designing patent search screen
class PatientCell: UITableViewCell {
    
    //MARK: - IBOutlet
    @IBOutlet weak var patientNumberCircularLabel: UILabel!
    @IBOutlet weak var patientNameLabel: UILabel!
    @IBOutlet weak var patientCondition: UILabel!
    
    //MARK: - Configure Cell
    func configurePatientCellWithPatientNameAndNumber(name: String, patientId: String, patientCondition: String, searchText: String) {
        
        self.backgroundColor = UIColor.colorForEmptySearchScreen()
        
        self.patientNumberCircularLabel.text = patientId
        self.patientNumberCircularLabel.textColor = UIColor.whiteColor()
        self.patientNumberCircularLabel.backgroundColor = UIColor.colorForPatientCollectionBackground()
        self.patientNumberCircularLabel.font = UIFont.HELVETICA_NEUE_BOLD_15()
        self.patientNumberCircularLabel.textAlignment = .Center
        self.patientNumberCircularLabel.layer.cornerRadius = self.patientNumberCircularLabel.frame.size.width / 2
        self.patientNumberCircularLabel.layer.masksToBounds = true
        
        self.patientCondition.text = patientCondition
        self.patientCondition.font = UIFont.HELVETICANEUE_REGULAR(16)
        self.patientCondition.textColor = UIColor.colorForpatientConditionInSearchResultCell()
        
        self.patientNameLabel.font = UIFont.HELVETICANEUE_REGULAR(14)
        self.patientNameLabel.textColor = UIColor.colorForPatientNameInSearchResultCell()
        
        let attributedString = NSMutableAttributedString(string: name)
        let textRange = name.startIndex..<name.endIndex
        name.enumerateSubstringsInRange(textRange, options: NSStringEnumerationOptions.ByWords, { (substring, substringRange, enclosingRange, stop) -> () in
            let start = distance(name.startIndex, substringRange.startIndex)
            let length = distance(substringRange.startIndex, substringRange.endIndex)
            let range = NSMakeRange(start, length)
            
            if (substring.lowercaseString == searchText.lowercaseString ) {
                attributedString.addAttribute(NSFontAttributeName, value: UIFont.HELVETICA_NEUE_MEDIUM_14(), range: range)
                self.patientNameLabel.attributedText = attributedString
            }
        })
    }
}
