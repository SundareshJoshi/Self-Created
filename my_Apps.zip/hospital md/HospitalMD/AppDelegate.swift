//
//  AppDelegate.swift
//  StarterApp
//
//  Created by Jeremy Koch on 1/21/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit
import MFNetworking
import HealthCareData

//@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    // MARK: - variables
    var window: UIWindow?
    var authenticationController: AuthenticationController {
         return window?.rootViewController as! AuthenticationController
    }

    // MARK: - Appdelegate default methods
    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        // setup the root
        if let window = self.window {
            window.rootViewController = AuthenticationController()
            window.makeKeyAndVisible()
            
            //print app & framework versions
            displayVersions()
            
            // set the global tint
            window.tintColor = StyleKit.defaultTint
            
            // run on first application launch
            AppSettings.sharedInstance.runHandlerOnFirstLaunch() {
                
                // handle anything you want to happen on first ever application launch
            }
        }
        self.setNavigationBarProperty()
        registerService(PatientModel())
        registerService(DownloaderService())
        
        return true
    }
    
    func applicationWillResignActive(application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(application: UIApplication) {
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(application: UIApplication) {
        // setup data source manager
        DataSourceManager.setup()
        
        // update the root authentication controller
        (window?.rootViewController as? AuthenticationController)?.update()
    }

    func applicationWillTerminate(application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    // MARK: - Private methods

    /**
    To display the app version and framework version for testing
    */
    private func displayVersions() {
        NSBundle.printAppVersionBuild()
        NSBundle.printAllEmbeddedFrameworksVersion()
    }

    /**
    To set the the application theme
    */
    private func setNavigationBarProperty()
    {
        var navigationBarAppearace = UINavigationBar.appearance()
        //Change the navigation bar background
        navigationBarAppearace.barTintColor = UIColor.NAVIGATION_BAR_COLOR()
        navigationBarAppearace.tintColor = UIColor.NAVIGATION_TITLE_COLOR()
        
        //Change statusBar title color to white
        UIApplication.sharedApplication().statusBarStyle = UIStatusBarStyle.LightContent
        //Change navigation item title color
        navigationBarAppearace.titleTextAttributes=[NSForegroundColorAttributeName:UIColor.NAVIGATION_TITLE_COLOR()]
        
        UIBarButtonItem.appearance().setTitleTextAttributes([NSForegroundColorAttributeName: UIColor.NAVIGATION_TITLE_COLOR()], forState: UIControlState.Normal)
    }
}

