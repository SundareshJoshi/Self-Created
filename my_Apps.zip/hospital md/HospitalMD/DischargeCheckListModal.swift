//
//  DischargeCheckListModal.swift
//  HospitalPatient
//
//  Created by kamruddin on 5/20/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit
import MFNetworking

//DischargeCheckListModal used for DataModal for Discharge CheckList
class DischargeCheckListModal: NSObject {
    
    //MARK: - Variables
    var taskName = ""
    var isSelected = false
   
    //MARK: - Initialize modal data 
    init(json: JSON) {
        self.taskName = json[KEY_TASKNAME].stringValue
    }
}
