//
//  Service.swift
//  HospitalPatient
//
//  Created by Mike Wang on 2015-05-18.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import Foundation

// Global service look up function
// type is the protocol type to lookup
func lookupService<T>(type: T.Type)-> T? {
    //println("protocol: \(type.dynamicType)")
    for e in _globalSerivces {
        if e is T {
            return e as? T
        }
    }
    return nil
}


// Register a service for global use
func registerService(service:AnyObject) {
    _globalSerivces.append(service)
}

func clearServices() {
    _globalSerivces.removeAll(keepCapacity: true)
}
