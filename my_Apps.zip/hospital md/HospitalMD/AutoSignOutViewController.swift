//
//  AutoSignOutViewController.swift
//  HospitalMD
//
//  Created by Sundaresh Joshi on 5/20/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit

//This class is used to display AutoSignout View
class AutoSignOutViewController: UIViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var signIn: UIButton!
    @IBOutlet weak var timeOutMessage: UILabel!
    
    // MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setOutletProperties()
    }
    
    // MARK: - IBAction
    @IBAction func signInClicked(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil)
        if let controller = self.authenticationController {
            controller.signOut()
        }
    }
    
    // MARK: - Private func
    private func setOutletProperties() {
        
        UIApplication.sharedApplication().setStatusBarStyle(UIStatusBarStyle.LightContent, animated: true)
        // setting the border of the button
        signIn.layer.borderWidth = 2.0
        signIn.layer.cornerRadius = 5.0
        signIn.layer.borderColor = UIColor(red: 57.0/255.0, green: 99.0/255.0, blue: 136.0/255.0, alpha: 1.0).CGColor
        
        // setting the timeOut label text
        self.timeOutMessage.text = MESSAGE_SESSIONTIMEOUT
    }
}