//
//  RESTAPI.swift
//  ShiftHandover
//
//  Created by David Huo on 2015-04-01.
//  Copyright (c) 2015 IBM. All rights reserved.
//


import MFNetworking

typealias RestCompletionHandler =  (urlRequest: NSURLRequest?, urlResponse: NSURLResponse?, data: String?, error: NSError?) -> Void
typealias DownloadCompletionHandler = (error:NSError?)->Void
typealias JSONDownloadCompletionHandler = (json: NSDictionary?, error: NSError?)->Void
typealias UpdateCompletionHandler = (data:String?, error:NSError?)->Void
typealias ArrayDownloadCompletionHandler = (array: NSArray?, error: NSError?)->Void


@objc protocol RestApi {
    
/***** Sample protocol **********/
//    func getCrews(handler: DownloadCompletionHandler)
//    func getPositions(handler: DownloadCompletionHandler)
//    func getCategories(handler: DownloadCompletionHandler)
//    func getIncompleteReasons(handler: DownloadCompletionHandler)
//    func getShift(handler: DownloadCompletionHandler)
//    func getPreviousShift(handler: DownloadCompletionHandler)
//    func getMachines(handler: DownloadCompletionHandler)
//    func getGoals(handler: DownloadCompletionHandler)
//    func startShift(handler: DownloadCompletionHandler)
//    func endShift(handler: DownloadCompletionHandler)
//    func getTeam(handler: DownloadCompletionHandler)
//    func putTeam(handler: DownloadCompletionHandler)
//    func getShiftLog(handler: ArrayDownloadCompletionHandler)
//    func getShiftWithID(shiftId: String, handler: JSONDownloadCompletionHandler)
//    func putCard(cardId:Card, handler: UpdateCompletionHandler)
}

enum RestRequest: DataSourceRequest {
    typealias url = String
    typealias body = String
    case GET(url)
    case POST(url, body?)
    case PUT(url, body?)
    
    func urlSuffix(url: String) -> String {
        let separator = "/"
        if url.hasPrefix(separator) {
            return url
        }
        return separator + url
    }
    
    func responseForURLRequest(urlRequest: NSURLRequest) -> MFNetworking.Response {
    switch self {
        case .GET(let url):
            MFLog("file url = \(url.queryToFile)")
            return MFNetworking.Response().withBodyFromResource(url.queryToFile, type: "json")
        case .POST(let url, let body):
            MFLog("LOCAL POST\n \(body)")
            return MFNetworking.Response().withBodyFromResource(url.queryToFile, type: "json")
        case .PUT(let url, let body):
            MFLog("LOCAL PUT\n \(body)")
            return MFNetworking.Response().withBodyFromResource(url.queryToFile, type: "json")
        }
    }
    
    func urlRequestWithBaseURLString(baseURLString: String?) -> NSURLRequest {
        switch self {
        case .GET(let url):
            return NSURLRequest(URL: NSURL(string: (baseURLString ?? "") + urlSuffix(url))!)
        case .POST(let url, let body):
            let urlRequest = NSMutableURLRequest(URL: NSURL(string: (baseURLString ?? "") + urlSuffix(url))!)
            urlRequest.HTTPMethod = "POST"
            urlRequest.HTTPBody = body?.data
            return urlRequest
        case .PUT(let url, let body):
            let urlRequest = NSMutableURLRequest(URL: NSURL(string: (baseURLString ?? "") + urlSuffix(url))!)
            urlRequest.HTTPMethod = "PUT"
            urlRequest.HTTPBody = body?.data
            return urlRequest
        }
    }

}


class RestApiUtil {
    
    class func GET(url:String, handler: RestCompletionHandler) {
        MFLog("GET \(url)")
        DataSourceManager.request(RestRequest.GET(url)).validate().responseString(handler)
    }
    
    class func POST(url:String, body:NSDictionary?, handler: RestCompletionHandler) {
        MFLog("POST \(url)")
        DataSourceManager.addHeaderWithName("Content-Type", value: "application/json")
        if let bodyJSONText = body?.jsonString() {
            DataSourceManager.request(RestRequest.POST(url, bodyJSONText)).validate().responseString(handler)
        }
    }
    
    class func PUT(url:String, body:NSDictionary?, handler: RestCompletionHandler) {
        MFLog("PUT \(url)")
        DataSourceManager.addHeaderWithName("Content-Type", value: "application/json")
        if let bodyJSONText = body?.jsonString() {
            DataSourceManager.request(RestRequest.PUT(url, bodyJSONText)).validate().responseString(handler)
        }
    }
}

