//
//  TitleViewCell.swift
//  HospitalMD
//
//  Created by Das on 20/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit

//This TableViewCell class is used to alllow user to enter note, once user presses on return or dismiss the keyboard note will be appended into existing Notes TableView along with date and a text 'Me' which signifies it was entered by current user
class TitleViewCell: UITableViewCell {

    @IBOutlet weak var titleViewTextField: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
