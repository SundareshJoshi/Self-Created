//
//  DataSourceManager+AppSpecific.swift
//  StarterApp
//
//  Created by Jeremy Koch on 1/24/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import Foundation
import MFNetworking

extension DataSourceManager {
    class func setup() {
        // setup default headers
        let deviceModel = UIDevice.currentDevice().model
        let appVersion = NSBundle.mainBundle().infoDictionary?["CFBundleShortVersionString"] as? String ?? ""
        DataSourceManager.addHeaderWithName("Device-Model", value:deviceModel)
        DataSourceManager.addHeaderWithName("App-Version", value:appVersion)
        DataSourceManager.addHeaderWithName("Accept-Language", value:"en-US")
        
        // configure the remote hosts
        if let hosts = NSBundle.mainBundle().infoDictionary?["DataSourceHosts"] as? [String: String] {
            var environments: [String: String] = [:]
            for (hostKey, urlString) in hosts {
                if AppSettings.sharedInstance.remoteName == hostKey {
                    DataSourceManager.baseURLString = urlString
                }
            }
        }
        
        // set the current environment
        DataSourceManager.localMode = AppSettings.sharedInstance.localMode
        
        // set the adhoc request matcher
        DataSourceManager.responseForURLMatcher = RequestMatcher()
    }
    
    class func pathForServiceName(name: String) -> String {
        if let paths = NSBundle.mainBundle().infoDictionary?["DataSourcePaths"] as? [String: String] {
            return paths[name] ?? ""
        }
        return ""
    }
}