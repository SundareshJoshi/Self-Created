//
//  LineGraph.swift
//  HospitalMD
//
//  Created by Saurav on 25/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit
import QuartzCore

// make Arrays substractable
func - (left: Array<CGFloat>, right: Array<CGFloat>) -> Array<CGFloat> {
    var result: Array<CGFloat> = []
    for index in 0..<left.count {
        var difference = left[index] - right[index]
        result.append(difference)
    }
    return result
}

// delegate method
@objc protocol LineGraphDelegate {
    func didSelectDataPoint(x: CGFloat, yValues: Array<CGFloat>, selectedDate: NSDate)
}
class LineGraph: UIControl {
    
    // MARK: - variables
    
    // default configuration
    var gridVisible = true
    var axesVisible = true
    var dotsVisible = true
    var labelsXVisible = true
    var labelsYVisible = true
    var areaUnderLinesVisible = false
    var gridLinesXVisible = true
    var gridLinesYVisible = false
    var numberOfGridLinesX: CGFloat = 5
    var numberOfGridLinesY: CGFloat = 3
    var animationEnabled = true
    var animationDuration: CFTimeInterval = 1
    
    var dotsBackgroundColor = UIColor.whiteColor()
    
    var areaBetweenLines = [-1, -1]
    
    // sizes
    var lineWidth: CGFloat = 2
    var outerRadius: CGFloat = 12
    var innerRadius: CGFloat = 8
    var outerRadiusHighlighted: CGFloat = 12
    var innerRadiusHighlighted: CGFloat = 8
    var axisInset: CGFloat = 10
    
    // values calculated on init
    var drawingHeight: CGFloat = 0
    var drawingWidth: CGFloat = 0
    
    var delegate: LineGraphDelegate?
    
    // data stores
    var dataStore: Array<Array<CGFloat>> = []
    var dotsDataStore: Array<Array<DotLayer>> = []
    var lineLayerStore: Array<CAShapeLayer> = []
    var colors: Array<UIColor> = []
    
    var xAxisLabels = [NSDate]()
    var linesColor = [CGColor]()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.backgroundColor = UIColor.clearColor()
        self.userInteractionEnabled = true
        self.colors = [
            UIColorFromHex(0x3F3F3F),
            UIColorFromHex(0x696969),
            UIColorFromHex(0x7E7E7E),
            UIColorFromHex(0x939393),
            UIColorFromHex(0xA8A8A8),
            UIColorFromHex(0xBDBDBD),
            UIColorFromHex(0xD3D3D3),
            UIColorFromHex(0xEDEDED),
            UIColorFromHex(0xFAFAFA)
        ]
    }
    
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    
    override func drawRect(rect: CGRect) {
        
        self.drawingHeight = self.bounds.height - (2 * axisInset)
        self.drawingWidth = self.bounds.width - (2 * axisInset) - 8
        
        // remove all labels
        for view: AnyObject in self.subviews {
            view.removeFromSuperview()
        }
        
        // remove all lines on device rotation
        for lineLayer in lineLayerStore {
            lineLayer.removeFromSuperlayer()
        }
        lineLayerStore.removeAll()
        
        // remove all dots on device rotation
        for dotsData in dotsDataStore {
            for dot in dotsData {
                dot.removeFromSuperlayer()
            }
        }
        dotsDataStore.removeAll()
        
        // draw grid
        if gridVisible { drawGrid() }
        
        // draw axes
        if axesVisible { drawAxes() }
        
        // draw labels
        if labelsXVisible { drawXLabels() }
        if labelsYVisible { drawYLabels() }
        
        // draw filled area between charts
        if areaBetweenLines[0] > -1 && areaBetweenLines[1] > -1 {
            drawAreaBetweenGraphs()
        }
        
        // draw lines
        for (lineIndex, lineData) in enumerate(dataStore) {
            var scaledDataXAxis = scaleDataXAxis(lineData)
            var scaledDataYAxis = scaleDataYAxis(lineData)
            drawLine(scaledDataXAxis, yAxis: scaledDataYAxis, lineIndex: lineIndex)
            
            // draw dots
            if dotsVisible { drawDataDots(scaledDataXAxis, yAxis: scaledDataYAxis, lineIndex: lineIndex) }
            
            // draw area under line chart
            if areaUnderLinesVisible { drawAreaBeneathLineGraph(scaledDataXAxis, yAxis: scaledDataYAxis, lineIndex: lineIndex) }
            
        }
        
    }
    
    
    
    /**
    * Convert hex color to UIColor
    */
    func UIColorFromHex(hex: Int) -> UIColor {
        var red = CGFloat((hex & 0xFF0000) >> 16) / 255.0
        var green = CGFloat((hex & 0xFF00) >> 8) / 255.0
        var blue = CGFloat((hex & 0xFF)) / 255.0
        return UIColor(red: red, green: green, blue: blue, alpha: 1)
    }
    
    
    
    /**
    * Lighten color.
    */
    func lightenUIColor(color: UIColor) -> UIColor {
        var h: CGFloat = 0
        var s: CGFloat = 0
        var b: CGFloat = 0
        var a: CGFloat = 0
        color.getHue(&h, saturation: &s, brightness: &b, alpha: &a)
        return UIColor(hue: h, saturation: s, brightness: b * 1.5, alpha: a)
    }
    
    
    
    /**
    * Get y value for given x value. Or return zero or maximum value.
    */
    func getYValuesForXValue(x: Int) -> Array<CGFloat> {
        var result: Array<CGFloat> = []
        for lineData in dataStore {
            if x < 0 {
                result.append(lineData[0])
            } else if x > lineData.count - 1 {
                result.append(lineData[lineData.count - 1])
            } else {
                result.append(lineData[x])
            }
        }
        return result
    }
    
    
    
    /**
    * Handle touch events.
    */
    func handleTouchEvents(touches: NSSet!, event: UIEvent!) {
        var point: AnyObject! = touches.anyObject()
        var xValue = point.locationInView(self).x
        var closestXValueIndex = findClosestXValueInData(xValue)
        var yValues: Array<CGFloat> = getYValuesForXValue(closestXValueIndex)
        highlightDataPoints(closestXValueIndex)
        delegate?.didSelectDataPoint(CGFloat(closestXValueIndex), yValues: yValues, selectedDate: xAxisLabels[closestXValueIndex])
    }
    
    override func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
        handleTouchEvents(touches, event: event)
    }
    
    /**
    * Listen on touch end event.
    */
    override func touchesEnded(touches: Set<NSObject>, withEvent event: UIEvent) {
        handleTouchEvents(touches, event: event)
        
    }
    
    /**
    * Listen on touch move event
    */
    override func touchesMoved(touches: Set<NSObject>, withEvent event: UIEvent) {
        handleTouchEvents(touches, event: event)
        
    }
    
    /**
    * Find closest value on x axis.
    */
    func findClosestXValueInData(xValue: CGFloat) -> Int {
        var scaledDataXAxis = scaleDataXAxis(dataStore[0])
        var difference = scaledDataXAxis[1] - scaledDataXAxis[0]
        var dividend = (xValue - axisInset) / difference
        var roundedDividend = Int(round(Double(dividend)))
        return roundedDividend
    }
    
    
    
    /**
    * Highlight data points at index.
    */
    func highlightDataPoints(index: Int) {
        for (lineIndex, dotsData) in enumerate(dotsDataStore) {
            // make all dots white again
            for dot in dotsData {
                dot.backgroundColor = dotsBackgroundColor.CGColor
//                dot.borderWidth = 1
            }
            // highlight current data point
            var dot: DotLayer
            if index < 0 {
                dot = dotsData[0]
            } else if index > dotsData.count - 1 {
                dot = dotsData[dotsData.count - 1]
            } else {
                dot = dotsData[index]
            }
            dot.backgroundColor = lightenUIColor(colors[lineIndex]).CGColor
//            dot.borderWidth = 2
        }
    }
    
    
    
    /**
    * Draw small dot at every data point.
    */
    func drawDataDots(xAxis: Array<CGFloat>, yAxis: Array<CGFloat>, lineIndex: Int) {
        var dots: Array<DotLayer> = []
        for index in 0..<xAxis.count {
            var xValue = xAxis[index] + axisInset - outerRadius/2
            var yValue = self.bounds.height - yAxis[index] - axisInset - outerRadius/2
            
            // draw custom layer with another layer in the center
            var dotLayer = DotLayer()
            //dotLayer.dotInnerColor = colors[lineIndex]
            dotLayer.dotInnerBorderColor = lineIndex < self.linesColor.count ? linesColor[lineIndex] : UIColor.blackColor().CGColor
            dotLayer.innerRadius = innerRadius
            dotLayer.backgroundColor = dotsBackgroundColor.CGColor
            dotLayer.cornerRadius = outerRadius / 2
            dotLayer.frame = CGRect(x: xValue, y: yValue, width: outerRadius, height: outerRadius)
            self.layer.addSublayer(dotLayer)
            dots.append(dotLayer)
            
            //Open this if Animation is required
            
            // animate opacity
            //            if animationEnabled {
            //                var animation = CABasicAnimation(keyPath: "opacity")
            //                animation.duration = animationDuration
            //                animation.fromValue = 0
            //                animation.toValue = 1
            //                dotLayer.addAnimation(animation, forKey: "opacity")
            //            }
            
        }
        dotsDataStore.append(dots)
    }
    
    
    
    /**
    * Draw x and y axis.
    */
    func drawAxes() {
        var height = self.bounds.height
        var width = self.bounds.width
        var context = UIGraphicsGetCurrentContext()
        CGContextSetStrokeColorWithColor(context, UIColor.axesColor().CGColor)
        // draw x-axis
        CGContextMoveToPoint(context, axisInset, height-axisInset)
        CGContextAddLineToPoint(context, width-axisInset, height-axisInset)
        CGContextStrokePath(context)
        // draw y-axis
        CGContextMoveToPoint(context, axisInset, height-axisInset)
        CGContextAddLineToPoint(context, axisInset, axisInset)
        CGContextStrokePath(context)
    }
    
    
    
    /**
    * Get maximum value in all arrays in data store.
    */
    func getMaximumValue() -> CGFloat {
        var maximum = 0
        for data in dataStore {
            var newMaximum = data.reduce(Int.min, combine: { max(Int($0), Int($1)) })
            if newMaximum > maximum {
                maximum = newMaximum
            }
        }
        return CGFloat(maximum)
    }
    
    
    
    /**
    * Scale to fit drawing width.
    */
    func scaleDataXAxis(data: Array<CGFloat>) -> Array<CGFloat> {
        var factor = drawingWidth / CGFloat(data.count - 1)
        var scaledDataXAxis: Array<CGFloat> = []
        for index in 0..<data.count {
            var newXValue = factor * CGFloat(index)
            scaledDataXAxis.append(newXValue)
        }
        return scaledDataXAxis
    }
    
    
    
    /**
    * Scale data to fit drawing height.
    */
    func scaleDataYAxis(data: Array<CGFloat>) -> Array<CGFloat> {
        var maximumYValue = getMaximumValue()
        var factor = drawingHeight / maximumYValue
        var scaledDataYAxis = data.map({datum -> CGFloat in
            var newYValue = datum * factor
            return newYValue
        })
        return scaledDataYAxis
    }
    
    
    
    /**
    * Draw line.
    */
    func drawLine(xAxis: Array<CGFloat>, yAxis: Array<CGFloat>, lineIndex: Int) {
        var path = CGPathCreateMutable()
        CGPathMoveToPoint(path, nil, axisInset, self.bounds.height - yAxis[0] - axisInset)
        for index in 1..<xAxis.count {
            var xValue = xAxis[index] + axisInset
            var yValue = self.bounds.height - yAxis[index] - axisInset
            CGPathAddLineToPoint(path, nil, xValue, yValue)
        }
        
        var layer = CAShapeLayer()
        layer.frame = self.bounds
        layer.path = path
        layer.strokeColor = lineIndex < self.linesColor.count ? linesColor[lineIndex] : UIColor.blackColor().CGColor
        layer.fillColor = nil
        layer.lineWidth = lineWidth
        self.layer.addSublayer(layer)
        
        // animate line drawing
        if animationEnabled {
            var animation = CABasicAnimation(keyPath: "strokeEnd")
            animation.duration = animationDuration
            animation.fromValue = 0
            animation.toValue = 1
            layer.addAnimation(animation, forKey: "strokeEnd")
        }
        
        // add line layer to store
        lineLayerStore.append(layer)
    }
    
    
    /**
    * Fill area between line chart and x-axis.
    */
    func drawAreaBeneathLineGraph(xAxis: Array<CGFloat>, yAxis: Array<CGFloat>, lineIndex: Int) {
        var context = UIGraphicsGetCurrentContext()
        CGContextSetFillColorWithColor(context, colors[lineIndex].colorWithAlphaComponent(0.2).CGColor)
        // move to origin
        CGContextMoveToPoint(context, axisInset, self.bounds.height - axisInset)
        // add line to first data point
        CGContextAddLineToPoint(context, axisInset, self.bounds.height - yAxis[0] - axisInset)
        // draw whole line chart
        for index in 1..<xAxis.count {
            var xValue = xAxis[index] + axisInset
            var yValue = self.bounds.height - yAxis[index] - axisInset
            CGContextAddLineToPoint(context, xValue, yValue)
        }
        // move down to x axis
        CGContextAddLineToPoint(context, xAxis[xAxis.count-1] + axisInset, self.bounds.height - axisInset)
        // move to origin
        CGContextAddLineToPoint(context, axisInset, self.bounds.height - axisInset)
        CGContextFillPath(context)
    }
    
    
    
    /**
    * Fill area between charts.
    */
    func drawAreaBetweenGraphs() {
        
        var xAxis = scaleDataXAxis(dataStore[0])
        var yAxisDataA = scaleDataYAxis(dataStore[areaBetweenLines[0]])
        var yAxisDataB = scaleDataYAxis(dataStore[areaBetweenLines[1]])
        var difference = yAxisDataA - yAxisDataB
        
        for index in 0..<xAxis.count-1 {
            
            var context = UIGraphicsGetCurrentContext()
            
            if difference[index] < 0 {
                CGContextSetFillColorWithColor(context, UIColor.negativeAreaColor().CGColor)
            } else {
                CGContextSetFillColorWithColor(context, UIColor.positiveAreaColor().CGColor)
            }
            
            var point1XValue = xAxis[index] + axisInset
            var point1YValue = self.bounds.height - yAxisDataA[index] - axisInset
            var point2XValue = xAxis[index] + axisInset
            var point2YValue = self.bounds.height - yAxisDataB[index] - axisInset
            var point3XValue = xAxis[index+1] + axisInset
            var point3YValue = self.bounds.height - yAxisDataB[index+1] - axisInset
            var point4XValue = xAxis[index+1] + axisInset
            var point4YValue = self.bounds.height - yAxisDataA[index+1] - axisInset
            
            CGContextMoveToPoint(context, point1XValue, point1YValue)
            CGContextAddLineToPoint(context, point2XValue, point2YValue)
            CGContextAddLineToPoint(context, point3XValue, point3YValue)
            CGContextAddLineToPoint(context, point4XValue, point4YValue)
            CGContextAddLineToPoint(context, point1XValue, point1YValue)
            CGContextFillPath(context)
            
        }
        
    }
    
    
    
    /**
    * Draw x grid.
    */
    func drawXGrid() {
        
        var space = drawingWidth / numberOfGridLinesX
        var context = UIGraphicsGetCurrentContext()
        CGContextSetStrokeColorWithColor(context, UIColor.axesColor().CGColor)
        CGContextSetLineWidth(context, 0.3)
        for index in 1...Int(numberOfGridLinesX) {
            CGContextMoveToPoint(context, axisInset + (CGFloat(index) * space), self.bounds.height - axisInset)
            CGContextAddLineToPoint(context, axisInset + (CGFloat(index) * space), axisInset)
        }
        CGContextStrokePath(context)
    }
    
    
    
    /**
    * Draw y grid.
    */
    func drawYGrid() {
        var maximumYValue = getMaximumValue()
        var step = Int(maximumYValue) / Int(numberOfGridLinesY)
        step = step == 0 ? 1 : step
        var height = drawingHeight / maximumYValue
        var context = UIGraphicsGetCurrentContext()
        for var index = 0; index <= Int(maximumYValue); index += step {
            CGContextMoveToPoint(context, axisInset, self.bounds.height - (CGFloat(index) * height) - axisInset)
            CGContextAddLineToPoint(context, self.bounds.width - axisInset, self.bounds.height - (CGFloat(index) * height) - axisInset)
        }
        CGContextStrokePath(context)
    }
    
    
    
    /**
    * Draw grid.
    */
    func drawGrid() {
        if gridLinesXVisible { drawXGrid() }
        if gridLinesYVisible { drawYGrid() }
        
    }
    
    
    
    /**
    * Draw x labels.
    */
    func drawXLabels() {
        var xAxisData = self.dataStore[0]
        var scaledDataXAxis = scaleDataXAxis(xAxisData)
        for (index, scaledValue) in enumerate(scaledDataXAxis) {
            var label = UILabel(frame: CGRect(x: scaledValue - axisInset/2, y: self.bounds.height-axisInset+10, width: axisInset + 20, height: axisInset))
            label.font = UIFont.HELVETICANEUE_REGULAR(11.0)
            label.textAlignment = NSTextAlignment.Center
            label.textColor = UIColor.xAxisLabelsColor()
            let date = NSDate.convertToString(fromDate: self.xAxisLabels[index], strFormatter: DATEFORMATTER_WEEKDAY)
            label.text = date
            self.addSubview(label)
            
        }
    }
    
    
    
    /**
    * Draw y labels.
    */
    func drawYLabels() {
        var maximumYValue = getMaximumValue()
        var step = Int(maximumYValue) / Int(numberOfGridLinesY)
        step = step == 0 ? 1 : step
        var height = drawingHeight / maximumYValue
        for var index = 0; index <= Int(maximumYValue); index += step {
            var yValue = self.bounds.height - (CGFloat(index) * height) - (axisInset * 1.5)
            var label = UILabel(frame: CGRect(x: -10, y: yValue, width: axisInset + 10, height: axisInset))
            label.font = UIFont.HELVETICANEUE_REGULAR(11.0)
            label.textAlignment = NSTextAlignment.Center
            label.textColor = UIColor.xAxisLabelsColor()
            label.text = String(index)
            self.addSubview(label)
        }
    }
    
    
    
    /**
    * Add line chart
    */
    func addLine(data: Array<CGFloat>) {
        self.dataStore.append(data)
        self.setNeedsDisplay()
    }
    
    
}

