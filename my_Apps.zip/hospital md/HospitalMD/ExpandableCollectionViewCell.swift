//
//  ExpandableCollectionViewCell.swift
//  HospitalMD
//
//  Created by Saurav on 20/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit
import HealthCareData

//This class is used to display Patient's Care team memeber and also nurse can contact different memeber using call or message
class ExpandableCollectionViewCell: UICollectionViewCell {
    
    // MARK: - @IBOutlet variables
    @IBOutlet weak var personImageView: UIImageView!
    @IBOutlet weak var personNameLabel: UILabel!
    @IBOutlet weak var callView: UIView!
    @IBOutlet weak var messageView: UIView!
    
    // MARK: - UITableViewCell
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.personImageView.layer.cornerRadius = self.personImageView.frame.width/2
        self.personImageView.layer.masksToBounds = true
    }
    
    // MARK: - Configure the care team cell for expandable state
    func configureCellForCareTeamMember(careTeamMember: StaffMember2) {
        
        self.personImageView.image = UIImage(named: careTeamMember.profilePictureURL)
        self.personNameLabel.text = careTeamMember.firstName + ". " + careTeamMember.lastName + ", " + careTeamMember.role
    }
    
}