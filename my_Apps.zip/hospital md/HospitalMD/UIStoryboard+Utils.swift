//
//  UIStoryboard+Utils.swift
//  HospitalMD
//
//  Created by Saurav on 18/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit

extension UIStoryboard {
    
    class func mainStoryboard() -> UIStoryboard {
        return UIStoryboard(name: "Main", bundle: nil)
    }
    class func autoSignOutStoryboard() -> UIStoryboard {
        return UIStoryboard(name: "AutoSignOut", bundle: nil)
    }
    class func dashBoardStoryboard() -> UIStoryboard {
        return UIStoryboard(name: "DashBoard", bundle: nil)
    }
    
    class func patientListStoryboard() -> UIStoryboard {
        return UIStoryboard(name: "PatientList", bundle: nil)
    }
    
    class func patientFilterListStoryboard() -> UIStoryboard {
        return UIStoryboard(name: "PatientFilterList", bundle: nil)
    }
    class func checkListStoryBoard() -> UIStoryboard {
        return UIStoryboard(name: "CheckList", bundle: nil)
    }
    class func vitalSignsStoryBoard() -> UIStoryboard {
        return UIStoryboard(name: "VitalSigns", bundle: nil)
    }
    class func patientSearchStoryBoard() -> UIStoryboard {
        return UIStoryboard(name: "SearchPatient", bundle: nil)
    }
    class func alertListStoryBoard() -> UIStoryboard {
        return UIStoryboard(name: "AlertList", bundle: nil)
    }
}
