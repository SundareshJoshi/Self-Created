//
//  AuthenticationController.swift
//
//  Created by Jeremy Koch on 9/24/14.
//  Copyright (c) 2014 IBM. All rights reserved.
//

import UIKit
import MFLogin
import MFNetworking
import HealthCareData

extension UIViewController {
    var authenticationController: AuthenticationController? {
        return (UIApplication.sharedApplication().delegate as! AppDelegate).authenticationController
    }
}

class AuthenticationController: UIViewController, LoginViewControllerDelegate {
    
    // MARK: - Private variables

    private var loginViewController: LoginViewController!
    private var securedRootViewController: UIViewController!
    private let sharedInstance = SessionService.sharedInstance
    private let startNotifier = ConnectionNotifier.Notify


    // MARK: - Controller Life cycle Methods

    override func viewDidLoad() {
        super.viewDidLoad()
        // Initialising the sharedInstance values
        sharedInstance.isUserLogged = false
        sharedInstance.isAutoSignOutPageDisplayed = false
        
        self.loadAuthorizationController()
    }
    
    // MARK: - Sign out action
    
    //To signout from any controller to Login
    func signOut() {
        // sharedInstance values are updated once the user logs out
        sharedInstance.isUserLogged = false
        sharedInstance.isAutoSignOutPageDisplayed = false
        flipFromViewController(securedRootViewController, toController: loginViewController, options: UIViewAnimationOptions.TransitionNone)
        self.securedRootViewController = nil
    }

    // MARK: - Private setup and management
    
    //Initialize the LoginViewController and Load it in the AuthenticationController
    private func loadAuthorizationController() {

        // load the app name
        let displayName = NSBundle.mainBundle().infoDictionary?["CFBundleDisplayName"] as? String ?? ""
        
        // create the login controller
        self.loginViewController = LoginViewController.defaultController()
        self.loginViewController.delegate = self
        self.loginViewController.passwordRequired = true
        self.loginViewController.headingText = displayName
        self.loginViewController.enableTouchID = true

        // for demo purpose
        self.loginViewController.defaultUserID = DEFAULT_USERID
        self.loginViewController.defaultPassword = DEFAULT_PASSWORD
        
        // updates the footer text
        self.update()
        
        // add login as child view controller
        self.addChildViewController(loginViewController)
        view.addSubview(loginViewController.view)
        loginViewController.didMoveToParentViewController(self)
    }
    
    /**
    Make the transition from Login to next controller with TransitionCrossDissolve animation
    
    :param: fromController - current controller, toController - next controller, options - Animation type
    */
    internal override func flipFromViewController(fromController: UIViewController, toController: UIViewController, options: UIViewAnimationOptions) {
        toController.view.frame = fromController.view.bounds
        self.addChildViewController(toController)
        fromController.willMoveToParentViewController(nil)
        
        self.transitionFromViewController(fromController, toViewController: toController, duration: 0.2, options: options, animations: {}) { (finished) -> Void in
            fromController.removeFromParentViewController()
            toController.didMoveToParentViewController(self)
        }
    }
    
    //Show the App version and Environment mode to the User
    func update() {
        let appVersion = NSBundle.mainBundle().infoDictionary?["CFBundleShortVersionString"] as? String ?? ""
        let envMode = AppSettings.sharedInstance.localMode ? "LOCAL" : AppSettings.sharedInstance.remoteName
        self.loginViewController.footerText = "\(appVersion) (\(envMode))"
    }
    
    // MARK: - Login response handling
    /**
    Method called after successful login and navigates to next Viewcontroler
    
    :param: authToken - Authentication token required for next level of functionalists
    */
    private func loginSuccessfulWithAuthorizationToken(authToken: String) {
        // sharedInstance values are updated once the user logs in
        sharedInstance.isUserLogged = true
        sharedInstance.isAutoSignOutPageDisplayed = false
        
        // Initialise Reachability
        startNotifier.startReachability()
        
        // store the auth token
        DataSourceManager.addHeaderWithName(HEADERKEY_AUTHORIZATION, value: authToken)
        
        self.loadMainViewController()

    }
    
    private func loadMainViewController() {
        // create the root view controller
        self.securedRootViewController = UIStoryboard.patientListStoryboard().instantiateViewControllerWithIdentifier(STORYBOARD_PATIENTLIST) as! UINavigationController
        
        // perform any additional service request or just load the main view controller
        flipFromViewController(self.loginViewController, toController: self.securedRootViewController, options: UIViewAnimationOptions.TransitionCrossDissolve)
    }
    /**
    Show Error popup after unsuccessful login
    
    :param: error - To know which type of error
    */
    private func loginFailedWithError(error: NSError) {
        // create the error message
        var message: String
        if error.code == 401 {
            message = NSLocalizedString(MESSAGE_INVALIDUSERORPASSWORD, comment: COMMENT_INVALIDUSERORPASSWORD)
        } else {
            message = NSLocalizedString(MESSAGE_NETWORKERROR, comment: MESSAGE_NETWORKERROR)
        }
        
        // show the alert
        var alert = AlertUtils.showErrorWith(message: message)
        self.presentViewController(alert, animated: false, completion: nil)
    }
    
    // MARK: - Login delegate
    
    func loginViewController(loginViewController: LoginViewController, didLoginWithUsername username: String, password: String, completionHandler: (Bool) -> Void) {
        
        //UserId and password validation
        if ((username != DEFAULT_USERID) || (password != DEFAULT_PASSWORD))
        {
            let error = NSError(domain: "", code: 401, userInfo: nil)
            self.loginFailedWithError(error)
            completionHandler(false)
            return
        }

        // authenticate with the server
        Request.Authentication(username, password).execute().validate().responseJSON { (_, _, json, error) -> Void in
            if let error = error {
                // inform login controller the login is unsuccessfully complete
                completionHandler(false)
                self.loginFailedWithError(error)
            } else {
                // inform login controller the login is successfully complete
                completionHandler(true)
                let authToken = Response.authenticationTokenFromJSON(json)
                self.loginSuccessfulWithAuthorizationToken(authToken)
            }
        }
    }
    
    func loginViewController(loginViewController: LoginViewController, didLoginUsingTouchWithCompletionHandler completionHandler: (Bool) -> Void) {
        // inform login controller the login is successfully complete
        completionHandler(true)
        
        // Up to the app to do something interesting since login occurred with Touch ID, but we'll just fake success with a placeholder token
        self.loginSuccessfulWithAuthorizationToken(TOKEN_TOUCHID)
    }
}

