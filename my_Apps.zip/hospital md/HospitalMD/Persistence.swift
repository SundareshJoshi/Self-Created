//
//  Persistence.swift
//  ShiftHandover
//
//  Created by David Huo on 2015-02-13.
//  Copyright (c) 2015 IBM. All rights reserved.
//



class Stores {
    class var User : String { return "user" }
    
// ***** Sample properties *****/
//    class var Crew : String  { return "crew" }
//    class var Position : String  { return "position" }
//    class var Shift : String  { return "shift" }
//    class var PreviousShift : String  { return "preshift" }
//    class var Category : String  { return "category" }
//    class var IncompleteReason : String  { return "incompletereason" }
//    class var Goals : String { return "goals" }
//    class var Machines : String {    return "machine"    }
//    class var Team : String {    return "team"    }
//    class var ShiftLog : String {    return "shiftlog"    }
//  
//    class var ShiftId:String {
//        return "shift"
//    }
}

// JSON document persistence contract
// This protcol is used for reading/writing 
// JSON document
@objc protocol IJSONPersistence {
    
    // store is the pool name for the same type of JSON documents
    // objectId is the identifier of the JSON data, an entity name
    func read(store:String, objectId: String) -> NSMutableDictionary?
    // store is the pool name for the same type of JSON documents
    // json is the dictionary data to be written 
    // the to as the given id, entity name
    // It returns true if the operation successful
    func write(store:String, json:NSMutableDictionary, withObjectId:String)->Bool
    
    // Gets all the documents from a store
    func readAll(store : String)->[NSMutableDictionary]?
    
    // Remove the storage
    func reset()
}