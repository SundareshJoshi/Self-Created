//
//  PatientFilterListViewController.swift
//  HospitalMD
//
//  Created by Das on 21/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit

//This protocol is used for determining which patient category is selected, so that it can be passed to calling View Contorller
@objc protocol PatientFilterDelegate {
    optional func selectedFilterTitle(title : String)
    optional func selectedFilterTypeIndex(indexRow : Int)
}

//This class is used to display various categories of Patient
class PatientFilterListViewController: UIViewController {
    
    //MARK:- Variable
    private let patientFilterList = [TEXT_ALLPATIENT,TEXT_ROUNDINGPATIENT,TEXT_NEWPATIENT,TEXT_DCPATIENT]
    private var selectedIndex : Int?
    weak var delegate:PatientFilterDelegate?
    
    //MARK:- IBOutlet
    @IBOutlet weak var patientTableView: UITableView!
    
    //MARK:- ViewLifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        selectedIndex = Patient.selectedFilterIndex
        
        //To adjust the scroll insets according to view
        self.automaticallyAdjustsScrollViewInsets = false
        
        //Don't show empty rows
        self.patientTableView.tableFooterView = UIView(frame: CGRectZero)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK:- IBActton
    @IBAction func doneClicked(sender: AnyObject) {
        
        if delegate != nil {
            delegate?.selectedFilterTitle!("\(Patient.patientTypeFilterArray[selectedIndex!]) (\(Patient.patientFilterArrayofPatientList[selectedIndex!].count))")
            
            delegate?.selectedFilterTypeIndex!(selectedIndex!)
        }
        
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    //MARK:- TableView DataSource
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Patient.patientTypeFilterArray.count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        return CELLHEIGHT_PATIENTFILTERLIST
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier(CELLIDENTIFIER_PATIENTFILTERLIST) as! UITableViewCell
        cell.textLabel?.text = "\(Patient.patientTypeFilterArray[indexPath.row]) (\(Patient.patientFilterArrayofPatientList[indexPath.row].count))"
        cell.accessoryType = UITableViewCellAccessoryType.None
        cell.accessoryView = nil
        
        if indexPath.row == selectedIndex {
            cell.accessoryView = UIImageView(image: UIImage(named: IMAGE_CHECKMARK))
        }
        return cell
    }
    
    //MARK:- TableView Delegate
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        Patient.selectedFilterIndex = indexPath.row
        selectedIndex = indexPath.row
        tableView.reloadData()
        
        //Pass the selected Category Item to previous screen
        if delegate != nil {
            delegate?.selectedFilterTitle!("\(Patient.patientTypeFilterArray[selectedIndex!]) (\(Patient.patientFilterArrayofPatientList[selectedIndex!].count))")
            
            delegate?.selectedFilterTypeIndex!(selectedIndex!)
        }
        
        self.dismissViewControllerAnimated(true, completion: nil)
    }
}
