//
//  NetworkAcitivityIndicatorManager.swift
//  HospitalMD
//
//  Created by Saurav on 18/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import Foundation
import UIKit

class NetworkAcitivityIndicatorManager {
    class var sharedInstance : NetworkAcitivityIndicatorManager { //design as singleton.
        
        struct Static {
            static let instance = NetworkAcitivityIndicatorManager()
        }
        
        return Static.instance
    }
    
    private var addRequestsCounter = 0
    private let synchronizationQueue = dispatch_queue_create("AppDelegate.synchronizationQueue", nil)
    
    func addNetworkActivityIndicator() {
        // synchronized pattern in Swift
        dispatch_sync(synchronizationQueue){
            self.addRequestsCounter++
            UIApplication.sharedApplication().networkActivityIndicatorVisible = true
        }
    }
    
    func removeNetworkActivityIndicator() {
        // synchronized pattern in Swift
        dispatch_sync(synchronizationQueue){
            self.addRequestsCounter--
            if (self.addRequestsCounter <= 0) {
                self.addRequestsCounter = 0
                UIApplication.sharedApplication().networkActivityIndicatorVisible = false
            }
        }
    }
    
}