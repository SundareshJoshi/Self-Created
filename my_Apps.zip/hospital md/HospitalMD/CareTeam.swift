//
//  CareTeam.swift
//  HospitalMD
//
//  Created by Saurav on 20/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit
import MFNetworking

//Modal For Care Team
class CareTeam {
    
    //MARK: - Variables
    var clinicianFirstName: String?
    var clinicianLastName: String?
    var clinicianImageName: String?
    var clinicianRole: String?
    var clinicianStaffid: String?
    
    //MARK: - Initialize modal data
    init(json: JSON) {
        self.clinicianImageName = json["profilePictureUrl"].stringValue
        self.clinicianFirstName = json["firstName"].stringValue
        self.clinicianLastName = json["lastName"].stringValue
        self.clinicianRole = json["role"].stringValue
        self.clinicianStaffid = json["staffId"].stringValue
    }
}