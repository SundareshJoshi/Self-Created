//
//  RESTAPIImpl.swift
//  ShiftHandover
//
//  Created by David Huo on 2015-04-02.
//  Copyright (c) 2015 IBM. All rights reserved.
//


import MFNetworking

@objc class RestApiImpl : RestApi {
    func persist(data:String?, key:String, store:String) {
        if let p = lookupService(IJSONPersistence) {
            if let json = data?.json() {
                if let items = json[key] as? [NSMutableDictionary] {
                    for c in items {
                        p.write(store, json: c as NSMutableDictionary, withObjectId: c["id"] as! String)
                    }
                } else {
                    if let jsonNode = json[key] as? NSMutableDictionary {
                        p.write(store, json: jsonNode, withObjectId: key)
                    } else {
                        MFLog("Warning, server data error! Can't find data under key \(key)")
                    }
                }
            }
        }
    }
}







