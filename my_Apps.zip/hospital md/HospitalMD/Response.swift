//
//  Response.swift
//
//  Created by Jeremy Koch on 12/13/14.
//  Copyright (c) 2014 IBM. All rights reserved.
//

import Foundation
import MFNetworking

class Response {
    
    /**
    Convert the JSON object to get Authorization token
    
    :param: json :  The JSON object need to get Authorization token
    :returns: Authorization token
    */

    class func authenticationTokenFromJSON(json: JSON) -> String {
        let root = json["response"]
        return root["Authorization"].stringValue
    }
    
    //MARK: - Response data for discharge checkList
    class func dataForDischargeCheckList(json: JSON) -> [DischargeCheckListModal] {
        let root = json["response"]
        
        var listData : [DischargeCheckListModal] = []
        for checkList in root
        {
            let result = DischargeCheckListModal(json: checkList)
            listData.append(result)
        }
        return listData
    }
    
    //MARK: - Response data for PatientAlert List
    class func patientAlertList(json: JSON) -> [AlertListModal] {
        let root = json["response"]
        
        var listData : [AlertListModal] = []
        for alertList in root
        {
            let result = AlertListModal(json: alertList)
            listData.append(result)
        }
        return listData
    }
    
    /**
    Parse the JSON object to our required format
    
    :param: json :  The JSON object need to convert to Array
    :returns: Array of the Notes Modal object
    */

    class func notesDataFromJSON(json: JSON) -> [NotesModal] {
        let root = json["response"]
        
        var listData : [NotesModal] = []
        for checkList in root
        {
            let result = NotesModal(json: checkList)
            listData.append(result)
        }
        return listData
    }
    
    /**
    Parse the JSON object to our required format
    
    :param: json :  The JSON object need to convert to Array
    :returns: Array of the CareTeam Modal object
    */
    class func careTeamFromJSON(json: JSON) -> [CareTeam] {
        let root = json["response"]
        
        var listData : [CareTeam] = []
        for checkList in root
        {
            let result = CareTeam(json: checkList)
            listData.append(result)
        }
        return listData
    }
    class func patientListFromJSON(json: JSON) -> [Patient] {
        let root = json["response"]
        
        var listData : [Patient] = []
        for checkList in root
        {
            let result = Patient(json: checkList)
            listData.append(result)
        }
        return listData
    }
    
    /**
    Parse the JSON object to our required format
    
    :param: json :  The JSON object need to convert to Array
    :returns: Array of the Alert Modal object
    */
    class func alertDataFromJSON(json: JSON) -> [AlertModal] {
        let root = json["response"]
        
        var listData : [AlertModal] = []
        for checkList in root
        {
            let result = AlertModal(json: checkList)
            listData.append(result)
        }
        return listData
    }
}