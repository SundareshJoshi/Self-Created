//
//  NSBundle+Utils.swift
//  StarterApp
//
//  Created by Ryan Moniz on 2015-02-18.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import Foundation

extension NSBundle {
    
    class func printAppVersionBuild() {
        if let appVersion: AnyObject = NSBundle.mainBundle().objectForInfoDictionaryKey("CFBundleShortVersionString") {
            if let appBuild: AnyObject = NSBundle.mainBundle().objectForInfoDictionaryKey("CFBundleVersion") {
                if let appName: AnyObject = NSBundle.mainBundle().objectForInfoDictionaryKey("CFBundleDisplayName") {
                    MFLog("\(appName): v\(appVersion) Build: \(appBuild)")
                }
            }
        }
    }

    class func printAllEmbeddedFrameworksVersion() {
        //recursively looking for StarterApp.app/Frameworks/*.framework
        let sharedFrameworkPath = NSBundle.mainBundle().bundlePath + "/Frameworks"

        let filemanager:NSFileManager = NSFileManager()
        let files = filemanager.enumeratorAtPath(sharedFrameworkPath)
        while let file: AnyObject = files?.nextObject() {
            if file.pathExtension == "framework" {
                if let infoDict = NSDictionary(contentsOfFile:"\(sharedFrameworkPath)/" + "\(file)" + "/Info.plist") {
                    if let bundleVersion: AnyObject = infoDict.valueForKey("CFBundleShortVersionString") {
                        if let bundleName: AnyObject = infoDict.valueForKey("CFBundleName") {
                            MFLog("\(bundleName).framework: v\(bundleVersion)")
                        }
                    }
                }                
            }
        }
    }

    class func printFrameworkVersionFor(#identifier: String) {
        if let bundle = NSBundle(identifier: identifier) {
            if let bundleVersion: AnyObject = bundle.objectForInfoDictionaryKey("CFBundleShortVersionString") {
                if let bundleName: AnyObject = bundle.objectForInfoDictionaryKey("CFBundleName") {
                    println("\(bundleName).framework: v\(bundleVersion)")
                }
            }
        }
    }
}
