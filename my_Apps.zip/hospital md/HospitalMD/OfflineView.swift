//
//  OfflineView.swift
//  HospitalMD
//
//  Created by Sundaresh Joshi on 5/26/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit

//Design of offline view
class OfflineView: UIView {
    
    // MARK: - @IBOutlet
    @IBOutlet weak var offlineLabel: UILabel!
    
    // MARK: - View life cycle method
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        configureOfflineView()
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    // MARK: - Private method
    
    /**
    To set the text of the lable to show while the user is offline
    */
    private func configureOfflineView() {
        self.offlineLabel.text = "No connection. Changes will not sync until you are reconnected."
    }
}
