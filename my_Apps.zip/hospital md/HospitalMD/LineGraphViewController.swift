//
//  LineGraphView.swift
//  HospitalMD
//
//  Created by Saurav on 25/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit

//For drawing Line graph for blood pressure
class LineGraphViewController: UIViewController, LineGraphDelegate {

    // MARK: - variables
    var cellView = UIView()
    var dateTitle = UILabel()
    var rightFirstTitle = UILabel()
    var rightSecondTitle = UILabel()
    
    var lineGraph: LineGraph?
    
    // MARK: - View life cycle method
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        configureLineGraph()
    }
    
    // MARK: - Draw the line graph
    
    /**
    * Initialize the line graph data and draw according to that
    */
    func configureLineGraph() {
        
        cellView = UIView()
        cellView.setTranslatesAutoresizingMaskIntoConstraints(false)
        cellView.userInteractionEnabled = true
        self.view.addSubview(cellView)
        
        dateTitle.text = NSDate.convertToString(fromDate: NSDate.convertToDate(fromString: GRAPH_STARTDATE, strFormatter: DATEFORMATTER_NOTESWEBSERVICE), strFormatter: DATEFORMATTER_RESPIRATOTYGRAPH)
        dateTitle.setTranslatesAutoresizingMaskIntoConstraints(false)
        dateTitle.textAlignment = NSTextAlignment.Left
        dateTitle.font = UIFont.HELVETICANEUE_REGULAR(15.0)
        dateTitle.textColor = UIColor.dateTitleColor()
        dateTitle.numberOfLines = 0;
        dateTitle.preferredMaxLayoutWidth = 211;
        
        cellView.addSubview(dateTitle)
        
        rightFirstTitle.setTranslatesAutoresizingMaskIntoConstraints(false)
        rightFirstTitle.textAlignment = NSTextAlignment.Left
        rightFirstTitle.font = UIFont.HELVETICANEUE_THIN(22.0)
        rightFirstTitle.textColor = UIColor.rightFirstTitleColor()
        rightFirstTitle.numberOfLines = 0;
        var firstTitleString = NSMutableAttributedString(string: "\(TEXT_130) \(TEXT_MMHG)")
        firstTitleString.addAttribute(NSFontAttributeName, value: UIFont.HELVETICANEUE_REGULAR(30.0), range: NSRange(location:0,length:5))
        rightFirstTitle.attributedText = firstTitleString
        rightFirstTitle.preferredMaxLayoutWidth = 200.0;
        cellView.addSubview(rightFirstTitle)
        
        rightSecondTitle.setTranslatesAutoresizingMaskIntoConstraints(false)
        rightSecondTitle.textAlignment = NSTextAlignment.Left
        rightSecondTitle.font = UIFont.HELVETICANEUE_THIN(22.0)
        rightSecondTitle.textColor = UIColor.rightSecondTitleColor()
        rightSecondTitle.numberOfLines = 0;
        var secondTitleString = NSMutableAttributedString(string: "\(TEXT_90) \(TEXT_MMHG)")
        secondTitleString.addAttribute(NSFontAttributeName, value: UIFont.HELVETICANEUE_REGULAR(30.0), range: NSRange(location:0,length:4))
        rightSecondTitle.attributedText = secondTitleString
        rightSecondTitle.preferredMaxLayoutWidth = 200.0;
        
        cellView.addSubview(rightSecondTitle)
        
        
        var data: Array<CGFloat> = [90, 150, 85, 120, 170, 80]
        var data2: Array<CGFloat> = [60, 85, 120, 60, 100, 70]
        
        lineGraph = LineGraph()
        lineGraph!.areaUnderLinesVisible = false
        lineGraph!.addLine(data)
        lineGraph!.addLine(data2)
        lineGraph!.setTranslatesAutoresizingMaskIntoConstraints(false)
        lineGraph!.delegate = self
        lineGraph?.userInteractionEnabled = true
        let dateStart = NSDate.convertToDate(fromString: GRAPH_STARTDATE, strFormatter: DATEFORMATTER_NOTESWEBSERVICE)
        lineGraph?.xAxisLabels = [dateStart!, dateStart!.dateByAddingTimeInterval(1*60*60*24), dateStart!.dateByAddingTimeInterval(2*60*60*24), dateStart!.dateByAddingTimeInterval(3*60*60*24), dateStart!.dateByAddingTimeInterval(4*60*60*24), dateStart!.dateByAddingTimeInterval(5*60*60*24), dateStart!.dateByAddingTimeInterval(6*60*60*24)]
        lineGraph?.linesColor = [UIColor.rightFirstTitleColor().CGColor,UIColor.rightSecondTitleColor().CGColor]
        lineGraph?.numberOfGridLinesX = CGFloat(data.count - 1)
        cellView.addSubview(lineGraph!)
        
        cellView.bringSubviewToFront(lineGraph!)
        
        var views: Dictionary<String, AnyObject> = [:]
        var metrics: Dictionary<String, AnyObject> = [:]
        
        views["cellView"] = cellView
        views["dateTitle"] = dateTitle
        views["rightFirstTitle"] = rightFirstTitle
        views["rightSecondTitle"] = rightSecondTitle
        views["lineGraph"] = lineGraph
        
        metrics["padding"] = 15.0
        
        
        self.view.addConstraints(NSLayoutConstraint.constraintsWithVisualFormat("|[cellView]|", options: nil, metrics: metrics, views: views))
        self.view.addConstraints(NSLayoutConstraint.constraintsWithVisualFormat("V:|[cellView]", options: nil, metrics: metrics, views: views))
        
        cellView.addConstraints(NSLayoutConstraint.constraintsWithVisualFormat("H:[dateTitle]-padding-|", options: nil, metrics: metrics, views: views))
        cellView.addConstraints(NSLayoutConstraint.constraintsWithVisualFormat("H:[rightFirstTitle]-padding-|", options: nil, metrics: metrics, views: views))
        cellView.addConstraints(NSLayoutConstraint.constraintsWithVisualFormat("H:[rightSecondTitle]-padding-|", options: nil, metrics: metrics, views: views))
        
        cellView.addConstraints(NSLayoutConstraint.constraintsWithVisualFormat("V:|-padding-[dateTitle]->=0-[rightFirstTitle]->=0-[rightSecondTitle]-padding-|", options: nil, metrics: metrics, views: views))
        
        
        cellView.addConstraints(NSLayoutConstraint.constraintsWithVisualFormat("H:|-[lineGraph]-|", options: nil, metrics: nil, views: views))
        
        //Align Chart below rightSecondTitle and chart height is 150
        cellView.addConstraints(NSLayoutConstraint.constraintsWithVisualFormat("V:[rightSecondTitle]-[lineGraph(==150)]", options: nil, metrics: nil, views: views))
        
        self.view.bringSubviewToFront(cellView)
    }
    override func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
        
        var point: AnyObject! = touches.first
        let array = Array(touches)
        let touch = array[0] as! UITouch
        let currentLocation = touch.locationInView(self.view)
        
        if currentLocation.y > 90 && currentLocation.y < 220 {
            lineGraph?.touchesBegan(touches, withEvent: event)
        }
    }
    
    /**
    * Line chart delegate method.
    */
    func didSelectDataPoint(x: CGFloat, yValues: Array<CGFloat>, selectedDate: NSDate){
        
        dateTitle.text = NSDate.convertToString(fromDate: selectedDate, strFormatter: DATEFORMATTER_RESPIRATOTYGRAPH)

        var firstTitleString = NSMutableAttributedString(string: "\(Int(yValues[0]))  \(TEXT_MMHG)")
        firstTitleString.addAttribute(NSFontAttributeName, value: UIFont.HELVETICANEUE_REGULAR(30.0), range: NSRange(location:0,length:5))
        rightFirstTitle.attributedText = firstTitleString

        var secondTitleString = NSMutableAttributedString(string: "\(Int(yValues[1])) \(TEXT_MMHG)")
        secondTitleString.addAttribute(NSFontAttributeName, value: UIFont.HELVETICANEUE_REGULAR(30.0), range: NSRange(location:0,length:5))
        rightSecondTitle.attributedText = secondTitleString

    }
    
    /**
    * Redraw chart on device rotation.
    */
    //Following Method need to be implemented in ViewController who is using Line Graph
    override func didRotateFromInterfaceOrientation(fromInterfaceOrientation: UIInterfaceOrientation) {
        if let chart = lineGraph {
            chart.setNeedsDisplay()
        }
    }
}
