//
//  Global.swift
//  HospitalMD
//
//  Created by G Thomas on 5/17/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit

//MARK: CELL HEIGHT CONSTANT
let CELLHEIGHT_NOTE:CGFloat = 82.0
let CELLHEIGHT_TITLE:CGFloat = 45.0
let CELLHEIGHT_PATIENTFILTERLIST:CGFloat = 44.0
let CELLHEIGHT_DISCHARGE: CGFloat = 50.0

//MARK: CELL IDENTIFIER CONSTANT
let CELLIDENTIFIER_NOTESTITLE = "TitleViewCell"
let CELLIDENTIFIER_NOTES = "NotesTableViewCell"
let CELLIDENTIFIER_CARETEAM = "careTeamCell"
let CELLIDENTIFIER_PATIENTLIST = "Cell"
let CELLIDENTIFIER_PATIENTFILTERLIST = "patientFilterListCell"
let CELLIDENTIFIER_DISCHARGE = "dischargeTableCell"
let CELLIDENTIFIER_VITALSIGNS = "VitalSignsTableViewCell"
let CELLIDENTIFIER_ALLPATIENT = "cell"
let CELLIDENTIFIER_PATIENTSEARCHRESULTLIST = "SearchResultsCell"
let CELLIDENTIFIER_ALERTLSIT = "alertListCell"

//MARK: COMMENT CONSTANT
let COMMENT_INVALIDUSERORPASSWORD = "Incorrect username/password"

//MARK: CONTROLLER CONSTANT
let CONTOLLER_DASHBOARD = "DashboardViewController"
let CONTROLLER_PATIENTFILTERLIST = "PatientFilterListNavController"
let CONTOLLER_AUTOSIGNOUT = "AutoSignOutNavController"

//MARK: DATE FORMATTER CONSTANT
let DATEFORMATTER_NOTESWEBSERVICE = "YYYY-MM-dd HH:mm:ss"//2015-06-30 13:08:00
let DATEFORMATTER_NOTESDATA = "MMMM d h:mma"
let DATEFORMATTER_NOTESDATA_ORDINAL = "MMMM d'%@', h:mma"
let DATEFORMATTER_VITALSIGNSLASTTAKEN = "MMMM d, h:mma"
let DATEFORMATTER_WEEKDAY = "EEE"
let DATEFORMATTER_RESPIRATOTYGRAPH = "EEEE MMMM d, h:mma"
let DATEFORMATTER_TARGETDC = "MMMM dd"

//MARK: DEFAULT CONSTANT
let DEFAULT_USERID = "jkoch"
let DEFAULT_PASSWORD = "mobilefirst"
let DEFAULT_TIMEOUT = 300.0 // Default Timeout for auto signout/Session is 5 minute = 300.0 second

let GRAPH_STARTDATE = "2015-05-26 10:19:04"

//MARK: HEADER CONSTANT
let HEADER_DISCHARGEVIEW = "HeaderView"
let CABG_TEXT = "CABG"
let HEADER_ADMITTED_DATE_TEXT = "Admitted "
let HEADER_TRAGET_DATE_TEXT = "Target DC "

//MARK: HEADER KEY CONSTANT
let HEADERKEY_AUTHORIZATION = "Authorization"

//MARK: IMAGE NAME CONSTANT
let IMAGE_CHECKMARK = "hospital-MD-icon-checkmark"
let IMAGE_SIGNOUT = "hospital-MD-icon-sign-out"
let IMAGE_SEARCH = "hospital-MD-icon-search"
let IMAGE_MESSAGE = "hospital-MD-icon-messages"
let IMAGE_HALFTRIANGLE = "halfTriangle"
let IMAGE_HALFTRIANGLEGRAY = "half_triangle_grey"

//MARK: KEY CONSTANT
let KEY_TIMEOUT = "timeOutSecs"
let KEY_TASKNAME = "taskName"
let KEY_NETWORK_CHANGE = "NetworkConnectionChanged"
let PATIENT_TITLE = "title"
let PATIENT_SUBTITLE = "subTitle"
let PATIENT_BEDNUMBER = "patientBedNumber"

//MARK: MESSAGE CONSTANT
let MESSAGE_NETWORKERROR = "Network Error"
let MESSAGE_NOFUNCTIONALITY = "This functionality has not been implemented"
let MESSAGE_NOINTERNETCONNECTION = "You are currently offline. Please connect to a network to perform this action."
let MESSAGE_WRONG = "Something goes wrong."
let MESSAGE_SESSIONTIMEOUT = "You have been signed out due to inactivity. please sign in again."
let MESSAGE_INVALIDUSERORPASSWORD = "Your username or password is incorrect."
let MESSAGE_DOWNLOADERROR = "Your data failed to download. To try again please login."

//MARK: NUMBER CONSTANT
let NUMBER_ZERO = 0
let NUMBER_ONE = 1
let NUMBER_TWO = 2
let NUMBER_THREE = 3
let NUMBER_FOUR = 4
let NUMBER_FIVE = 5
let NUMBER_SIX = 6
let NUMBER_SEVEN = 7
let NUMBER_EIGHT = 8
let NUMBER_NINE = 9

let NUMBER_TEN: CGFloat = 10
let NUMBER_FORTYFOUR: CGFloat = 44.0
let NUMBER_TWOHUNDRED: CGFloat = 200.0

//MARK: SIZE CONSTANT
let SIZE_CELLEXTRA:CGFloat = 61//21+40

//MARK: SPACE CONSTANT
let SPACE_CELL:CGFloat = 30

//MARK: STORYBOARD CONSTANT
let STORYBOARD_CHECKLIST = "checkListStoryBoard"
let STORYBOARD_PATIENTLIST = "patientListStoryBoard"
let STORYBOARD_BLOODPRESSURE = "bloodPressureStoryBoard"
let STORYBOARD_VITALSIGNS = "VitalSigns"
let STORYBOARD_SearchPatientResults = "SearchPatientResults"
let STORYBOARD_ALERTLIST = "AlertList"
let STORYBOARD_ALERTLIST_NAVIGATIONCONTROLLER = "AlertNavigationController"

//MARK: TEXT CONSTANT
let TEXT_NOTESTABLEHEADER = "Notes"
let TEXT_NOTESTABLEFOOTER = "Add new note"
let TEXT_ME = "Me"
let TEXT_ENTERNOTES = "Enter notes text here."
let TEXT_TESTRESULT = "View Test Results"
let TEXT_REVIEWDC = "Review DC Checklist"
let TEXT_REVIEWPLAN = "Review Recovery Plan"
let TEXT_ALLPATIENT = "All Patients"
let TEXT_ROUNDINGPATIENT = "Rounding Patients"
let TEXT_NEWPATIENT = "New Patients"
let TEXT_DCPATIENT = "DC Patients"
let TEXT_VIEWVITALSIGNS = "View Vital Signs"
let TEXT_LASTTAKEN = "Last taken "
let TEXT_VITALSIGNS = "Vital Signs"
let TEXT_BLOODPRESSURE = "Blood Pressure"
let TEXT_ALERTS = "Alerts"
let TEXT_MMHG = "mm Hg"
let TEXT_130 = "130"
let TEXT_90 = "90"

//MARK: TITLE CONSTANT
let TITLE_ATTENTION = "Attention"
let TITLE_OK = "OK"

//MARK: TOKEN CONSTANT
let TOKEN_TOUCHID = "TOUCHID"

//MARK: XIB CONSTANT
let XIB_NOTESCELL = "NotesViewTableViewCell"
let XIB_CARETEAMCELL = "CareTeamTableViewCell"
let XIB_NAVBARTITLEVIEW = "NavigationBarTitleView"
let XIB_ALERTLISTCELL = "AlertListCell"

//MARK: COLOR NAMES AND SIZE
let HELVETICA_MEDIUM = "HelveticaNeue-Medium"
let HELVETICA_MEDIUM_LARGE = "HelveticaNeue-MEDIUM"
let HELVETICA_NEUE_THIN = "HelveticaNeue-Thin"
let HELVETICA_NEUE = "HelveticaNeue"
let HELVETICA_NEUE_BOLD = "HelveticaNeue-BOLD"

let FONT_SIZE_17 : CGFloat = 17.0
let FONT_SIZE_15 : CGFloat = 15.0

//MARK:-
let networkReachability = Reachability.reachabilityForTheInternetConnection()

//MARK:- ACTIVITY INDICATOR
func hideActivityIndicator(_activityIndicatorView: UIActivityIndicatorView)
{
    if(_activityIndicatorView.isAnimating())
    {
        _activityIndicatorView.stopAnimating()
    }
}

func showActivityIndicator(_activityIndicatorView: UIActivityIndicatorView)
{
    if(!_activityIndicatorView.isAnimating())
    {
        _activityIndicatorView.startAnimating()
    }
}

let dashboardViewController = "DashboardViewController"
let PatientFilterListNavController = "PatientFilterListNavController"
let PatientFilterListController = "PatientFilterListViewController"


//MARK:- MISCELLANOUS CONSTANT

var _globalSerivces:[AnyObject] = []

