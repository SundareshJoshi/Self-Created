//
//  OfflineViewController.swift
//  HospitalMD
//
//  Created by Sundaresh Joshi on 5/25/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

// This viewController is not used the updated design, i am keeping this file for the furture use 

import UIKit

//Offline view controller
class OfflineViewController: UIViewController {

    // MARK: - View life cycle method
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
