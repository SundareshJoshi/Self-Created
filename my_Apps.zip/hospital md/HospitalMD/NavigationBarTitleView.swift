//
//  NavigationBarTitleView.swift
//  HospitalMD
//
//  Created by Saurav on 26/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit

//Thic class is used for custom Navigation Bar Title View, where one title followed by reverse triangle image is there/
//Value of title will change depending user current selection of Patient Category type
class NavigationBarTitleView: UIView {

    //MARK: - IBOutlets
    @IBOutlet weak var title: UILabel!

}
