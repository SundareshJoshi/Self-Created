//
//  DischargeCheckListManager.swift
//  HospitalPatient
//
//  Created by kamruddin on 5/20/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit

//To check discharge button should be visible after all discharge task checked
protocol FooterViewDelegate: class {
    func handleSelectedRow(isFooterVisible: Bool)
}

//DischargeCheckListManager handles delgate and datsource of DischargeCheckList
class DischargeCheckListManager: NSObject, UITableViewDataSource, UITableViewDelegate
{
    //MARK: - Variables
    private var checkListData: [DischargeCheckListModal] = []
    private var numberOfSection : Int?
    private var selectedIndexPath: NSIndexPath?
    weak var delegate :FooterViewDelegate?
    var isFooterViewVisible: Bool?
    
    //MARK: - Data Initializers
    func setDischargeCheckList(listData: [DischargeCheckListModal]) {
        
        for remainingTaskData in listData {
            let data = remainingTaskData as DischargeCheckListModal
            self.checkListData.append(data)
        }
    }
    
    //MARK: - UITableViewDataSource
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.checkListData.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        tableView.allowsSelection = false
        var cell: UITableViewCell = UITableViewCell(style: UITableViewCellStyle.Subtitle, reuseIdentifier: CELLIDENTIFIER_DISCHARGE)
        
        var dischargeCheckListModal = self.checkListData[indexPath.row] as DischargeCheckListModal
        
        cell.textLabel!.text = dischargeCheckListModal.taskName
        cell.textLabel?.textColor = UIColor.checkListCellColor()
        cell.textLabel?.font = UIFont.CUSTOM_FONT(HELVETICA_MEDIUM, customFontSize: FONT_SIZE_15)
        cell.textLabel?.numberOfLines = 0
        cell.textLabel?.lineBreakMode = NSLineBreakMode.ByWordWrapping
        
        //Check for selected row
        var selectedItem = self.checkListData[indexPath.row] as DischargeCheckListModal
        if(selectedItem.isSelected == true) {
            cell.textLabel?.textColor = UIColor.lightGrayColor()
            let attributeString =  NSMutableAttributedString(string: (selectedItem.taskName))
            attributeString.addAttribute(NSStrikethroughStyleAttributeName, value: 1, range: NSMakeRange(0, attributeString.length))
            cell.textLabel!.attributedText = attributeString
            
        }
        else{
            
            cell.textLabel?.textColor = UIColor.checkListCellColor()
        }
        return cell
    }
    
    //MARK: - UITableViewDelegate
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        
        var selectedItem = self.checkListData[indexPath.row] as DischargeCheckListModal
        if(selectedItem.isSelected == true) {
            return false
        }
        return true
    }

    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if(editingStyle == UITableViewCellEditingStyle.Delete) {
            
            tableView.editing = true
            // To strike out row on selection
            self.completetdTask(tableView, completedRowAtIndexPath: indexPath)
        }
    }
    
    func tableView(tableView: UITableView, editActionsForRowAtIndexPath indexPath: NSIndexPath) -> [AnyObject]? {
        var completeButton = UITableViewRowAction(style: .Default, title: "Complete", handler: { (action, indexPath) in
            tableView.dataSource?.tableView?(
                tableView,
                commitEditingStyle: .Delete,
                forRowAtIndexPath: indexPath
            )
            
            return
        })
        completeButton.backgroundColor = UIColor.colorCompleteButton()
        
        return [completeButton]
    }
    
    //MARK: - Action for complete button of swiped row
    /**
    Check for showing discharge button and separate the completed task
    
    :param: tableView : Tableview in which the tasks are shown
    :param: indexPath : Indexpath of the selected row in table
    */
    func completetdTask(tableView: UITableView, completedRowAtIndexPath indexPath : NSIndexPath) -> () {
        
        self.selectedIndexPath = indexPath
        tableView.deselectRowAtIndexPath(indexPath, animated: false)
        var selectedItem = self.checkListData[indexPath.row] as DischargeCheckListModal
        selectedItem.isSelected = selectedItem.isSelected == true ? false : true
        self.checkListData[indexPath.row] = selectedItem
        
        for checkListData in self.checkListData
        {
            if(checkListData.isSelected == false)
            {
                self.isFooterViewVisible = false
                break
            }
            else
            {
                self.isFooterViewVisible = true
            }
        }
        
        if self.delegate != nil {
            self.delegate?.handleSelectedRow(self.isFooterViewVisible!)
        }
        
        //* Logic to suuffle rows on selection
        if(selectedItem.isSelected == true) {
            
            self.checkListData.removeAtIndex(indexPath.row)
            self.checkListData.append(selectedItem)
        }
        tableView.reloadData()
    }
    
}

