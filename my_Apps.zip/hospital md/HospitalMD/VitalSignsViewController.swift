//
//  VitalSignsViewController.swift
//  HospitalMD
//
//  Created by Das on 26/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit

// Screen design for Vital sign
class VitalSignsViewController: UIViewController {
    
    // MARK: - IBOutlet
    @IBOutlet weak var tableVitalSigns: UITableView!
    @IBOutlet weak var offlineView: OfflineView!
    @IBOutlet weak var offlineViewHeightConstraint: NSLayoutConstraint!
    
    // MARK: - Variables
    var arrVitalSignsData : [VitalsSignModal] = []
    var mytimer : NSTimer = NSTimer()
    
    // MARK: - View life cycle method
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = TEXT_VITALSIGNS
        // Initialize data to show in table
        arrVitalSignsData = VitalsSignModal.initializeVitalData()
        //Reload table after data initialized
        tableVitalSigns.reloadData()
        
        //To remove separator after visible cell
        tableVitalSigns.tableFooterView = UIView()
        
        // OfflineView Default values
        self.offlineViewHeightConstraint.constant = 0
        self.offlineView.hidden = true
        
        //To check whether the internet connection is there or not
        if networkReachability.isReachable() {
            self.offlineViewHeightConstraint.constant = 0
        }
        else {
            self.animateOfflineView()
        }
        
        //Set notification for checking Network connection
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "notifyNetworkChange:", name: KEY_NETWORK_CHANGE, object: nil)
    }
    
    //MARK:- Private methods
    
    /**
    push to blood pressure controller
    */
    private func showBloodPressureGraphViewController() {
        
        let bloodPressureViewController = self.storyboard!.instantiateViewControllerWithIdentifier(STORYBOARD_BLOODPRESSURE) as! UIViewController
        self.navigationController?.pushViewController(bloodPressureViewController, animated: true)
    }
    
    // MARK: - UITableViewDataSource
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return NUMBER_ONE
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrVitalSignsData.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(CELLIDENTIFIER_VITALSIGNS, forIndexPath: indexPath) as! VitalSignsTableViewCell
        
        if let vitalModalObj = arrVitalSignsData[indexPath.row] as VitalsSignModal!
        {
            cell.lblVitalSignType.text = vitalModalObj.vitalSignType
            cell.lblVitalSignValue.text = vitalModalObj.vitalSignValue
            cell.lblVitalUnit.text = vitalModalObj.vitalUnit
            cell.lblLastTaken.text = TEXT_LASTTAKEN + NSDate.convertToString(fromDate: vitalModalObj.lastTaken, strFormatter: DATEFORMATTER_VITALSIGNSLASTTAKEN)
        }
        
        cell.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
        
        return cell
    }
    
    // MARK: Table view delegate
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        if(indexPath.row == NUMBER_ZERO)
        {
            showBloodPressureGraphViewController()
        }
        else
        {
            if networkReachability.isReachable() {
                var alert = AlertUtils.showErrorWith(message: MESSAGE_NOFUNCTIONALITY)
                self.presentViewController(alert, animated: false, completion: nil)
            }
            else {
                var alert = AlertUtils.showErrorWithoutTitle(message: MESSAGE_NOINTERNETCONNECTION)
                self.presentViewController(alert, animated: false, completion: nil)
            }
        }
    }
    
    //MARK:- Notification method
    /**
    Reachability - Check the network connection
    
    :param: Notification - Notification object for which notification called
    */
    func notifyNetworkChange(Notification: NSNotification) {
        let reachability = Notification.object as! Reachability
        if reachability.isReachable() {
            self.removeOfflineView()
        }
        else {
            self.animateOfflineView()
        }
    }
    
    //MARK:- Show or hide offline view
    /**
    Show the offline view with animation in the controller while user is in offline
    */
    func animateOfflineView() {
        offlineView.hidden = false
        if self.offlineViewHeightConstraint.constant != 30 {
            mytimer = NSTimer .scheduledTimerWithTimeInterval(0.1, target: self, selector: "restart", userInfo: nil, repeats: false)
        }
    }
    
    /**
    Remove the offline view with animation from the controller
    */
    func removeOfflineView() {
        if self.offlineViewHeightConstraint.constant != 0 {
            mytimer = NSTimer .scheduledTimerWithTimeInterval(0.1, target: self, selector: "restartTimer", userInfo: nil, repeats: false)
        }
        else {
            self.offlineView.hidden = true
        }
    }
    
    //MARK:- Timer methods
    
    /**
    Restart the timer while showing offline view
    */
    func restart() {
        UIView.animateWithDuration(0.1, delay: 0.0, options: UIViewAnimationOptions.CurveEaseIn , animations: {  self.offlineViewHeightConstraint.constant += 5}, completion:  {(finished: Bool) in self.animateOfflineView() })
    }
    
    /**
    Restart the timer while hidding offline view
    */
    func restartTimer() {
        UIView.animateWithDuration(0.1, delay: 0.0, options: UIViewAnimationOptions.CurveEaseIn , animations: {  self.offlineViewHeightConstraint.constant -= 5}, completion:  {(finished: Bool) in self.removeOfflineView() })
    }
}
