//
//  VitalSignsTableViewCell.swift
//  HospitalMD
//
//  Created by Das on 26/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit

//To design the table cell for the Vital sign screen
class VitalSignsTableViewCell: UITableViewCell {

    // MARK: - @IBOutlet
    @IBOutlet weak var lblVitalSignType: UILabel!
    @IBOutlet weak var lblVitalSignValue: UILabel!
    @IBOutlet weak var lblVitalUnit: UILabel!
    @IBOutlet weak var lblLastTaken: UILabel!
}
