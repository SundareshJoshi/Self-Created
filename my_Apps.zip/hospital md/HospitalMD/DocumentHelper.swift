//
//  DocumentHelper.swift
//  HospitalMD
//
//  Created by Saurav on 18/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class DocumentHelper {
    struct Static {
        static let APP_STARTED_IN_LOCAL_MODE = "AppStartedInLocalMode"
    }
    
    class func document(name: String, withCompletionHandler callback: ((UIManagedDocument?, String?) -> Void)) {
        let documentUrl = documentUrlForName(name)
        var document = newDocument(documentUrl)
        
        #if DEBUG
            // always create a new document in debug build
            if NSFileManager.defaultManager().fileExistsAtPath(documentUrl.path!) {
            MFLog("deleting previous version of the document \(name) (running in debug mode)")
            deleteFile(documentUrl.path!)
            }
            #else
            let userDefaults = NSUserDefaults.standardUserDefaults()
            if DataSource.isLocal() {
                userDefaults.setValue(true, forKey: Static.APP_STARTED_IN_LOCAL_MODE)
                userDefaults.synchronize()
            } else if userDefaults.boolForKey(Static.APP_STARTED_IN_LOCAL_MODE) {
                userDefaults.setValue(false, forKey: Static.APP_STARTED_IN_LOCAL_MODE)
                userDefaults.synchronize()
                MFLog("deleting previous version of the document \(name) (starting in network mode after local mode)")
                deleteFile(documentUrl.path!)
            }
        #endif
        
        if(NSFileManager.defaultManager().fileExistsAtPath(documentUrl.path!)) {
            MFLog("opening an existing document \(name)")
            openDocument(document) { success in
                if success {
                    callback(document, nil)
                }
                else {
                    MFLog("recovering by recreating the document (all local cache will be lost)")
                    DocumentHelper.deleteFile(documentUrl.path!)
                    document = DocumentHelper.newDocument(documentUrl)
                    DocumentHelper.createDocument(document) { success in
                        if success {
                            callback(document, nil)
                        }
                        else {
                            callback(nil, "cannot create document \(name)")
                        }
                    }
                }
            }
        }
        else {
            MFLog("creating a new document \(name)")
            let folder = documentUrl.URLByDeletingLastPathComponent
            NSFileManager.defaultManager().createDirectoryAtURL(folder!, withIntermediateDirectories: true, attributes: nil, error: nil)
            
            createDocument(document) { success in
                if success {
                    callback(document, nil)
                }
                else {
                    callback(nil, "cannot create document \(name)")
                }
            }
        }
    }
    
    
    private class func documentUrlForName(name: String) -> NSURL {
        let urls = NSFileManager.defaultManager().URLsForDirectory(.ApplicationSupportDirectory, inDomains: .UserDomainMask)
        let appSupport = urls[urls.count-1] as! NSURL
        return appSupport.URLByAppendingPathComponent(name)
    }
    
    
    private class func deleteFile(path: String) {
        NSFileManager.defaultManager().removeItemAtPath(path, error: nil)
    }
    
    
    private class func newDocument(fileURL: NSURL) -> UIManagedDocument{
        let document = UIManagedDocument(fileURL: fileURL)
        
        let options = [
            NSMigratePersistentStoresAutomaticallyOption: true,
            NSInferMappingModelAutomaticallyOption: true
        ]
        document.persistentStoreOptions = options
        
        return document
    }
    
    
    private class func openDocument(document: UIManagedDocument, callback: (Bool) -> Void) {
        document.openWithCompletionHandler() { success in
            if success {
                if document.documentState == .Normal {
                    callback(true)
                }
                else {
                    MFLog("existing document is in a bad state (\(document.documentState.rawValue))")
                    callback(false)
                }
            }
            else {
                MFLog("cannot open document")
                callback(false)
            }
        }
    }
    
    
    private class func createDocument(document: UIManagedDocument, callback: (Bool) -> Void) {
        document.saveToURL(document.fileURL, forSaveOperation: .ForCreating) { success in
            if success {
                if document.documentState == .Normal {
                    callback(true)
                }
                else {
                    MFLog("created document is in a bad state (\(document.documentState.rawValue))")
                    callback(false)
                }
            }
            else {
                MFLog("cannot create document")
                callback(false)
            }
        }
    }
    
}
