//
//  MFLog.swift
//  
//
//  Created by John Alexander on 10/28/14.
//  Copyright (c) 2014 IBM Corporation. All rights reserved.
//

// DBG_LVL controls level of output. default is level 1.
let DBG_LVL:Int = 1
let DBG_INFO:Int = 2
let DBG_WARN:Int = 3
let DBG_ERR:Int = 4
let DBG_VERBOSE:Bool = true

// MFLog
// 
// Usage:
//          MFLog(string)
//          MFLog(string,level)
//          MFError(string)
//
// Output:
//          [debug level] filename : methodname  line: line number     message: message string
//
//          So for example, some log messages set in AppDelegate.swift, in the initData() method might produce the following output:
//
//          [1]AppDelegate.swift:initData() line:24		message:a message
//          [2]AppDelegate.swift:initData() line:25		message:deep message set to level 2
//
//          **********	ERROR IN AppDelegate.swift:initData() LINE:26		ERROR:error message
//
//          [1]ApplicationData.swift:syncSkus(skus:) line:591		message:9 SKUs synced




#if MTL_ENABLE_DEBUG_INFO
     
func MFLog(message: String, level: Int = 1, file: String = __FILE__, method: String = __FUNCTION__, line: Int = __LINE__){
    if(level<=DBG_LVL){
        if(DBG_VERBOSE){
            println("[\(level)]\(file.lastPathComponent):\(method) line:\(line)\t\tmessage:\(message)")
        }
        else {
            println("\(message)")
        }
    }
}

#else

func MFLog(message: String, level: Int = 1, file: String = __FILE__, method: String = __FUNCTION__, line: Int = __LINE__){}
    
#endif


