//
//  UIViewController+Helper.swift
//  ShiftHandover
//
//  Created by David Huo on 2015-02-10.
//  Copyright (c) 2015 IBM. All rights reserved.
//


import UIKit

extension UIImageView {
    func circular () {
        self.layer.cornerRadius = self.bounds.height / 2
        self.layer.borderWidth = 2.0
        self.layer.borderColor = UIColor.clearColor().CGColor
        self.clipsToBounds = true
    }
}

extension UILabel {
    func smartText(tokens:[String]?, width:CGFloat) {
        
    }
}

extension UIFont {
    func bold() -> UIFont {
        let descriptor = self.fontDescriptor().fontDescriptorWithSymbolicTraits(UIFontDescriptorSymbolicTraits.TraitBold)
        return UIFont(descriptor: descriptor!, size: 0)
    }
}

extension UIViewController {
    /*
        Present a controller from storyboard file, using the storyboard name as 
        the default controller id
    */
    func presentViewControllerFromStoryboard(storyboardName:String, controllerId:String? = nil, animated: Bool = false) {
        var theId = storyboardName
        if let cId = controllerId {
            theId = cId
        }
        let sb = UIStoryboard(name: storyboardName, bundle: nil)
        let start: UIViewController = sb.instantiateViewControllerWithIdentifier(theId) as! UIViewController
        presentViewController(start, animated: animated, completion: nil)
    }
    
    /*
        dismiss the current presented controller
     */
    func dismissSelf() {
        self.presentingViewController?.dismissViewControllerAnimated(true, completion: nil)
    }
    
    func flipFromViewController(fromController: UIViewController, toController: UIViewController, options: UIViewAnimationOptions) {
        toController.view.frame = fromController.view.bounds
        self.addChildViewController(toController)
        fromController.willMoveToParentViewController(nil)
        
        self.transitionFromViewController(fromController, toViewController: toController, duration: 0.2, options: options, animations: {}) { (finished) -> Void in
            fromController.removeFromParentViewController()
            toController.didMoveToParentViewController(self)
        }
    }
    
    func waitForBlock(block:(activity:UIActivityIndicatorView)->()) {
        self.view.waitForBlock(block)
    }
}

class BlockingUIIndicatorView: UIActivityIndicatorView {
    deinit {
        var window = UIApplication.sharedApplication().windows[0] as? UIWindow
        window?.userInteractionEnabled = true
    }
    
    override func startAnimating() {
        super.startAnimating()
        var window = UIApplication.sharedApplication().windows[0] as? UIWindow
        window?.userInteractionEnabled = false
    }
    
    override func stopAnimating() {
        super.startAnimating()
        var window = UIApplication.sharedApplication().windows[0] as? UIWindow
        window?.userInteractionEnabled = true
    }
}

extension UIView {
    var tableView : UITableView? {
        var p = self.superview
        while p != nil {
            if p is UITableView {
                return p as? UITableView
            }
            p = p!.superview
        }
        return nil
    }
    
    var tableCell : UITableViewCell? {
        var p = self.superview
        while p != nil {
            if p is UITableViewCell {
                return p as? UITableViewCell
            }
            p = p!.superview
        }
        return nil
    }
    
    var collectionView : UICollectionView? {
        var p = self.superview
        while p != nil {
            if p is UICollectionView {
                return p as? UICollectionView
            }
            p = p!.superview
        }
        return nil
    }
    
    func waitForBlock(block:(activity:UIActivityIndicatorView)->()) {
        var activity = BlockingUIIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.Gray)
        activity.bounds.size = CGSize(width: 20.0, height: 20.0)
        activity.center = self.center
        self.addSubview(activity)
        activity.startAnimating()
       
        block(activity: activity)
    }
}

extension UITableView {
    var firstResponder : UIView? {
        let cells = self.visibleCells()
        for c in cells {
            if let s = searchFirstResponder(c as! UIView) {
                return s
            }
        }
        return nil
    }
    
    func searchFirstResponder(view:UIView)->UIView? {
        if view.isFirstResponder() {
            return view
        }
        for v in view.subviews {
            if let v = searchFirstResponder(v as! UIView) {
                return v
            }
        }
        return nil
    }
}


extension UITableViewCell {
    func fullSeparator() {
        self.separatorInset = UIEdgeInsetsZero
        self.layoutMargins = UIEdgeInsetsZero

    }
}

extension UIBarButtonItem {
    func bold() {
        setTitleTextAttributes([NSFontAttributeName: UIFont.boldSystemFontOfSize(17)], forState: UIControlState.Normal)
    }
}

extension UITableView {
    func emphsize(indexPath:NSIndexPath) {
        let cell = self.cellForRowAtIndexPath(indexPath)
        let animation = CABasicAnimation(keyPath: "borderWidth")
        let layer = cell?.contentView.layer
        layer?.borderColor = UIColor.redColor().CGColor
        animation.fromValue = 6
        animation.toValue = 0
        animation.duration = 0.6
        // animation.repeatCount = 2
        layer?.addAnimation(animation, forKey: "cornerRadius")
    }
}