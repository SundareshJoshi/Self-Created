//
//  DataUtil.swift
//  HospitalMD
//
//  Created by Saurav on 18/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import Foundation

class DataUtil {
    
    class func dataFromFile(file: String) -> NSData? {
        let fileName = file.stringByDeletingPathExtension
        let fileType = file.pathExtension
        
        if let filePath = NSBundle.mainBundle().pathForResource(fileName, ofType: fileType) {
            return NSData(contentsOfFile: filePath)
        }
            
        else  if let data = NSData(contentsOfFile: file){
            return data
        }
        else {
            return nil
        }
    }
    
    
    class func jsonArrayFromFile(fileName: String) -> ([NSDictionary]?, String?){
        let (json: AnyObject?, error) = jsonObjectFromFile(fileName)
        if let e = error {
            return (nil, e)
        }
        if let jsonArray = json as? [NSDictionary] {
            return (jsonArray, nil)
        }
        else {
            return (nil, "JSON error in file: \(fileName): expected array of objects")
        }
    }
    
    
    class func jsonObjectFromFile(fileName: String) -> (AnyObject?, String?){
        if let filePath = NSBundle.mainBundle().pathForResource(fileName, ofType: "json") {
            if let jsonData = NSData(contentsOfFile: filePath) {
                var error: NSError?
                let json: AnyObject? = NSJSONSerialization.JSONObjectWithData(jsonData, options: NSJSONReadingOptions(0), error: &error)
                if(error != nil){
                    return (nil, "JSON parse error: \(error!.localizedDescription) (file: \(filePath))")
                }
                if(json == nil) {
                    return (nil, "JSON parse error (file: \(filePath))")
                }
                return (json, nil)
            }
        }
        return (nil, "cannot find JSON file: \(fileName)")
    }
    
    
    class func dateFromString(string: String) -> NSDate? {
        let df = NSDateFormatter()
        df.timeZone = NSTimeZone(abbreviation: "UTC")
        
        df.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSS'Z'"
        var date: NSDate? = df.dateFromString(string)
        
        if date == nil {
            df.dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'"
            date = df.dateFromString(string)
        }
        
        return date
    }
    
    
    class func processArray<T>(array: [T], processFunc: (T, (String?) -> Void) -> Void, withCompletionHandler completionHandler: ([String]) -> Void) {
        let group = dispatch_group_create()
        //let queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0)
        //let queue = dispatch_queue_create("processArray", DISPATCH_QUEUE_SERIAL)
        //TODO: managed object context is not thread safe, temporary using the main queue
        let queue = dispatch_get_main_queue()
        var errors: [String] = []
        
        for item in array {
            dispatch_group_enter(group)
            dispatch_async(queue) {
                processFunc(item) {
                    error in
                    if let e = error {
                        errors.append(e)
                    }
                    dispatch_group_leave(group)
                }
            }
        }
        
        dispatch_group_notify(group, queue) {
            completionHandler(errors)
        }
    }
    
    
    class func process(range: Range<Int>, processFunc: (Int, () -> Void) -> Void, withCompletionHandler completionHandler: () -> Void) {
        let group = dispatch_group_create()
        //let queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0)
        //let queue = dispatch_queue_create("processArray", DISPATCH_QUEUE_SERIAL)
        //TODO: managed object context is not thread safe, temporary using the main queue
        let queue = dispatch_get_main_queue()
        
        for index in range {
            dispatch_group_enter(group)
            dispatch_async(queue) {
                processFunc(index) {
                    dispatch_group_leave(group)
                }
            }
        }
        
        dispatch_group_notify(group, queue) {
            completionHandler()
        }
    }
}
