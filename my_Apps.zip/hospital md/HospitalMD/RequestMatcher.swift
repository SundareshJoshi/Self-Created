//
//  RequestMatcher.swift
//  StarterApp
//
//  Created by Jeremy Koch on 2/9/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import Foundation
import MFNetworking

class RequestMatcher: RequestMatching {
    func responseForURLRequest(urlRequest: NSURLRequest) ->  MFNetworking.Response {
        // create the 200 response
        var response = MFNetworking.Response()
        
//        // inspect the path to build up the response
//        if urlRequest.URL.path == "/somepath" {
//            
//        }
    
        // return the response
        return response
    }
}