//
//  PatientListViewController.swift
//  HospitalMD
//
//  Created by Raja Pratap Singh on 20/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit
import HealthCareData

//Protocol is used to tell which patient was is currently selected
@objc protocol PatientListDelegate {
    func selectedPatient(patient: Patient2)
}

//This class is used to display collection view and it's cell contains selectable Patient ID, on selecting of patient it's corresponding detail is laoded
class PatientListViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource  {
    
    //MARK: - IBOutlet
    @IBOutlet weak var patientCollectionView: UICollectionView!
    
    //MARK: - Variable
    var selectedCellIndex = NUMBER_ZERO
    var patientListArray : [Patient2] = []
    
    weak var delegate : PatientListDelegate?
    
    //MARK: - ViewLifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.patientCollectionView.backgroundColor = UIColor.colorForPatientCollectionBackground()
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 15)
        layout.scrollDirection = UICollectionViewScrollDirection.Horizontal
        layout.minimumInteritemSpacing = 20
        layout.itemSize = CGSize(width: 80.0, height: 95.0)
        patientCollectionView.collectionViewLayout = layout
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated);
    }
    
    //MARK: - Instance method
    //Get Data for patient from JSON File and load into UI
    func getDataForPatient () {
        
        if let patients = lookupService(ModelService)?.patients {
            for patient in patients {
                patientListArray.append(patient)
            }
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                
                self.patientCollectionView.reloadData()
                if self.delegate != nil {
                    self.delegate?.selectedPatient(self.patientListArray[self.selectedCellIndex])
                }
            })
        }
    }
    
    //MARK: - UICollectionViewDataSource
    
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.patientListArray.count
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        
        let cell: PatientCollectionViewCell = collectionView.dequeueReusableCellWithReuseIdentifier(CELLIDENTIFIER_PATIENTLIST, forIndexPath: indexPath) as! PatientCollectionViewCell
        
        cell.configureCellWithPatientName(self.patientListArray[indexPath.row].lastName, bedNumber: self.patientListArray[indexPath.row].bed.bedNumber, isSelected: indexPath.row == selectedCellIndex)
        
        return cell
    }
    
    //MARK: - UICollectionViewDelegate
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        //If patient is already selected then it will return
        if(selectedCellIndex == indexPath.row){return}
        
        selectedCellIndex = indexPath.row
        if self.delegate != nil {
            self.delegate?.selectedPatient(patientListArray[selectedCellIndex])
        }
        patientCollectionView.reloadData()
    }
}
