//
//  Session.swift
//  HospitalMD
//
//  Created by Saurav on 18/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import Foundation

//Session used to manage login shared instance
class SessionService: NSObject {
    
    // MARK: - Variables
    var isUserLogged = false
    var isAutoSignOutPageDisplayed = false
    
    // MARK: - Class func
    class var sharedInstance : SessionService {
        
        struct SessionServiceStruct {
            static var onceToken : dispatch_once_t = 0
            static var instance : SessionService? = nil
        }
        
        dispatch_once(&SessionServiceStruct.onceToken) {
            SessionServiceStruct.instance = SessionService()
        }
        
        return SessionServiceStruct.instance!
    }
}
