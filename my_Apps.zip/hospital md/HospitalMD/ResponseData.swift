//
//  ResponseData.swift
//  HospitalMD
//
//  Created by Saurav on 18/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import Foundation


let keyStatusCode = "status"
let keyStatusMessage = "message"

class ResponseData {
    
    //feedback data from server
    let responseJson:NSDictionary?
    let responseData:AnyObject?
    
    //network error message
    let error:NSError?
    
    //URLResponse
    let response:NSURLResponse!
    
    
    init(responseJson:NSDictionary?,response:NSURLResponse!,error:NSError?)
    {
        self.responseJson = responseJson
        if let json = responseJson {
            self.responseData = json["data"]
        }
        else {
            self.responseData = nil
        }
        self.error = error
        self.response = response
    }
    
    func errorMessage() -> String? {
        if let er = self.error {
            return self.errorText(er)
        }
        return nil
    }
    
    private func errorText(error: NSError) -> String {
        var text = error.localizedDescription
        if error.domain != "NSURLErrorDomain" {
            return text
        }
        
        switch error.code {
        case NSURLErrorUnknown: text = "Unknown"
        case NSURLErrorCancelled: text = "Cancelled"
        case NSURLErrorBadURL: text = "Bad URL"
        case NSURLErrorTimedOut: text = "Timed Out"
        case NSURLErrorUnsupportedURL: text = "Unsupported URL"
        case NSURLErrorCannotFindHost: text = "Cannot Find Host"
        case NSURLErrorCannotConnectToHost: text = "Cannot Connect To Host"
        case NSURLErrorDataLengthExceedsMaximum: text = "Data Length Exceeds Maximum"
        case NSURLErrorNetworkConnectionLost: text = "Network Connection Lost"
        case NSURLErrorDNSLookupFailed: text = "DNS Lookup Failed"
        case NSURLErrorHTTPTooManyRedirects: text = "HTTP Too Many Redirects"
        case NSURLErrorResourceUnavailable: text = "Resource Unavailable"
        case NSURLErrorNotConnectedToInternet: text = "Not Connected To Internet"
        case NSURLErrorRedirectToNonExistentLocation: text = "Redirect To Non Existent Location"
        case NSURLErrorBadServerResponse: text = "Bad Server Response"
        case NSURLErrorUserCancelledAuthentication: text = "User Cancelled Authentication"
        case NSURLErrorUserAuthenticationRequired: text = "User Authentication Required"
        case NSURLErrorZeroByteResource: text = "Zero Byte Resource"
        case NSURLErrorCannotDecodeRawData: text = "Cannot Decode Raw Data"
        case NSURLErrorCannotDecodeContentData: text = "Cannot Decode Content Data"
        case NSURLErrorCannotParseResponse: text = "Cannot Parse Response"
        case NSURLErrorInternationalRoamingOff: text = "International Roaming Off"
        case NSURLErrorCallIsActive: text = "Call Is Active"
        case NSURLErrorDataNotAllowed: text = "Data Not Allowed"
        case NSURLErrorRequestBodyStreamExhausted: text = "Request Body Stream Exhausted"
        case NSURLErrorFileDoesNotExist: text = "File Does Not Exist"
        case NSURLErrorFileIsDirectory: text = "File Is Directory"
        case NSURLErrorNoPermissionsToReadFile: text = "No Permissions To Read File"
        case NSURLErrorSecureConnectionFailed: text = "Secure Connection Failed"
        case NSURLErrorServerCertificateHasBadDate: text = "Server Certificate Has Bad Date"
        case NSURLErrorServerCertificateUntrusted: text = "Server Certificate Untrusted"
        case NSURLErrorServerCertificateHasUnknownRoot: text = "Server Certificate Has Unknown Root"
        case NSURLErrorServerCertificateNotYetValid: text = "Server Certificate Not Yet Valid"
        case NSURLErrorClientCertificateRejected: text = "Client Certificate Rejected"
        case NSURLErrorClientCertificateRequired: text = "Client Certificate Required"
        case NSURLErrorCannotLoadFromNetwork: text = "Cannot Load From Network"
        case NSURLErrorCannotCreateFile: text = "Cannot Create File"
        case NSURLErrorCannotOpenFile: text = "Cannot Open File"
        case NSURLErrorCannotCloseFile: text = "Cannot Close File"
        case NSURLErrorCannotWriteToFile: text = "Cannot Write To File"
        case NSURLErrorCannotRemoveFile: text = "Cannot Remove File"
        case NSURLErrorCannotMoveFile: text = "Cannot Move File"
        case NSURLErrorDownloadDecodingFailedMidStream: text = "Download Decoding Failed Mid Stream"
        case NSURLErrorDownloadDecodingFailedToComplete: text = "Download Decoding Failed To Complete"
        default: ()
        }
        
        return text
    }
    
}
