//
//  MyApplication.swift
//  CarCare
//
//  Created by Sundaresh Joshi on 5/5/15.
//  Copyright (c) 2015 ibm. All rights reserved.
//

import UIKit
import Foundation

// Timer used for App User event management
class Timer: UIApplication
{
    // MARK: - Variables
    var idleTimer : NSTimer?
    let sharedInstance = SessionService.sharedInstance
    
    // MARK: - Initializers
    override init()
    {
        super.init()
        // reset timer initially
        if !sharedInstance.isUserLogged {
            resetIdleTimer()
        }
    }
    
    // MARK: - UIApplication sendEvent
    override func sendEvent( event: UIEvent )
    {
        super.sendEvent( event )
        
        if let all_touches = event.allTouches() {
            if all_touches.count > NUMBER_ZERO {
                let phase = ((all_touches as NSSet).anyObject() as! UITouch).phase
                if phase == UITouchPhase.Began || phase == UITouchPhase.Ended {
                    resetIdleTimer()
                }
            }
        }
    }

    // MARK: - Private Methods
    private func resetIdleTimer()
    {
        // reset the timer
        if idleTimer != nil {
            idleTimer?.invalidate()
        }
        var idleSecs = AppSettings.sharedInstance.getSessionTimeOutInSeconds()
        idleTimer = NSTimer.scheduledTimerWithTimeInterval(idleSecs, target: self, selector: "idleTimerExceeded", userInfo: nil, repeats: true)
    }
    
    func idleTimerExceeded()
    {
        // Present Auto SignOut Screen
        let rootViewController = UIApplication.sharedApplication().keyWindow?.rootViewController
        
        // Auto SignOut screen will be displayed only when the user is not at the login screen
        if !sharedInstance.isAutoSignOutPageDisplayed && sharedInstance.isUserLogged {
            let navCntrl: UINavigationController = UIStoryboard.autoSignOutStoryboard().instantiateViewControllerWithIdentifier(CONTOLLER_AUTOSIGNOUT) as! UINavigationController
            
            rootViewController?.presentViewController(navCntrl, animated: true, completion: nil)
            sharedInstance.isAutoSignOutPageDisplayed = true
        }

        resetIdleTimer()
    }
}
