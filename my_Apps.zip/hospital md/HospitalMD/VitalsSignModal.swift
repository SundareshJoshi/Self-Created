//
//  VitalsSignModal.swift
//  HospitalMD
//
//  Created by Das on 27/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit

//Vital modal class for showing in Vital Signs
class VitalsSignModal: NSObject {
    
    @IBOutlet weak var lblVitalSignType: UILabel!
    @IBOutlet weak var lblVitalSignValue: UILabel!
    @IBOutlet weak var lblVitalUnit: UILabel!
    @IBOutlet weak var lblLastTaken: UILabel!
    
    //MARK:- Variables
    var vitalSignType = ""
    var vitalSignValue = ""
    var vitalUnit = ""
    var lastTaken : NSDate?
    
    //Initialization Method
    override init() {
        self.vitalSignType = ""
        self.vitalSignValue = ""
        self.vitalUnit = ""
        self.lastTaken = nil
    }
    
    /**
    Initialization Method
    
    :param: type - vital sign type
    :param: value - vital sign value
    :param: unit - vital sign unit of the value
    :param: date - Last taken date
    */
    convenience init(type: String, value: String, unit:String, date:NSDate?) {
        self.init()
        self.vitalSignType = type
        self.vitalSignValue = value
        self.vitalUnit = unit
        self.lastTaken = date
    }
    
    //TODO: This method will be removed when data will come from json or database
    /**
    This method is to initialize static data in the table view
    
    :returns: array of VitalsSignModal object
    */
    class func initializeVitalData()->[VitalsSignModal]
    {
        var arrVitalSignsData : [VitalsSignModal] = []
        
        let bloodPressure = VitalsSignModal(type: "BLOOD PRESSURE", value: "130/90", unit: "mm Hg", date: NSDate())
        arrVitalSignsData.append(bloodPressure)
        
        let bodyTemp = VitalsSignModal(type: "BODY TEMPERATURE", value: "38°", unit: "C", date: NSDate())
        arrVitalSignsData.append(bodyTemp)
        
        let heartRate = VitalsSignModal(type: "HEART RATE", value: "120", unit: "BPM", date: NSDate())
        arrVitalSignsData.append(heartRate)
        
        let respiratoryRate = VitalsSignModal(type: "RESPIRATORY RATE", value: "15", unit: "breaths/minute", date: NSDate())
        arrVitalSignsData.append(respiratoryRate)
        
        return arrVitalSignsData
    }
}
