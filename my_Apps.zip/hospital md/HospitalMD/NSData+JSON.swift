//
//  NSData+JSON.swift
//  ShiftHandover
//
//  Created by David Huo on 2015-02-23.
//  Copyright (c) 2015 IBM. All rights reserved.
//



extension NSData {

    func json()->NSMutableDictionary {
        
        var error: NSError?
        var d: NSDictionary = NSJSONSerialization.JSONObjectWithData(self, options: NSJSONReadingOptions.MutableContainers, error: &error) as! NSDictionary
        
        return d as! NSMutableDictionary
    }
}