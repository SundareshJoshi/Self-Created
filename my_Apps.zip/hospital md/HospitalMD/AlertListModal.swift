//
//  AlertListModal.swift
//  HospitalMD
//
//  Created by kamruddin on 5/28/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit
import MFNetworking

//Modal class for Alert
class AlertListModal: NSObject {
    
    //MARK: - Variables
    var title = ""
    var subTitle = ""
    var patientBedNumber = ""
    
    //MARK: - Initialize modal data from JSON
    init(json: JSON) {
        self.title = json[PATIENT_TITLE].stringValue
        self.subTitle = json[PATIENT_SUBTITLE].stringValue
        self.patientBedNumber = json[PATIENT_BEDNUMBER].stringValue
    }
}
