//
//  SearchPatientViewController.swift
//  HospitalMD
//
//  Created by Raja Pratap Singh on 26/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit
import MFNetworking
import HealthCareData

//For search patient screen
class SearchPatientViewController: UITableViewController {
    
    //MARK: - IBOutlet
    @IBOutlet var patientSearchResultTableView: UITableView!
    
    //MARK: - Variables
    var allResults: [Patient2] = []
    lazy var visibleResults: [Patient2] = []
    var patientAlertList: [Alert2] = []
    var textSearchBar = ""
    
    // MARK: - View LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.backgroundColor = UIColor.colorForEmptySearchScreen()
        //To remove separator after visible cell
        tableView.tableFooterView = UIView()
    }
    
    override func viewWillAppear(animated: Bool) {
        
        self.getArrayForAllResults()
    }
    
    // MARK: - instance Menthod
    func getArrayForAllResults () {
        
        if let patients = lookupService(ModelService)?.patients {
            self.allResults = patients
            for patient in patients {
                var alertList = patient.alerts.allObjects as! [Alert2]
                let firstAlert = alertList[0] as Alert2
                self.patientAlertList.append(firstAlert)
            }
        }
        
        visibleResults = self.allResults
    }
    
    /// A `nil` / empty filter string means show all results. Otherwise, show only results containing the filter.
    var filterString: String? = nil {
        didSet {
            if filterString == nil || filterString!.isEmpty {
                visibleResults = allResults
            }
            else {
                // Filter the results using a predicate based on the filter string.
                let filterFirstNamePredicate = NSPredicate(format: "firstName like[cd] %@", argumentArray: [filterString!])
                let filterPatientNumberPredicate = NSPredicate(format: "bed.bedNumber like[cd] %@", argumentArray: [filterString!])
                let filterLastNamePredicate = NSPredicate(format: "lastName like[cd] %@", argumentArray: [filterString!])
                let compoundPredicate = NSCompoundPredicate.orPredicateWithSubpredicates([filterFirstNamePredicate, filterPatientNumberPredicate, filterLastNamePredicate])
                visibleResults = allResults.filter { compoundPredicate.evaluateWithObject($0) }
            }
            textSearchBar = filterString!
            tableView.reloadData()
        }
    }
    
    // MARK: - UITableViewDataSource
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return visibleResults.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell: PatientCell = tableView.dequeueReusableCellWithIdentifier(CELLIDENTIFIER_PATIENTSEARCHRESULTLIST, forIndexPath: indexPath) as! PatientCell
        
        cell.configurePatientCellWithPatientNameAndNumber((visibleResults[indexPath.row].firstName + " " + visibleResults[indexPath.row].lastName), patientId: visibleResults[indexPath.row].bed.bedNumber, patientCondition:patientAlertList[indexPath.row].longDesc, searchText:textSearchBar)
        
        return cell
    }
}
