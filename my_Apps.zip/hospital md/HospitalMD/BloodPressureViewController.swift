//
//  BloodPressureViewController.swift
//  HospitalMD
//
//  Created by Saurav on 26/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit

//To show blood pressure data in graphical format
class BloodPressureViewController: UIViewController {
    
    // MARK: - @IBOutlet
    @IBOutlet weak var segmentControlGraph: UISegmentedControl!
    // MARK: - View life cycle method
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = TEXT_BLOODPRESSURE
        // Do any additional setup after loading the view.
        
        segmentControlGraph.tintColor = UIColor.NAVIGATION_BAR_COLOR()
        var attr = NSDictionary(object: UIFont.HELVETICANEUE_MEDIUM(15), forKey: NSFontAttributeName)
        UISegmentedControl.appearance().setTitleTextAttributes(attr as [NSObject : AnyObject], forState: .Normal)
    }
    
    // MARK: - Segment control action method
    @IBAction func segmentControlGraphOnclick(sender: UISegmentedControl) {
        
        if(sender.selectedSegmentIndex == 0)
        {
            if networkReachability.isReachable() {
                self.presentViewController(AlertUtils.showErrorWith(message: MESSAGE_NOFUNCTIONALITY), animated: true, completion: nil)
            }
            else {
                self.presentViewController(AlertUtils.showErrorWithoutTitle(message: MESSAGE_NOINTERNETCONNECTION), animated: true, completion: nil)
            }
        }
        
    }
}
