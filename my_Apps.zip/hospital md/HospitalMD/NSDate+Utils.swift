//
//  NSDate+Utils.swift
//  HospitalMD
//
//  Created by Das on 19/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import Foundation
import UIKit

//Handle all the type of Date and its formatter
extension NSDate{
    
    /**
    Converts date a String to Date
    
    :param: fromString :  The string that needs to be changed to Date
    :param: strFormatter : The desired tyoe of Formatter is sent here if not it automatically assigns to "YYYY-MM-dd HH:mm:ss"
    :returns: Converted NSDate is returned
    */
    
    class func convertToDate (#fromString : String?, strFormatter : String?) -> NSDate?
    {
        var dateFormatter : NSDateFormatter? = NSDateFormatter()
        // Check if strFormatter is nil then assign it to default type
        if !(strFormatter != nil)
        {
            strFormatter == DATEFORMATTER_NOTESWEBSERVICE
        }
        dateFormatter?.dateFormat = strFormatter
        if fromString != nil && NSString(string: fromString!).length > 0
        {
            return dateFormatter!.dateFromString(fromString!)
        }
        else
        {
            return nil
        }
    }
    /**
    Converts date a Date to String
    
    :param: fromDate :  The Date that needs to be changed to String
    :param: strFormatter : The desired tyoe of Formatter is sent here if not it automatically assigns to "MMMM d h:mma"
    :returns: Converted String is returned
    */
    
    class func convertToString (#fromDate : NSDate?, strFormatter : String?) -> String
    {
        var dateFormatter : NSDateFormatter? = NSDateFormatter()
        
        // Check if strFormatter is nil then assign it to default type
        if !(strFormatter != nil) {
            strFormatter == DATEFORMATTER_NOTESDATA
        }
        dateFormatter?.dateFormat = strFormatter
        
        if fromDate != nil {
            return dateFormatter!.stringFromDate(fromDate!)
        }
        else {
            return ""
        }
    }
    /**
    Converts a Date to String with Ordinal format
    
    :param: fromDate :  The Date that needs to be changed to String
    :param: strFormatter : The desired tyoe of Formatter is sent here if not it automatically assigns to "MMMM d h:mma"
    :returns: Converted String is returned
    */
    
    class func convertToStringWithOrdinalFormat (#fromDate : NSDate?, strFormatter : String?) -> String
    {
        var dateFormatter : NSDateFormatter? = NSDateFormatter()
        dateFormatter?.formatterBehavior = NSDateFormatterBehavior.Behavior10_4
        
        // Check if strFormatter is nil then assign it to default type
        if !(strFormatter != nil)
        {
            strFormatter == DATEFORMATTER_NOTESDATA_ORDINAL
        }
        
        let newFormat  = NSString (format: strFormatter!, self.daySuffix(fromDate!))
        dateFormatter?.dateFormat = newFormat as String
        
        if fromDate != nil
        {
            return dateFormatter!.stringFromDate(fromDate!)
        }
        else
        {
            return ""
        }
    }

    /**
    To get the ordinal format of the day
    
    :param: date :  The Date for which the ordinal format required
    :returns: Converted ordinal format is returned
    */
    class func daySuffix(date: NSDate) -> String {
        let calendar = NSCalendar.currentCalendar()
        let dayOfMonth = calendar.component(.CalendarUnitDay, fromDate: date)
        switch dayOfMonth {
        case 1: fallthrough
        case 21: fallthrough
        case 31: return "st"
        case 2: fallthrough
        case 22: return "nd"
        case 3: fallthrough
        case 23: return "rd"
        default: return "th"
        }
    }
}