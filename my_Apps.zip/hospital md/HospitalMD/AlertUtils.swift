//
//  AlertUtils.swift
//  HospitalMD
//
//  Created by Saurav on 18/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import Foundation

import Foundation
import UIKit

//To handle all types of alert message
class AlertUtils {
    
    //MARK: - Alert
    class func showErrorWith(#message: String)-> UIAlertController {
        
        let alertController = UIAlertController(title: TITLE_ATTENTION, message: message, preferredStyle:.Alert)
        let okButton = UIAlertAction(title: TITLE_OK, style: .Default, handler: nil)
        alertController.addAction(okButton)
        
        return alertController
    }
    
    //MARK: - Alert with no title
    class func showErrorWithoutTitle(#message: String)-> UIAlertController {
        let alertController = UIAlertController(title: "", message: message, preferredStyle:.Alert)
        let okButton = UIAlertAction(title: TITLE_OK, style: .Default, handler: nil)
        alertController.addAction(okButton)
        
        return alertController
    }
}