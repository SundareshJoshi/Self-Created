//
//  User.swift
//  ShiftHandover
//
//  Created by John Martino on 2015-04-07.
//  Copyright (c) 2015 IBM. All rights reserved.
//

//
//  This class is used to access the currently logged in user.
//  Setting any of its properties will persist the object data.
//
//  authenticationToken: the token from the last successful server login.
//

import Foundation
import MFNetworking

private let instanceMutex = NSLock()

class User {
    private let userID = "CurrentUser"
    private let kAuthenticationTokenKey = "AuthenticationToken"
    private let kUserNameKey = "UserName"
    private let kSessionKey = "session"
    private let kIdleTimeStampKey = "idleTimeStamp"
    
    var userInMidShift: Bool = false { didSet { self.save() } }
    var downloadComplete: Bool = false { didSet { self.save() } }
    var authenticationToken: String? { didSet { self.save() } }
    var username: String? { didSet { self.save() } }
    var session: Session? { didSet { self.save() } }
    var idleTimeStamp: NSDate? { didSet { self.save() } }
    
    private struct Instance {
        static var instance: User?
    }
    
    class func currentUser() -> User {
        instanceMutex.lock()
        if Instance.instance == nil {
            Instance.instance = User()
        }
        instanceMutex.unlock()
        return Instance.instance!
    }
    
    private init() {
        load()
    }

    private func load() {
        if let userDictionary = lookupService(IJSONPersistence)?.read(Stores.User, objectId: userID) as? [String : AnyObject] {
            authenticationToken = userDictionary[kAuthenticationTokenKey] as? String
            username = userDictionary[kUserNameKey] as? String
            
            if let sessionValue = userDictionary[kSessionKey] as? NSMutableDictionary {
                session = Session(json: sessionValue)
            }
            
            idleTimeStamp = userDictionary[kIdleTimeStampKey] as? NSDate
        }
    }
    
    func save() {
        var userDictionary = NSMutableDictionary()
        if let authenticationTokenValue = authenticationToken {
            userDictionary[kAuthenticationTokenKey] = authenticationTokenValue
        }
        if let usernameValue = username {
            userDictionary[kUserNameKey] = usernameValue
        }
        if let sessionValue = session?.json {
            userDictionary[kSessionKey] = sessionValue
        }
        if let timeStamp = idleTimeStamp {
            userDictionary[kIdleTimeStampKey] = timeStamp
        }
        lookupService(IJSONPersistence)?.write(Stores.User, json: userDictionary, withObjectId: userID)
    }
    
    func reset() {
        // Warning: this should only be called when the IJSONPersistence data has been reset()
        instanceMutex.lock()
        Instance.instance = nil
        instanceMutex.unlock()
    }
}
