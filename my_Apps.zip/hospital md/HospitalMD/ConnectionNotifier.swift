//
//  ConnectionNotifier.swift
//  HospitalMD
//
//  Created by Sundaresh Joshi on 5/26/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import Foundation

//Session used to manage login shared instance
class ConnectionNotifier: NSObject {
    var startNotify : Bool = false
    
    // MARK: - Class func
    class var Notify : ConnectionNotifier {
        
        struct NotifyService {
            static var onceToken : dispatch_once_t = 0
            static var instance : ConnectionNotifier? = nil
        }
        
        dispatch_once(&NotifyService.onceToken) {
            NotifyService.instance = ConnectionNotifier()
        }
        
        return NotifyService.instance!
    }

    func startReachability() {
        
        let reachability = Reachability.reachabilityForTheInternetConnection()
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "reachabilityChanged:", name: ReachabilityChangedNotification, object: reachability)
        
        reachability.startNotifier()
    }
    
    // This is called once their is a change in networkConnection
    func reachabilityChanged(note: NSNotification) {
        
        NSNotificationCenter.defaultCenter().postNotificationName(KEY_NETWORK_CHANGE, object: note.object as! Reachability)
    }
}

