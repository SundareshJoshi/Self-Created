//
//  DischargeCheckListManager.swift
//  HospitalPatient
//
//  Created by kamruddin on 5/20/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit
import HealthCareData

protocol CareTeamInfoDelegate: class {
    func careTeamInfo()
}

//HeaderView: This view is used for displaying patient detail and reused in Patient DC List scrreen and CareTeam Screen
class HeaderView: UIView {
    
    //MARK: - IBOutlets
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var dischargeDetail: UILabel!
    @IBOutlet weak var CABG: UILabel!
    
    //MARK: - Variables
    weak var delegate :CareTeamInfoDelegate?
    
    //MARK: - Care Team Info method
    @IBAction func careTeamInfo(sender: AnyObject) {
        if self.delegate != nil {
            self.delegate?.careTeamInfo()
        }
    }
    
    //MARK: - update header detail
    func  updateHeaderDetail(patientDetail: Patient2) {
        
        self.name.text = patientDetail.firstName + " " + patientDetail.lastName
        
        self.dischargeDetail.text = HEADER_TRAGET_DATE_TEXT + NSDate.convertToString(fromDate: patientDetail.recoveryPath.dischargeDate, strFormatter: DATEFORMATTER_TARGETDC)
        self.CABG.text = CABG_TEXT
    }
}
