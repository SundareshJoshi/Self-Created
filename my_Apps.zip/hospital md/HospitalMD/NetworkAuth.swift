//
//  NetworkAuth.swift
//  HospitalMD
//
//  Created by Saurav on 18/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import Foundation

let passwordString:String = "MobileFirstForiOS"
let authFileName:String = "clientcert"
let authFileType:String = "pfx"

class NetworkAuth:NSObject,NSURLSessionDelegate{
    
    
    private var certificateFilePath:NSString!
    private var password:NSString!
    private var credentialData:NSURLCredential!
    
    class var sharedInstance : NetworkAuth {
        struct Static {
            static let instance : NetworkAuth = NetworkAuth()
        }
        return Static.instance
    }
    
    private override init() {
        super.init()
        //defualt certificate
        var path = NSBundle.mainBundle().pathForResource(authFileName, ofType:authFileType)
        self.updateAuthInfo(path, password: passwordString)
    }
    
    
    func updateAuthInfo(certificateFilePath:NSString!,password:NSString!){
        self.certificateFilePath = certificateFilePath
        self.password = password
    }
    
    func setUp(){
        
        self.credential(self.certificateFilePath, password: self.password)
        
    }
    
    
    func credential(path:NSString,password:NSString)->NSURLCredential?{
        if self.credentialData == nil{
            
            var clientcertData: NSData = NSData(contentsOfFile: path as String, options: nil, error: nil)!
            
            // Import .clientcert data
            var keyref: Unmanaged<CFArray>?
            
            var optionDict: NSMutableDictionary = NSMutableDictionary()
            optionDict.setValue(password, forKey: kSecImportExportPassphrase!.takeRetainedValue() as String)
            
            var sanityChesk = SecPKCS12Import(clientcertData,optionDict,&keyref)
            if sanityChesk != noErr{
                MFLog("Error while importing  \(sanityChesk)", level: 1)
                return nil
            } else {
                MFLog("Success opening p12 certificate.", level: 1)
            }
            
            if keyref == nil {
                
                MFLog("Error keyref == nil", level: 1)
                return nil
            }
            
            // Identity
            var key = keyref!
            var arr:NSArray = key.takeUnretainedValue()
            var ide:NSDictionary = arr[0] as! NSDictionary
            var identityDict = ide
            var identityRef:SecIdentity! = identityDict["identity"] as! SecIdentity
            
            
            // Cert
            var cert: Unmanaged<SecCertificateRef>? =  nil
            var status: OSStatus  = SecIdentityCopyCertificate(identityRef, &cert)
            if status != noErr{
                MFLog("Error SecIdentityCopyCertificate failed")
                return nil
            }
            
            var certs = NSMutableArray()
            certs.addObject(cert!.takeUnretainedValue())
            
            self.credentialData = NSURLCredential(identity: identityRef, certificates: certs as [AnyObject], persistence: NSURLCredentialPersistence.None)
        }
        return self.credentialData
    }
    
    
    func URLSession(session: NSURLSession, didReceiveChallenge challenge: NSURLAuthenticationChallenge, completionHandler: (NSURLSessionAuthChallengeDisposition, NSURLCredential!) -> Void){
        
        var credential:NSURLCredential?
        if challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust
        {
            credential = NSURLCredential(forTrust:challenge.protectionSpace.serverTrust)
        }
        else if challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodClientCertificate
        {
            MFLog("challenge")
            credential = self.credential(self.certificateFilePath, password: self.password)
        }
        
        if (credential != nil)
        {
            completionHandler(NSURLSessionAuthChallengeDisposition.UseCredential,credential)
        }
        else
        {
            completionHandler(NSURLSessionAuthChallengeDisposition.UseCredential,nil)
            
        }
    }
}