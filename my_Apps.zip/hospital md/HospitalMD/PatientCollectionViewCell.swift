//
//  PatientCollectionViewCell.swift
//  HospitalMD
//
//  Created by Raja Pratap Singh on 20/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit

//This class is derived from UICollectionViewCell and is used to display patient detail in Patient List StoryBoard
class PatientCollectionViewCell: UICollectionViewCell {
    //MARK: - IBOutlet
    @IBOutlet weak var patientNumberLabel: UILabel!
    @IBOutlet weak var patientNumberBackGroundLabel: UILabel!
    @IBOutlet weak var patientNameLabel: UILabel!
    @IBOutlet weak var arrowImageView: UIImageView!

    //MARK: - Configure colection view Cell
    func configureCellWithPatientName(name: String, bedNumber: String, isSelected: Bool) {
    
        self.backgroundColor = UIColor.colorForPatientCollectionBackground()

        self.patientNumberLabel.text = bedNumber
        self.patientNumberLabel.textColor = isSelected ? UIColor.colorForPatientCollectionBackground() : UIColor.colorForSelectedPatientInCollection()
        self.patientNumberLabel.backgroundColor =  isSelected ? UIColor.colorForSelectedPatientInCollection() : UIColor.colorForPatientCollectionBackground()
        self.patientNumberLabel.layer.cornerRadius = self.patientNumberLabel.frame.size.width / 2
        self.patientNumberLabel.layer.masksToBounds = true

        self.patientNumberBackGroundLabel.backgroundColor =  UIColor.colorForSelectedPatientInCollection()
        self.patientNumberBackGroundLabel.layer.cornerRadius = self.patientNumberBackGroundLabel.frame.size.width / 2
        self.patientNumberBackGroundLabel.layer.masksToBounds = true
        
        self.patientNameLabel.text = name
        self.patientNameLabel.textColor = UIColor.colorForSelectedPatientInCollection()
        self.arrowImageView.hidden = !isSelected
        if networkReachability.isReachable() {
            self.arrowImageView.image = UIImage(named: IMAGE_HALFTRIANGLE)
        }
        else {
            self.arrowImageView.image = UIImage(named: IMAGE_HALFTRIANGLEGRAY)
        }
    }
}
