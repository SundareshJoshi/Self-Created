//
//  Global.swift
//  HospitalMD
//
//  Created by G Thomas on 5/17/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

let networkReachability = Reachability.reachabilityForInternetConnection()

//MARK: AlertUtils
let messageTitle = "Error"
let okButtonTitle = "OK"
let networkErrorMessage = "Network Error"

//MARK:- AuthenticationController
let errorMessageForInvalidUsernamePassword = "Your username or password is incorrect."
let commentForInvalidUsernamePasswoed = "Incorrect username/password"
let defaultUserID = "jkoch"
let defaultPassword = "mobilefirst"
let authorizationTokenHeaderKey = "Authorization"
let mainStoryBoard = "UIMainStoryboardFile"
let touchIdAuthorizationToken = "TOUCHID"
<<<<<<< HEAD
=======

//MARK: SessionManager Constants
let timeOutKey = "timeOutSecs"
let sessionTimeOutMessage = "You have been signed out due to inactivity, please sign in again"

// MARK: - UIStoryBoard Identifier

let autoSignOutNavController = "AutoSignOutNavController"
>>>>>>> task-9779-SessionHandling
