//
//  Patient.swift
//  HospitalMD
//
//  Created by Raja Pratap Singh on 21/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import Foundation
import MFNetworking

//Modal Class for Patient
class Patient: NSObject {
    
    //MARK: - Variable
    var patientId: String
    var firstName: String
    var lastName: String
    var gender: String
    var birthdate: String
    var physicianName: String
    var status: String
    var ambulatoryStatus: String
    var acuity: String
    var admittedDate: String
    var targetDate: String
    var patientCondition: String
    var careTeamStaffIds = [String]()
    
    //MARK: Static Variable
    static var patientFilterArrayofPatientList : [NSArray] = []
    static let patientTypeFilterArray = ["All Patients", "Rounding Patients", "New Patients",  "DC Patients"]
    static var selectedFilterIndex = -1
    
    //MARK: - Initialize modal data
    override init() {
        self.patientId = ""
        self.firstName = ""
        self.lastName = ""
        self.gender = ""
        self.birthdate = ""
        self.physicianName = ""
        self.status = ""
        self.ambulatoryStatus = ""
        self.acuity = ""
        self.admittedDate = ""
        self.targetDate = ""
        self.patientCondition = ""
    }
    
    init(json: JSON) {
        
        self.patientId = json["patientId"].stringValue
        self.firstName = json["firstName"].stringValue
        self.lastName = json["lastName"].stringValue
        self.gender = json["gender"].stringValue
        self.birthdate = json["birthdate"].stringValue
        self.physicianName = json["physicianName"].stringValue
        self.status = json["status"].stringValue
        self.ambulatoryStatus = json["ambulatoryStatus"].stringValue
        self.acuity = json["acuity"].stringValue
        self.admittedDate = json["admittedDate"].stringValue
        self.targetDate = json["targetDate"].stringValue
        self.patientCondition = json["patientCondition"].stringValue
        var staffIds = json["careTeamStaffIds"].arrayValue
        
        for id in staffIds {
            self.careTeamStaffIds.append(id.stringValue)
        }
    }
    
    //MARK: - Class Func Filter
    /**
    Filtering the Patients on the basis of the status category(New/Rounding/Discharge)
    
    :param: patientArray - Array of all patients for filtering
    */
    class func applyFilter(patientArray: [Patient]) {
        
        var allPatientArray : [Patient] = []
        var roundingPatientArray : [Patient] = []
        var newPatientArray : [Patient] = []
        var dcPatientArray : [Patient] = []
        
        for patientObj in patientArray {
            allPatientArray.append(patientObj)
            
            if patientObj.status == "N" {
                newPatientArray.append(patientObj)
            }
            else if patientObj.status == "R" {
                roundingPatientArray.append(patientObj)
            }
            else if patientObj.status == "DC" {
                dcPatientArray.append(patientObj)
            }
        }
        
        self.patientFilterArrayofPatientList.append(allPatientArray)
        self.patientFilterArrayofPatientList.append(roundingPatientArray)
        self.patientFilterArrayofPatientList.append(newPatientArray)
        self.patientFilterArrayofPatientList.append(dcPatientArray)
    }
}
