//
//  AlertModal.swift
//  HospitalMD
//
//  Created by Das on 22/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import Foundation
import MFNetworking

// Modal class for Alert

class AlertModal: Printable {
    
    //MARK:- Variables
    var alertText = ""
    var alertType = ""
    
    //MARK:- Initialization Method
    init(text: String, type: String) {
        
        self.alertText = text
        self.alertType = type
    }
    
    //MARK: - Initialize modal data
    init(json: JSON) {
        self.alertText = json["alertText"].stringValue
        self.alertType = json["alertType"].stringValue
    }
    
    var description: String {
        return "Alert data description"
    }
}