//
//  DashBoardViewController.swift
//  HospitalMD
//
//  Created by Saurav on 20/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit

//This class is used to dispaly Patient detail like it's care team member, DC Date, Alerts and Notes
class DashBoardViewController: UIViewController, UITableViewDataSource, UIScrollViewDelegate, UITextFieldDelegate, ContactStaffDelegate, PatientFilterDelegate, PatientListDelegate, CareTeamInfoDelegate {
    
    // MARK:- Variables
    var badgeView: UIView?
    var badgeLabel: UILabel?
    var selectedPatient: Patient?
    var notesDatas: [NotesModal] = []
    var alertDatas: [AlertModal] = []
    var previousScrollViewYOffset :CGFloat = 0.0
    var patientController: PatientListViewController?
    var dischargeController: DischargeCheckListViewController?
    var textFldTemp :UITextField?// To get reference of the current textfield in viewcontroller
    var mytimer : NSTimer = NSTimer()

    // MARK:- Outlets
    @IBOutlet weak var slidingView: UIView!
    @IBOutlet weak var slidingTableView: UITableView!
    @IBOutlet weak var dashBoardFooterView: UIView!
    @IBOutlet weak var footerViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var offlineView: OfflineView!
    @IBOutlet weak var offlineViewHeightConstraint: NSLayoutConstraint!
    
    
    @IBOutlet weak var navigationBarTitleView: UIView! {
        didSet {
            let nib:NSArray = NSBundle.mainBundle().loadNibNamed(XIB_NAVBARTITLEVIEW, owner: self, options: nil)
            var navigationBarTitleView = nib.objectAtIndex(0) as? NavigationBarTitleView
            let titleLabelTapGesture = UITapGestureRecognizer(target: self, action:"titleLabelTapped:")
            self.navigationBarTitleView.addGestureRecognizer(titleLabelTapGesture)
            self.navigationBarTitleView!.addSubview(navigationBarTitleView!)
        }
    }
    // MARK:- Controller life cycle methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.title = "Patient"
        self.navigationController!.navigationBar.tintColor = UIColor.NAVIGATION_TITLE_COLOR()
        self.offlineViewHeightConstraint.constant = 0
        self.offlineView.hidden = true

        configureNavigationBar()

        for childController in self.childViewControllers {
            if(childController.isKindOfClass(PatientListViewController)) {
                patientController = childController as? PatientListViewController
                patientController?.delegate = self
            }
        }
    
        //To check whether the internet connection is there or not
        if networkReachability.isReachable() {
            self.offlineViewHeightConstraint.constant = 0
        }
        else {
            self.animateOfflineView()
        }
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "notifyNetworkChange:", name: KEY_NETWORK_CHANGE, object: nil)
        

        
        //To adjust the scroll insets according to view
        self.automaticallyAdjustsScrollViewInsets = false
        
        //Tap Gesture is added to the table view to resign keyboard while tapping on table when keyboard is shown.
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: "dismissKeyboard")
        tapGestureRecognizer.cancelsTouchesInView = false
        self.slidingTableView.addGestureRecognizer(tapGestureRecognizer)

        //To register the cell from xib
        self.slidingTableView.registerNib(UINib(nibName: XIB_CARETEAMCELL, bundle: nil), forCellReuseIdentifier: CELLIDENTIFIER_CARETEAM)
        self.slidingTableView.registerNib(UINib(nibName: XIB_NOTESCELL, bundle: nil),forCellReuseIdentifier: CELLIDENTIFIER_NOTES)
        self.slidingTableView.registerNib(UINib(nibName: CELLIDENTIFIER_NOTESTITLE, bundle: nil),forCellReuseIdentifier: CELLIDENTIFIER_NOTESTITLE)
        
        getDataForPatientAtIndex(NUMBER_ZERO)
        
        //To load data from json file
        notesDataService()
        alertsDataService()
    }
    
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
        self.badgeView?.hidden = false
        self.badgeLabel?.hidden = false
        if(self.dischargeController != nil && (self.dischargeController?.footerView.hidden == false)) {
            self.dashBoardFooterView.hidden = false
            footerViewHeightConstraint.constant = 52.0
        }
        else {
            self.dashBoardFooterView.hidden = true
            footerViewHeightConstraint.constant = 0.0
        }
    }
    
    override func viewWillDisappear(animated: Bool) {
        
        super.viewWillDisappear(animated)
        self.badgeView?.hidden = true
        self.badgeLabel?.hidden = true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK:- table view DataSource methods
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return NUMBER_SEVEN
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        switch section {
        case NUMBER_ZERO:
            return NUMBER_ONE
        case NUMBER_ONE:
            return alertDatas.count + NUMBER_ONE//For adding first header cell
        case NUMBER_TWO:
            return notesDatas.count + NUMBER_TWO//For adding two cell, header and footer part(notes , Add new note)
        default:
            return NUMBER_ONE
        }
    }

    func tableView(tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat
    {
        return CGFloat(NUMBER_ONE)
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
    
        switch indexPath.section {
        case NUMBER_ZERO:
            return NUMBER_TWOHUNDRED //For Care team table cell height
        case NUMBER_ONE:
            if(indexPath.row == NUMBER_ZERO) {
                return NUMBER_FORTYFOUR
            }
            else {
                if let alertData = alertDatas[indexPath.row - NUMBER_ONE] as AlertModal! {
                    return (String.getSizeOftext(text: alertData.alertText, maxWidth: self.view.frame.size.width - SPACE_CELL, textFont: UIFont.ALERT_TEXT_FONT()).height) + NUMBER_TEN
                }
            }
        case NUMBER_TWO:
            if(indexPath.row == NUMBER_ZERO || indexPath.row == notesDatas.count + NUMBER_ONE) {
                return CELLHEIGHT_TITLE
            }
            else {
                if let noteData = notesDatas[indexPath.row - NUMBER_ONE] as NotesModal! {
                    return (String.getSizeOftext(text: noteData.notesText, maxWidth: self.view.frame.size.width - SPACE_CELL, textFont: UIFont.NOTES_TEXT_FONT()).height) + SIZE_CELLEXTRA
                }
            }
        default:
            return NUMBER_FORTYFOUR
        }
        
        
        return NUMBER_FORTYFOUR
    }
    
    func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        
        var footerView = UIView(frame: self.view.frame)
        footerView.backgroundColor = UIColor.clearColor()
        
        //20 pixel is offset from start
        //0.25 is line height
        var lineView = UIView(frame: CGRectMake(15, 0, self.view.frame.size.width, 0.5))
        lineView.backgroundColor = UIColor.colorFooterLine()
        lineView.autoresizingMask = UIViewAutoresizing.FlexibleWidth | UIViewAutoresizing.FlexibleLeftMargin | UIViewAutoresizing.FlexibleRightMargin

        footerView.addSubview(lineView)
        return footerView
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        switch indexPath.section {
        case NUMBER_ZERO:
            return configureCareTeamCell(tableView, cellForRowAtIndexPath: indexPath)
        case NUMBER_ONE:
            let cell = tableView.dequeueReusableCellWithIdentifier(CELLIDENTIFIER_ALLPATIENT) as! UITableViewCell
            cell.selectionStyle = UITableViewCellSelectionStyle.None

            cell.textLabel?.numberOfLines = NUMBER_ZERO
            if indexPath.row == NUMBER_ZERO {
                cell.textLabel?.text = TEXT_ALERTS
                cell.textLabel?.font = UIFont.ALERT_HEADER_FONT()
                cell.textLabel?.textColor = UIColor.colorAlertHeader()
                cell.accessoryType = UITableViewCellAccessoryType.None
            }
            else
            {
                if let alertData = alertDatas[indexPath.row - NUMBER_ONE] as AlertModal! {
                    cell.textLabel?.font = UIFont.ALERT_TEXT_FONT()
                    cell.textLabel?.text = alertData.alertText
                    cell.textLabel?.textColor = UIColor.blackColor()
                }
            }
            
            cell.selectionStyle = UITableViewCellSelectionStyle.None
            return cell
        case NUMBER_TWO:
            if ((indexPath.row == NUMBER_ZERO) || (indexPath.row == notesDatas.count + NUMBER_ONE)) {
                return configureNoteHeaderFooterCell(tableView, cellForRowAtIndexPath: indexPath)
            }
            else {
                return configureNotesCell(tableView, cellForRowAtIndexPath: indexPath)
            }
        default:
            let cell = tableView.dequeueReusableCellWithIdentifier(CELLIDENTIFIER_ALLPATIENT) as! UITableViewCell
            
            cell.textLabel?.textColor = UIColor.colorCellForDashboard()
            cell.textLabel?.font = UIFont.VIEWTESTRESULT_FONT()
            cell.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
            
            if indexPath.section == NUMBER_THREE {
                cell.textLabel?.text = "\(TEXT_TESTRESULT) (\(2))"
            }
            else if indexPath.section == NUMBER_FOUR
            {
                cell.textLabel?.text = "\(TEXT_VIEWVITALSIGNS)"
            }
            else if indexPath.section == NUMBER_FIVE
            {
                cell.textLabel?.text = "\(TEXT_REVIEWDC)"
            }
            else if indexPath.section == NUMBER_SIX
            {
                cell.textLabel?.text = "\(TEXT_REVIEWPLAN)"
            }
            
            return cell
        }

    }
    //MARK: UITableViewDelegate
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        tableView.deselectRowAtIndexPath(indexPath, animated: false)
        self.view.endEditing(true)

        if(indexPath.section == NUMBER_FOUR && indexPath.row == NUMBER_ZERO) {
            
            showVitalSignsController()
        }
        else if(indexPath.section == NUMBER_FIVE && indexPath.row == NUMBER_ZERO) {

            showDCViewController()
        }
        else if (indexPath.section == NUMBER_THREE || indexPath.section == NUMBER_SIX){
            self.presentViewController(AlertUtils.showErrorWith(message: MESSAGE_NOFUNCTIONALITY), animated: true, completion: nil)
        }
    }

    //MARK:- Push/Present ViewController
    func showDCViewController() {
        self.dischargeController = UIStoryboard.checkListStoryBoard().instantiateViewControllerWithIdentifier(STORYBOARD_CHECKLIST) as? DischargeCheckListViewController
        self.showViewController(self.dischargeController!, sender: nil)
        self.dischargeController?.patientDetail = self.selectedPatient
    }
    
    func showVitalSignsController() {
        let vitalSIgnCOntroller: UIViewController = UIStoryboard.vitalSignsStoryBoard().instantiateViewControllerWithIdentifier(STORYBOARD_VITALSIGNS) as! VitalSignsViewController
        self.showViewController(vitalSIgnCOntroller, sender: nil)
    }

    //MARK:- Cell Configure
    
    /**
    Configure Careteam cell
    
    :param: tableView - Tableview for which the careteam data need to show
    :param: indexPath - indexpath of the cell
    */
    private func configureCareTeamCell(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
    
        let cell = tableView.dequeueReusableCellWithIdentifier(CELLIDENTIFIER_CARETEAM) as! CareTeamTableViewCell
        cell.tapDelegate = self
        cell.selectionStyle = UITableViewCellSelectionStyle.None
        return cell
    }
    
    /**
    Configure notes header and footer cell
    
    :param: tableView - Tableview for which the note need to show
    :param: indexPath - indexpath of the cell
    */
    private func configureNoteHeaderFooterCell(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
    
        let cell = tableView.dequeueReusableCellWithIdentifier(CELLIDENTIFIER_NOTESTITLE, forIndexPath: indexPath) as! TitleViewCell
        
        cell.titleViewTextField.placeholder = (indexPath.row == NUMBER_ZERO ? "" : TEXT_NOTESTABLEFOOTER)
        cell.titleViewTextField.text = (indexPath.row == NUMBER_ZERO ? TEXT_NOTESTABLEHEADER : "")
        cell.titleViewTextField.userInteractionEnabled = (indexPath.row == NUMBER_ZERO ? false : true)
        cell.titleViewTextField.delegate = self
        cell.titleViewTextField.isAccessibilityElement = true
        cell.titleViewTextField.accessibilityHint = (indexPath.row == NUMBER_ZERO ? NSLocalizedString(TEXT_NOTESTABLEHEADER, comment: "") : NSLocalizedString(TEXT_ENTERNOTES, comment: ""))
        cell.titleViewTextField.font = UIFont.NOTES_HEADER_FONT()
        cell.titleViewTextField.textColor = UIColor.colorNotesHeader()

        cell.selectionStyle = UITableViewCellSelectionStyle.None
        return cell
    }
    
    /**
    Configure notes inner cell
    
    :param: tableView - Tableview for which the note need to show
    :param: indexPath - indexpath of the cell
    */
    private func configureNotesCell(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(CELLIDENTIFIER_NOTES, forIndexPath: indexPath) as! NotesViewTableViewCell
        
        if let noteData = notesDatas[indexPath.row - NUMBER_ONE] as NotesModal! {
            cell.notesTextLbl.text = noteData.notesText
            cell.originatorDetailLbl.text = noteData.name + " - " + noteData.date
            
            cell.notesTextLbl.textColor = UIColor.blackColor()
            cell.originatorDetailLbl.textColor = UIColor.colorNotesDate()

            cell.notesTextLbl.font = UIFont.NOTES_TEXT_FONT()
            cell.originatorDetailLbl.font = UIFont.NOTES_DATE_FONT()
        }
        
        cell.selectionStyle = UITableViewCellSelectionStyle.None
        return cell
    }
    
    //MARK:- UIScrollViewDelegate
    func scrollViewDidEndDragging(scrollView: UIScrollView, willDecelerate decelerate: Bool)
    {
        if (textFldTemp != nil){
            if ((textFldTemp?.isFirstResponder()) != nil)
            {
                textFldTemp?.resignFirstResponder()
            }
        }
    }
    
    //MARK: - Private Methods
    
    /**
    This method is to move table view while entering notes
    
    :param: textField - The field where notes need to be enter
    */
    private func scrollViewToTextField(textField:UITextField)
    {        
        // Get the text fields location
        let point = textField.superview!.convertPoint(textField.superview!.frame.origin, toView: slidingTableView)
        
        slidingTableView.setContentOffset(CGPointMake(0, point.y-12), animated: true)
    }
    /**
    This method is to resign the keyboard while tapping outside of keyboard
    */
    func dismissKeyboard()
    {
        if (textFldTemp != nil){
            if ((textFldTemp?.isFirstResponder()) != nil)
            {
                textFldTemp?.resignFirstResponder()
            }
        }
    }
    
    // MARK:- Web service call Methods
    //This method is to retrive notes data from json file and load it in the table view
    private func notesDataService()
    {
        Request.Notes().execute().validate().responseJSON{ (_, _, json, error) -> Void in
            if let error = error {
                self.serviceFailedWithError(error)
            } else {
                
                self.notesDatas = Response.notesDataFromJSON(json)
                
                //Reload table
                self.slidingTableView.reloadData()
            }
        }
    }
    
    //This method is to retrive alert data from json file and load it in the table view
    private func alertsDataService()
    {
        Request.AlertData().execute().validate().responseJSON{ (_, _, json, error) -> Void in
            if let error = error {
                self.serviceFailedWithError(error)
            } else {
                
                self.alertDatas = Response.alertDataFromJSON(json)
                
                //Reload table
                self.slidingTableView.reloadData()
            }
        }
    }

    /**
    This method is to show alert if an error occured while parsing data from Json
    
    :param: error - Error object which need to show in alert
    */
    private func serviceFailedWithError(error: NSError)
    {
        // create the error message
        self.presentViewController(AlertUtils.showErrorWith(message: TITLE_ATTENTION), animated: true, completion: nil)
    }
    
    
    private func getDataForPatientAtIndex(index: Int) {
        
        Request.PatientList().execute().validate().responseJSON { (_, _, json, error) -> Void in
            
            if let error = error {
                
            }
                
            else {
                
                let allPatient = Response.patientListFromJSON(json)
                Patient.applyFilter(allPatient)
                Patient.selectedFilterIndex = index
                
                let patientList = Patient.patientFilterArrayofPatientList[index] as! [Patient]
                let navigationBarTitleView = self.navigationBarTitleView.subviews[0] as! NavigationBarTitleView
                navigationBarTitleView.title.text = Patient.patientTypeFilterArray[index] + " (" + String(patientList.count) + ")"
            }
        }
    }
    
    private func configureNavigationBar() {

        let signOutBarButtonItem =  UIBarButtonItem(image: UIImage(named: IMAGE_SIGNOUT), style: UIBarButtonItemStyle.Plain, target: self, action: "signOutButtonTapped:")
        signOutBarButtonItem.tintColor = UIColor.NAVIGATION_TITLE_COLOR()
        
        let searchBarButtonItem =  UIBarButtonItem(image: UIImage(named: IMAGE_SEARCH), style: UIBarButtonItemStyle.Plain, target: self, action: "searchButtonTapped:")
        searchBarButtonItem.tintColor = UIColor.NAVIGATION_TITLE_COLOR()
        let alertBarButtonItem =  UIBarButtonItem(image: UIImage(named: IMAGE_MESSAGE), style: UIBarButtonItemStyle.Plain, target: self, action: "alertButtonTapped:")
        alertBarButtonItem.tintColor = UIColor.NAVIGATION_TITLE_COLOR()
        self.addBadgeView()

        self.navigationItem.leftBarButtonItem = signOutBarButtonItem
        self.navigationItem.rightBarButtonItems = [alertBarButtonItem,searchBarButtonItem]

    }
    
    //MARK: To Add notification badge
    func addBadgeView() {
        
        var width = self.navigationController?.navigationBar.frame.size.width
        self.badgeView = UIView(frame: CGRectMake(width! - 30.0, 0.0, 18.0, 18.0))
        self.badgeView!.backgroundColor = UIColor.redColor()
        self.badgeView!.layer.cornerRadius = 10.0
        self.badgeView!.layer.masksToBounds = true
        self.badgeView!.backgroundColor = UIColor.redColor()
        self.navigationController?.navigationBar.addSubview(self.badgeView!)
        
        self.badgeLabel = UILabel(frame: CGRectMake(width! - 30.0, 0.0, 18.0, 18.0))
        self.badgeLabel!.text = "3"
        self.badgeLabel!.textAlignment = NSTextAlignment.Center
        self.badgeLabel!.textColor = UIColor.whiteColor()
        self.navigationController?.navigationBar.addSubview(self.badgeLabel!)
        badgeView!.bringSubviewToFront(self.view)
    }
    
    // MARK:- Textfield delegate Methods
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool
    {
        textFldTemp = textField
        scrollViewToTextField(textField)
        
        return true
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool
    {
        if(!isEmpty(textField.text))
        {
            let objNotes = NotesModal(notes: textField.text, name: TEXT_ME, date: NSDate.convertToStringWithOrdinalFormat(fromDate: NSDate(), strFormatter: DATEFORMATTER_NOTESDATA_ORDINAL), actualDate:NSDate())
            notesDatas.append(objNotes)
            
            slidingTableView.reloadData()
        }
        
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldShouldEndEditing(textField: UITextField) -> Bool
    {
        textField.text = ""
//        slidingTableView.setContentOffset(CGPointZero, animated: true)
        return true
    }

    //MARK:- ContactStaffDelegate
    func didTapCallButtonAtIndexPath(indexpath: NSIndexPath) {
        self.presentViewController(AlertUtils.showErrorWith(message: MESSAGE_NOFUNCTIONALITY), animated: true, completion: nil)

    }
    func didTapMessageButtonAtIndexPath(indexpath: NSIndexPath) {
        
    }
    
    //MARK:- Header View Item Action
    func signOutButtonTapped(id:UIBarButtonItem) {
        if let controller = self.authenticationController {
            controller.signOut()
        }
    }

    func searchButtonTapped(id:UIBarButtonItem) {
        var searchController: UISearchController!
        // Create the search results view controller and use it for the UISearchController.
        let searchResultsController = UIStoryboard.patientSearchStoryBoard().instantiateViewControllerWithIdentifier(STORYBOARD_SearchPatientResults) as! SearchResultViewController
        
        // Create the search controller and make it perform the results updating.
        searchController = UISearchController(searchResultsController: searchResultsController)
        searchController.searchResultsUpdater = searchResultsController
        searchController.hidesNavigationBarDuringPresentation = false
        
        searchController.searchBar.barTintColor = UIColor.colorForPatientCollectionBackground()
        
        searchController.searchBar.tintColor = UIColor.whiteColor()
        searchController.view.backgroundColor = UIColor.colorForEmptySearchScreen()
        
        // Present the view controller.
        presentViewController(searchController, animated: true, completion: nil)
    }
    
    func alertButtonTapped(id:UIBarButtonItem) {
        
        let navCntrl: UINavigationController = UIStoryboard.alertListStoryBoard().instantiateViewControllerWithIdentifier(STORYBOARD_ALERTLIST_NAVIGATIONCONTROLLER) as! UINavigationController
        let alertViewController = navCntrl.topViewController as! AlertViewController
        self.presentViewController(navCntrl, animated: true, completion: nil)
    }
    

    func titleLabelTapped(gesture:UITapGestureRecognizer) {
        let navCntrl: UINavigationController = UIStoryboard.patientFilterListStoryboard().instantiateViewControllerWithIdentifier(CONTROLLER_PATIENTFILTERLIST) as! UINavigationController
        let patientListVIewController = navCntrl.topViewController as! PatientFilterListViewController
        patientListVIewController.delegate = self
        
        //self.navigationController?.pushViewController(navCntrl.topViewController, animated: true)
        self.presentViewController(navCntrl, animated: true, completion: nil)
    }
    
    func showAlert() {
        self.presentViewController(AlertUtils.showErrorWith(message: MESSAGE_NOFUNCTIONALITY), animated: true, completion: nil)
    }
    //MARK:- PatientFilterDelegate
    
    func selectedFilterTitle(title : String) {
        let navigationBarTitleView = self.navigationBarTitleView.subviews[0] as! NavigationBarTitleView
        navigationBarTitleView.title.text = title
    }
    func selectedFilterTypeIndex(indexRow : Int) {
    }
    
    //MARK: - PatientListDelegate
    func selectedPatient(patient: Patient)
    {
        //Scroll to top
        self.slidingTableView.scrollRectToVisible(CGRectMake(0, 0, 1, 1), animated: false)
        footerViewHeightConstraint.constant = 0.0

        self.selectedPatient = patient
        //As By default UITableView has 1 section
        let numberOfRow = self.slidingTableView.numberOfRowsInSection(0)
        
        if numberOfRow > 0 {
            let careTeamCell = self.slidingTableView.cellForRowAtIndexPath(NSIndexPath(forRow: 0, inSection: 0)) as! CareTeamTableViewCell
            let careTeamCollectionView = careTeamCell.careTeamCollectionView
            careTeamCell.careTeamList.removeAll(keepCapacity: false)
            careTeamCollectionView.reloadData()
            careTeamCell.patientDetailView?.updateHeaderDetail(self.selectedPatient!)
            careTeamCell.getCareTeamDataForIds(patient.careTeamStaffIds)
            careTeamCell.patientDetailView?.delegate = self
        }

        
    }
    
    //MARK: - CareTeamInfoDelegate
    func careTeamInfo() {
        if networkReachability.isReachable() {
            self.presentViewController(AlertUtils.showErrorWith(message: MESSAGE_NOFUNCTIONALITY), animated: true, completion: nil)
        }
        else {
            self.presentViewController(AlertUtils.showErrorWithoutTitle(message: MESSAGE_NOINTERNETCONNECTION), animated: true, completion: nil)
        }
    }
    
    //Reachability - change in network connection
    func notifyNetworkChange(Notification: NSNotification) {
        let reachability = Notification.object as! Reachability
        if reachability.isReachable() {
            self.removeOfflineView()
        }
        else {
            self.animateOfflineView()
        }
    }
    
    //To Animate Offline view
    func animateOfflineView() {
        offlineView.hidden = false
        if self.offlineViewHeightConstraint.constant != 30 {
            mytimer = NSTimer .scheduledTimerWithTimeInterval(0.1, target: self, selector: "restart", userInfo: nil, repeats: false)
        }
    }
    
    func restart() {
        UIView.animateWithDuration(0.1, delay: 0.0, options: UIViewAnimationOptions.CurveEaseIn , animations: {  self.offlineViewHeightConstraint.constant += 5}, completion:  {(finished: Bool) in self.animateOfflineView() })
    }
    
    // To remove the offline view
    func removeOfflineView() {
        if self.offlineViewHeightConstraint.constant != 0 {
            mytimer = NSTimer .scheduledTimerWithTimeInterval(0.1, target: self, selector: "restartTimer", userInfo: nil, repeats: false)
        }
        else {
            self.offlineView.hidden = true
        }
    }
    
    func restartTimer() {
        UIView.animateWithDuration(0.1, delay: 0.0, options: UIViewAnimationOptions.CurveEaseIn , animations: {  self.offlineViewHeightConstraint.constant -= 5}, completion:  {(finished: Bool) in self.removeOfflineView() })
    }

}
