//
//  StyleKit.swift
//
//  Created by Jeremy Koch on 11/21/14.
//  Copyright (c) 2014 IBM. All rights reserved.
//

import UIKit

public class StyleKit : NSObject {

    //// Cache
    
    private struct Cache {
        static var defaultTint: UIColor = UIColor(red: 0.043, green: 0.376, blue: 0.490, alpha: 1.000)
    }
    
    //// Colors
    
    public class var defaultTint: UIColor { return Cache.defaultTint }
     static var HELVETICA_NEUE_REGULAR_14 :UIFont { return UIFont.HELVETICANEUE_REGULAR(14) }
}

extension UIColor {
    func colorWithHue(newHue: CGFloat) -> UIColor {
        var saturation: CGFloat = 1.0, brightness: CGFloat = 1.0, alpha: CGFloat = 1.0
        self.getHue(nil, saturation: &saturation, brightness: &brightness, alpha: &alpha)
        return UIColor(hue: newHue, saturation: saturation, brightness: brightness, alpha: alpha)
    }
    func colorWithSaturation(newSaturation: CGFloat) -> UIColor {
        var hue: CGFloat = 1.0, brightness: CGFloat = 1.0, alpha: CGFloat = 1.0
        self.getHue(&hue, saturation: nil, brightness: &brightness, alpha: &alpha)
        return UIColor(hue: hue, saturation: newSaturation, brightness: brightness, alpha: alpha)
    }
    func colorWithBrightness(newBrightness: CGFloat) -> UIColor {
        var hue: CGFloat = 1.0, saturation: CGFloat = 1.0, alpha: CGFloat = 1.0
        self.getHue(&hue, saturation: &saturation, brightness: nil, alpha: &alpha)
        return UIColor(hue: hue, saturation: saturation, brightness: newBrightness, alpha: alpha)
    }
    func colorWithAlpha(newAlpha: CGFloat) -> UIColor {
        var hue: CGFloat = 1.0, saturation: CGFloat = 1.0, brightness: CGFloat = 1.0
        self.getHue(&hue, saturation: &saturation, brightness: &brightness, alpha: nil)
        return UIColor(hue: hue, saturation: saturation, brightness: brightness, alpha: newAlpha)
    }
    func colorWithHighlight(highlight: CGFloat) -> UIColor {
        var red: CGFloat = 1.0, green: CGFloat = 1.0, blue: CGFloat = 1.0, alpha: CGFloat = 1.0
        self.getRed(&red, green: &green, blue: &blue, alpha: &alpha)
        return UIColor(red: red * (1-highlight) + highlight, green: green * (1-highlight) + highlight, blue: blue * (1-highlight) + highlight, alpha: alpha * (1-highlight) + highlight)
    }
    func colorWithShadow(shadow: CGFloat) -> UIColor {
        var red: CGFloat = 1.0, green: CGFloat = 1.0, blue: CGFloat = 1.0, alpha: CGFloat = 1.0
        self.getRed(&red, green: &green, blue: &blue, alpha: &alpha)
        return UIColor(red: red * (1-shadow), green: green * (1-shadow), blue: blue * (1-shadow), alpha: alpha * (1-shadow) + shadow)
    }
    
    //MARK: - NavigationBar color
    class func NAVIGATION_BAR_COLOR() -> UIColor {return UIColor(red: 36/255, green: 42/255, blue: 74/255, alpha: 1.0) }
    class func NAVIGATION_TITLE_COLOR() -> UIColor {return UIColor(red: 208/255, green: 228/255, blue: 242/255, alpha: 1.0) }

    class func checkListCellColor() -> UIColor {return UIColor(red: 83/255, green: 88/255, blue: 95/255, alpha: 1.0) }
    
     class func colorForCheckMark() -> UIColor {return UIColor(red: 81/255, green: 176/255, blue: 255/255, alpha: 1.0) }
    
    //MARK: - PatientListView Color
    class func colorForPatientCollectionBackground() -> UIColor {
        return UIColor(red: 36/255, green: 42/255, blue: 74/255, alpha: 1.0)
    }
    
    class func colorForSelectedPatientInCollection() -> UIColor {return UIColor(red: 208/255, green: 228/255, blue: 242/255, alpha: 1.0)}

    //MARK: - Dashboard Color
    class func colorAlertHeader() -> UIColor {return UIColor(red: 83/255, green: 88/255, blue: 95/255, alpha: 1.0) }
    class func colorNotesHeader() -> UIColor {return UIColor(red: 83/255, green: 88/255, blue: 95/255, alpha: 1.0) }
    class func colorNotesDate() -> UIColor {return UIColor(red: 134/255, green: 138/255, blue: 144/255, alpha: 1.0) }
    class func colorFooterLine() -> UIColor {return UIColor(red: 167/255, green: 170/255, blue: 169/255, alpha: 1.0) }

    class func colorCellForDashboard() -> UIColor {
        return UIColor(red: 74.0/255.0, green: 100.0/255.0, blue: 145.0/255.0, alpha: 1.0)
    }
    
    //MARK: - DischargeCheckList Color
    class func colorCompleteButton() -> UIColor {return UIColor(red: 72/255, green: 119/255, blue: 154/255, alpha: 1.0) }
    
    //MARK: - Line Graph Color
    class func dateTitleColor() -> UIColor {return UIColor(red: 102.0/255.0, green: 105.0/255.0, blue: 112.0/255.0, alpha: 1.0)}
    class func rightFirstTitleColor() -> UIColor {return UIColor(red: 33.0/255.0, green: 56.0/255.0, blue: 71.0/255.0, alpha: 1.0)}
    class func rightSecondTitleColor() -> UIColor {return UIColor(red: 103.0/255.0, green: 175.0/255.0, blue: 233.0/255.0, alpha: 1.0)}

    class func gridColor() -> UIColor {return UIColor(red: 238/255.0, green: 238/255.0, blue: 238/255.0, alpha: 1)}
    class func axesColor() -> UIColor {return UIColor(red: 83.0/255.0, green: 88.0/255.0, blue: 95.0/255.0, alpha: 1.0)}
    class func positiveAreaColor() -> UIColor {return UIColor(red: 246/255.0, green: 153/255.0, blue: 136/255.0, alpha: 1)}
    class func negativeAreaColor() -> UIColor {return UIColor(red: 114/255.0, green: 213/255.0, blue: 114/255.0, alpha: 1)}

    class func xAxisLabelsColor() -> UIColor {return UIColor(red: 82.0/255.0, green: 88.0/255.0, blue: 96.0/255.0, alpha: 1.0)}
    //MARK: - Search screen Color
    class func colorForPatientNameInSearchResultCell() -> UIColor {return UIColor(red: 83/255, green: 88/255, blue: 95/255, alpha: 1.0)}
    class func colorForpatientConditionInSearchResultCell() -> UIColor {return UIColor.blackColor()}
    class func colorForEmptySearchScreen() -> UIColor {return UIColor(red: 244/255, green: 248/255, blue: 251/255, alpha: 1.0)}
    class func colorSearchBarText() -> UIColor {return UIColor(red: 166/255, green: 170/255, blue: 169/255, alpha: 1.0) }

}
