//
//  NotesViewTableViewCell.swift
//  HospitalMD
//
//  Created by Das on 19/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit

//This class is used to display notes entered by doctor or nurse
class NotesViewTableViewCell: UITableViewCell {

    // MARK:- Outlets
    @IBOutlet weak var notesTextLbl: UILabel!
    @IBOutlet weak var originatorDetailLbl: UILabel!
    
    // MARK:- UITableViewCell methods
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
