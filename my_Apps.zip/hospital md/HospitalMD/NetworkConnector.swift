//
//  NetworkConnector.swift
//  HospitalMD
//
//  Created by Saurav on 18/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import Foundation
import UIKit

let httpRequestTimeoutInterval:Double = 300 //need be redefined

class NetworkConnector {
    
    class func httpGetRequest(baseURL:NSString,
        queryParameters:NSDictionary?,
        headerFields:NSDictionary?,
        result:(responseJson:NSDictionary?, response:NSURLResponse!, error:NSError?)->()) -> NSURLSessionDataTask
    {
        MFLog("GET baseURL:\(baseURL) queryParameters:\(queryParameters) headerFields:\(headerFields)", level:1)
        return NetworkConnector.httpBaseRequest(baseURL, method:"GET", queryParameters:queryParameters, headerFields:headerFields, bodyDict:nil, result:result)
    }
    
    
    class func httpPostRequest(baseURL:NSString,
        queryParameters:NSDictionary?,
        bodyDict:NSDictionary?,
        headerFields:NSDictionary?,
        result:(responseJson:NSDictionary?,response:NSURLResponse!,error:NSError?)->()) -> NSURLSessionDataTask
    {
        MFLog("POST baseURL:\(baseURL) queryParameters:\(queryParameters) headerFields:\(headerFields) bodyDict:\(bodyDict)", level:1)
        return NetworkConnector.httpBaseRequest(baseURL, method:"POST", queryParameters:queryParameters, headerFields:headerFields, bodyDict:bodyDict, result:result)
    }
    
    
    class func httpPutRequest(baseURL:NSString,
        queryParameters:NSDictionary?,
        bodyDict:NSDictionary?,
        headerFields:NSDictionary?,
        result:(responseJson:NSDictionary?,response:NSURLResponse!,error:NSError?)->()) -> NSURLSessionDataTask
    {
        return NetworkConnector.httpBaseRequest(baseURL,method:"PUT", queryParameters:queryParameters, headerFields:headerFields, bodyDict:bodyDict,result:result)
    }
    
    
    class func httpDeleteRequest(baseURL:NSString,
        queryParameters:NSDictionary?,
        bodyDict:NSDictionary?,
        headerFields:NSDictionary?,
        result:(responseJson:NSDictionary?,response:NSURLResponse!,error:NSError?)->()) -> NSURLSessionDataTask
    {
        return NetworkConnector.httpBaseRequest(baseURL,method:"DELETE", queryParameters:queryParameters, headerFields:headerFields, bodyDict:bodyDict,result:result)
    }
    
    
    class private func httpBaseRequest(baseURL:NSString,method:String,
        queryParameters:NSDictionary?,
        headerFields:NSDictionary?,
        bodyDict:NSDictionary?,
        result:(responseJson:NSDictionary?,response:NSURLResponse!,error:NSError?)->()) -> NSURLSessionDataTask
    {
        
        //init request
        let queryString = NetworkConnector.addQueryStringToUrl(baseURL, params: queryParameters)
        
        let sessionConfiguration: NSURLSessionConfiguration = NSURLSessionConfiguration.defaultSessionConfiguration()
        let session: NSURLSession = NSURLSession(configuration: sessionConfiguration, delegate: NetworkAuth.sharedInstance, delegateQueue: nil)
        
        let request = NSMutableURLRequest(URL: NSURL(string: queryString as String)!, cachePolicy: NSURLRequestCachePolicy.UseProtocolCachePolicy, timeoutInterval: httpRequestTimeoutInterval)
        request.HTTPMethod = method
        
        if headerFields != nil {
            request.allHTTPHeaderFields = headerFields as? [NSObject : AnyObject]
        }
        
        // all request should be json
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        //add request body
        if bodyDict != nil {
            var err: NSError?
            request.HTTPBody = NSJSONSerialization.dataWithJSONObject(bodyDict!, options: nil, error: &err)
        }
        
        let networkAcitivityIndicatorManager = NetworkAcitivityIndicatorManager.sharedInstance
        
        //create task, and try anything in sub thread
        let task = session.dataTaskWithRequest(request, completionHandler: { (data, response, error) -> () in
            networkAcitivityIndicatorManager.removeNetworkActivityIndicator()
            var json :NSDictionary? = NetworkConnector.serializationDataToJson(data)
            dispatch_async(dispatch_get_main_queue()){ //all callback will be in main thread
                result(responseJson: json, response: response, error: error)
            }
        })
        
        //start to request from network
        networkAcitivityIndicatorManager.addNetworkActivityIndicator()
        task.resume()
        return task
    }
    
    
    
    class var sharedInstance : NetworkConnector { //design as singleton.
        
        struct StaticNetworkConnector
        {
            static var onceToken : dispatch_once_t = 0
            static var instance : NetworkConnector? = nil
        }
        
        dispatch_once(&StaticNetworkConnector.onceToken) {
            StaticNetworkConnector.instance = NetworkConnector()
        }
        return StaticNetworkConnector.instance!
    }
    
    private let requestArray:NSMutableArray
    
    init()
    {
        requestArray = NSMutableArray() // [NSURLRequest]
    }
    
    
    func downloadImage(imageURL:NSURL, showIndicator:Bool = true, result:(imageData:NSData?,response:NSURLResponse!,error:NSError?) -> ()) -> NSURLSessionDownloadTask
    {
        var request = NSMutableURLRequest(URL: imageURL)
        return self.downloadImage(request, showIndicator:showIndicator, result: { (imageData, response, error) -> () in
            result(imageData: imageData, response: response, error: error)
        })
    }
    
    func downloadImage(imageRequest:NSURLRequest, showIndicator:Bool = true, result:(imageData:NSData?,response:NSURLResponse!,error:NSError?) -> ()) -> NSURLSessionDownloadTask{
        
        let configuration = NSURLSessionConfiguration.defaultSessionConfiguration()
        let quee = NSOperationQueue()
        let session:NSURLSession = NSURLSession(configuration: configuration, delegate: NetworkAuth.sharedInstance, delegateQueue: quee)
        let networkAcitivityIndicatorManager = NetworkAcitivityIndicatorManager.sharedInstance
        
        //start
        if showIndicator == true {
            networkAcitivityIndicatorManager.addNetworkActivityIndicator()
        }
        
        //create download task, try anything in sub thread
        let downloadTask =  session.downloadTaskWithRequest(imageRequest, completionHandler: { (location:NSURL!, response:NSURLResponse!, errorDownload:NSError!) in
            
            var status200 = true
            if let httpResponse = response as? NSHTTPURLResponse {
                status200 = httpResponse.statusCode == 200
            }
            
            var imageData:NSData?
            if (errorDownload == nil && status200) {
                imageData = NSData(contentsOfURL: location, options: NSDataReadingOptions(0), error: nil)
            }
            
            //return result in main thread
            dispatch_async(dispatch_get_main_queue()) {
                result(imageData:imageData, response:response, error: errorDownload)
                if showIndicator == true {
                    networkAcitivityIndicatorManager.removeNetworkActivityIndicator()
                }
            }
        })
        
        //start to download
        downloadTask.resume()
        return downloadTask
    }
    
    //private help functions
    class func urlEscape(unencodedString:NSString) -> NSString {
        var resutlString = CFURLCreateStringByAddingPercentEscapes(nil, unencodedString, nil, "!*'\"();:@&=+$,/?%#[]% ", CFStringEncoding())
        return resutlString
    }
    
    private class func addQueryStringToUrl(url:NSString, params:NSDictionary?) -> NSString {
        var urlWithQueryString = NSMutableString(string: url)
        if params != nil {
            for key in params!.allKeys {
                let value:NSString = params!.objectForKey(key) as! NSString
                let keyStr = key as! NSString
                if urlWithQueryString.rangeOfString("?").location == NSNotFound {
                    urlWithQueryString.appendString("?\(NetworkConnector.urlEscape(keyStr))=\(NetworkConnector.urlEscape(value))")
                }else{
                    urlWithQueryString.appendString("&\(NetworkConnector.urlEscape(keyStr))=\(NetworkConnector.urlEscape(value))")
                }
            }
        }
        return urlWithQueryString
    }
    
    private class func serializationDataToJson(data: NSData?) -> NSDictionary?
    {
        var json :NSDictionary?
        if data != nil {
            var e: NSError?
            var jsonObject:AnyObject? = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &e)
            if let x: AnyObject = jsonObject {
                if x is NSArray {
                    json = NSDictionary(object: jsonObject!, forKey: "data")
                }else{
                    json = jsonObject as? NSDictionary
                }
            }
        }
        return json
    }
}
