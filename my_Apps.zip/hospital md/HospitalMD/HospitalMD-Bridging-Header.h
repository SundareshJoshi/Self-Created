//
//  Use this file to import your target's public headers that you would like to expose to Swift.
//

#ifndef HospitalMD_HospitalMD_Bridging_Header_h
#define HospitalMD_HospitalMD_Bridging_Header_h

#import "Reachability.h"

#endif