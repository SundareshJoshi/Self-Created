//
//  String+Formats.swift
//  ShiftHandover
//
//  Created by David Huo on 2015-02-13.
//  Copyright (c) 2015 IBM. All rights reserved.
//


import UIKit

extension String {
    // Format a string to a date, default use the JSON date format
    // yyyy-MM-dd HH:mm:ssz
    // format is the format of the date string
   func date(format:String? = "yyyy-MM-dd HH:mm:ssz")->NSDate? {
        let f = NSDateFormatter()
        f.dateFormat = format
        var t = f.dateFromString(self)
        if t == nil {
            /* For the demo data
            This code is under a condition and only works when the input text is in "HH:mm:ss" format. This is for the demo data date fields. The actual data from the server should have the full format it excepts. But we need this code to support parsing demo data date so that the app has data to demo for every day.*/
            f.dateFormat = "HH:mm:ss"
            f.timeZone = NSTimeZone()            
            t = f.dateFromString(self)
            let calendar = NSCalendar.currentCalendar()
            let comp = calendar.components((NSCalendarUnit.CalendarUnitHour | NSCalendarUnit.CalendarUnitMinute), fromDate: t!)
            let currentDate = calendar.components((NSCalendarUnit.CalendarUnitYear | NSCalendarUnit.CalendarUnitMonth | NSCalendarUnit.CalendarUnitDay), fromDate: NSDate())
            currentDate.hour = comp.hour
            currentDate.minute = comp.minute
            return calendar.dateFromComponents(currentDate)
        }
        return t
    }
    
    // Returns the localized text
    var localized : String {
        return NSLocalizedString(self, comment: self)
    }
    
    var queryToFile : String {
        let set = NSCharacterSet(charactersInString: "&+=?")
        let comps = self.componentsSeparatedByCharactersInSet(set) as NSArray
        return comps.componentsJoinedByString("_")
    }
    
    func ignoreCaseContains(other:String?)->Bool {
        if let other = other {
            return self.lowercaseString.rangeOfString(other.lowercaseString) != nil
        }
        return false
    }
    
    func matchedAttributeString(other:String, color:UIColor)->NSMutableAttributedString {
        let range = self.lowercaseString.rangeOfString(other.lowercaseString)
        let at = NSMutableAttributedString(string: self)
        if let range = range {
            let start = distance(self.startIndex, range.startIndex)
            let length = distance(range.startIndex, range.endIndex)
            let nsRange = NSMakeRange(start, length)
            at.setAttributes([NSForegroundColorAttributeName : color], range: nsRange)
        }
        return at
    }
    
    func boldMatchedAttributeString(other:String, regularFont: UIFont)->NSMutableAttributedString {
        let range = self.lowercaseString.rangeOfString(other.lowercaseString)
        let at = NSMutableAttributedString(string: self)
        if let range = range {
            let start = distance(self.startIndex, range.startIndex)
            let length = distance(range.startIndex, range.endIndex)
            let nsRange = NSMakeRange(start, length)
            at.setAttributes([NSFontAttributeName : regularFont.bold()], range: nsRange)
        }
        return at
    }
    
    func widthWithFont(font:UIFont)->CGFloat {
        let attributes = [NSFontAttributeName:font]
        let attstr = NSAttributedString(string:self, attributes: attributes)
        return attstr.size().width
    }
    
    var data:NSData? {
        return (self as NSString).dataUsingEncoding(NSUTF8StringEncoding)
    }
    
    func json()->NSMutableDictionary? {
        var error: NSError?
        if let data = (self as NSString).dataUsingEncoding(NSUTF8StringEncoding) {
            if data.length > 0 {
                return data.json()
            }
        }
        return nil
    }
}





