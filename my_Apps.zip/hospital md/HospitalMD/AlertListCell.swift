//
//  AlertListCell.swift
//  HospitalMD
//
//  Created by kamruddin on 5/28/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit

//Cell to display Patient Alerts detail
class AlertListCell: UITableViewCell {
    
    //MARK: - IBOutlets
    @IBOutlet weak var subTitleLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var patientBedNumber: UILabel!
    @IBOutlet weak var alertView: UIView!
    @IBOutlet weak var sepratorView: UIView!
    
    //MARK: - cell life cycle method
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        sepratorView.frame.size.height = 0.5
        self.alertView.layer.cornerRadius = 20.0
        self.alertView.layer.masksToBounds = true
    }
    
    //MARK: To set the data for patient alert list
    /**
    Configure and set the data for alert list
    
    :param: title - Alert title
    :param: subTitle - Patient Name
    :param: patientBedNumber - Bed number
    */
    func configureCellData(title: String, subTitle: String, patientBedNumber: String)
    {
        self.titleLabel.text = title
        self.subTitleLabel.text = subTitle
        self.patientBedNumber.text = patientBedNumber
    }
}
