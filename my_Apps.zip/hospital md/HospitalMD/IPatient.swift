//
//  IPatient.swift
//  HospitalMD
//
//  Created by Saurav on 25/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit
import HealthCareData
import CoreData

class IPatient: HealthCareData.Patient2 {
   
    class func inititatePatientFromJSONFile(fileName: String) -> HealthCareData.Patient2 {

        let entityDescripition = NSEntityDescription.entityForName("Patient", inManagedObjectContext: CoreDataStack.sharedInstance.managedObjectContext!)
        
        var patient = HealthCareData.Patient2(entity: entityDescripition!, insertIntoManagedObjectContext: CoreDataStack.sharedInstance.managedObjectContext)

        patient.setProperties("P1", firstName: "Saurav", lastName: "Kabra", gender: GenderEnum.Male, birthDate: NSDate(), acuity: PatientAcuityEnum.FMTODO, ambulatoryStatus: PatientAmbulatoryStatus.WalkingWithAssistance, physicianName: "", status: PatientStatusEnum.Admitted, alerts: nil, allergies: nil, barriers: nil, bed: nil, diagnoses: nil, diets: nil, immunizations: nil, pertainingMessages: nil, pertainingTasks: nil, recoveryPath: nil, room: nil, roundedBy: nil, roundingNotes: nil, symptoms: nil, vitals: nil)
        
        CoreDataStack.sharedInstance.managedObjectContext?.save(nil)
        return patient

    }

}
