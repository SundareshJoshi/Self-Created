//
//  OrientationAwareController.swift
//  ShiftHandover
//
//  Created by David Huo on 2015-02-11.
//  Copyright (c) 2015 IBM. All rights reserved.
//


import UIKit

/**
 * Base conttoller has orientation awareness
 * Steps to support orientation for iPad in interface builder
 * 1) Add all the common constraints for both orientation
 * 2) Create all the landscape constraints and add them to landscapeConstraints outlet collection
 * 3) Uninstall all the landscape constraints
 * 4) Create all the portrait contraints and add them to portraitConstraints outlet collection
 * 5) Install all the landscape constraints, ignore the layout conflicts
 * 6) Subclass need to call super.viewDidLoad() if it overrides
 */
class OrientationAwareController : UIViewController {
    @IBOutlet var landscapeConstraints: [NSLayoutConstraint]!
    @IBOutlet var portraitConstraints: [NSLayoutConstraint]!
    
    func applyConstraintsForPortrait() {
        // Apply contraints for Portrait
        self.view.removeConstraints(landscapeConstraints)
        self.view.addConstraints(portraitConstraints)
        // Call all the subview controller to notify the rotation
        for c in childViewControllers {
            if c is OrientationAwareController {
                c.applyConstraintsForPortrait()
            }
        }
    }
    
    func applyConstraintsForLandscape() {
        // Apply contraints for Landscape
        self.view.removeConstraints(portraitConstraints)
        self.view.addConstraints(landscapeConstraints)
        // Call all the subview controller to notify the rotation
        for c in childViewControllers {
            if c is OrientationAwareController {
                c.applyConstraintsForLandscape()
            }
        }        
    }
    
    override func viewDidLayoutSubviews() {
        if(UIInterfaceOrientationIsPortrait(UIApplication.sharedApplication().statusBarOrientation))
        {
            applyConstraintsForPortrait()
        }
        else
        {
            applyConstraintsForLandscape()
        }
    }
    
    
    override func viewWillTransitionToSize(size: CGSize, withTransitionCoordinator coordinator: UIViewControllerTransitionCoordinator) {
        let transitionToWide = size.width > size.height
        if transitionToWide {
            applyConstraintsForLandscape()
        } else {
            applyConstraintsForPortrait()
        }
        
    }
}