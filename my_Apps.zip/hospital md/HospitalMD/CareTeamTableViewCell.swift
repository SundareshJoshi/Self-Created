//
//  CareTeamTableViewCell.swift
//  HospitalMD
//
//  Created by Saurav on 21/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit
import HealthCareData

@objc protocol ContactStaffDelegate {
    /**
    Called When user taps the call button of Care Team Cell
    
    :param: indexpath - User tapped at IndexPath
    */
    func didTapCallButtonAtIndexPath(indexpath: NSIndexPath)
    
    /**
    Called When user taps the Message button of Care Team Cell
    
    :param: indexpath - User tapped at IndexPath
    */
    func didTapMessageButtonAtIndexPath(indexpath: NSIndexPath)
}

//This class is derived from UITableViewCell and contains care team collectionView
class CareTeamTableViewCell: UITableViewCell, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    //MARK:- Private Variale
    private let kCollectionViewCell = "careTeamCell"
    private let kExpnadableCollectionViewCell = "expandableCell"
    private var selectedCellIndex = -1
    
    weak var tapDelegate: ContactStaffDelegate?
    var patientInfo : Patient2?
    var careTeamList : [StaffMember2] = []
    var patientDetailView : HeaderView?
    
    //MARK:- IBOutlet
    @IBOutlet weak var careTeamCollectionView: UICollectionView!
    @IBOutlet weak var headerView: UIView! {
        didSet {
            let nib:NSArray = NSBundle.mainBundle().loadNibNamed(HEADER_DISCHARGEVIEW, owner: self, options: nil)
            let width  = self.headerView?.frame.size.width
            let height  = self.headerView?.frame.size.height
            patientDetailView = nib.objectAtIndex(0) as? HeaderView
            patientDetailView?.frame = CGRectMake(0.0, 0.0,width!,height!)
            
            self.headerView!.addSubview(patientDetailView!)
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        careTeamCollectionView.registerNib(UINib(nibName: "CareTeamCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: kCollectionViewCell)
        careTeamCollectionView.registerNib(UINib(nibName: "ExpandableCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: kExpnadableCollectionViewCell)
        
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
        layout.scrollDirection = UICollectionViewScrollDirection.Horizontal
        careTeamCollectionView.collectionViewLayout = layout
        
        
    }
    
    //MARK: - HookUp
    //Get Care Team Data from JSON
    func getCareTeamDataForIds(selectedpatient: Patient2!) {
        selectedCellIndex = -1
        
        //First get all Care Team List
        if let patient = selectedpatient {
            let careTeamArray = patient.recoveryPath.careTeam.allObjects as! [StaffMember2]
            self.careTeamList = careTeamArray
        }
        dispatch_async(dispatch_get_main_queue(), {
            self.careTeamCollectionView.reloadData()
        })
    }
    
    //MARK:- UICollectionVIewDataSource
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return careTeamList.count
    }
    
    // The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        
        let careTeamMember = careTeamList[indexPath.row]
        if selectedCellIndex == indexPath.row {
            let cellExpand = collectionView.dequeueReusableCellWithReuseIdentifier(kExpnadableCollectionViewCell, forIndexPath: indexPath) as! ExpandableCollectionViewCell
            cellExpand.configureCellForCareTeamMember(careTeamMember)
            self.addGestureForViewForCell(cellExpand)
            
            return cellExpand
        }
        
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier(kCollectionViewCell, forIndexPath: indexPath) as! CareTeamCollectionViewCell
        
        cell.configureCellForCareTeamMember(careTeamMember)
        
        return cell
    }
    
    //MARK: UICollectionViewDelegate
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        
        let previousSelectedIndex = selectedCellIndex
        
        //Reload newly selected cell
        let selectedCell = careTeamCollectionView.cellForItemAtIndexPath(indexPath)
        
        if let cell = selectedCell {
            if (cell.isKindOfClass(CareTeamCollectionViewCell)) {
                selectedCellIndex = indexPath.row
            }
            else {
                selectedCellIndex = -NUMBER_ONE
            }
            //Reload previous open Cell
            if previousSelectedIndex > -NUMBER_ONE {
                UIView.performWithoutAnimation {
                    collectionView.reloadItemsAtIndexPaths([NSIndexPath(forRow: previousSelectedIndex, inSection: 0)])
                }
            }
            UIView.performWithoutAnimation {
                collectionView.reloadItemsAtIndexPaths([indexPath])
            }
            collectionView.scrollToItemAtIndexPath(indexPath, atScrollPosition: UICollectionViewScrollPosition.CenteredHorizontally, animated: true)
        }
    }
    
    // MARK: - UICollectionViewFlowLayout
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
        
        return selectedCellIndex == indexPath.row ? CGSizeMake(250, 121) : CGSizeMake(112, 121)
    }
    
    //Add Tap gesture for Call and Message View
    func addGestureForViewForCell(cell: ExpandableCollectionViewCell) {
        
        let callTapGesture = UITapGestureRecognizer(target: self, action:"tapGesture:")
        
        cell.bringSubviewToFront(cell.callView)
        cell.callView.addGestureRecognizer(callTapGesture)
        
        let messageTapGesture = UITapGestureRecognizer(target: self, action:"tapGesture:")
        
        cell.bringSubviewToFront(cell.messageView)
        cell.messageView.addGestureRecognizer(messageTapGesture)
    }
    
    //MARK: - Gesture Action
    
    func tapGesture(tapGesture: UITapGestureRecognizer) {
        
        if self.tapDelegate != nil {
            self.tapDelegate?.didTapCallButtonAtIndexPath(NSIndexPath(forRow: 0, inSection: 0))
        }
    }
}
