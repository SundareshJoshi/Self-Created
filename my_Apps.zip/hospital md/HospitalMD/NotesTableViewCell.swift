//
//  NotesTableViewCell.swift
//  HospitalMD
//
//  Created by Saurav on 21/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit

//This class is dervied from UITableViewCell and is used to display any pre-entered notes for a patient by Nurse
class NotesTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }    
}
