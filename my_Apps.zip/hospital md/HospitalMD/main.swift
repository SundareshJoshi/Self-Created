//
//  main.swift
//  CarCare
//
//  Created by Sundaresh Joshi on 5/5/15.
//  Copyright (c) 2015 ibm. All rights reserved.
//
import Foundation
import UIKit

//setting the UIApplicationMain
UIApplicationMain(Process.argc, Process.unsafeArgv, NSStringFromClass(Timer),  NSStringFromClass(AppDelegate)!)
