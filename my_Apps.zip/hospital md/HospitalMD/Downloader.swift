//
//  Downloader.swift
//  ShiftHandover
//
//  Created by John Martino on 2015-04-08.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import Foundation
import HealthCareData

typealias DownloaderServiceHandler = (error:NSError?)->Void
typealias OperationBlock = ()->Void

@objc protocol Downloader {
    func downloadPatientForPatientID(patientId: String, handler: DownloaderServiceHandler)
    func downloadPatientInfoForPatientID(patientId: String, handler: DownloaderServiceHandler)
    func downloadPatientsForUserID(userId: String, handler: DownloaderServiceHandler)
}

@objc class DownloaderService: Downloader {
    private let queue = NSOperationQueue()
    private var outstandingOperationCount = 0
    private var isCancelling = false
    
    init() {
        queue.maxConcurrentOperationCount = 1
    }
    
    private func handleDownloadCompletedWithError(error: NSError?, handler: DownloaderServiceHandler) {
        outstandingOperationCount--
        
        if error != nil {
            queue.cancelAllOperations()
            if !isCancelling {
                handler(error: error)
                outstandingOperationCount = -1
            }
            isCancelling = true
        }
        else if outstandingOperationCount == 0 {
            handler(error: nil)
        }
    }
    
    func downloadPatientForPatientID(patientId: String, handler: DownloaderServiceHandler) {
        isCancelling = false
        
        var operations = [OperationBlock]()
            
        operations.append({ ()->Void in
            Patient2Store.downloadPatient(patientId) { (patient:Patient2?, error: NSError?) -> Void in
                if error == nil && patient != nil {
                    lookupService(ModelService)?.patient = patient
                    self.handleDownloadCompletedWithError(nil, handler: handler)
                } else {
                    self.handleDownloadCompletedWithError(error, handler: handler)
                }
            }
        })
        
        outstandingOperationCount = operations.count

        for operation in operations {
            queue.addOperationWithBlock(operation)
        }

    }
    
    
    func downloadPatientInfoForPatientID(patientId: String, handler: DownloaderServiceHandler) {
        isCancelling = false
        var operations = [OperationBlock]()
        
        if let patient = lookupService(ModelService)?.patient {
            operations.append({ ()->Void in
                InformationBooklets2Store.downloadInformationBooklets(forPatient:patient) { (booklets:[InformationBooklet2]?, error: NSError?) -> Void in
                    if error == nil {
                        lookupService(ModelService)?.informationBooklets = booklets
                        self.handleDownloadCompletedWithError(nil, handler: handler)
                        
                    } else {
                        self.handleDownloadCompletedWithError(error, handler: handler)
                    }
                }
            })
            
            operations.append({ ()->Void in
                StaffMember2Store.downloadStaffMembers(forPatient:patient) { (staffMembers:[StaffMember2]?, error: NSError?) -> Void in
                    if error == nil {
                        var staffs = [String:StaffMember2]()
                        if staffMembers != nil {
                            for staff in staffMembers! {
                                staffs[staff.staffId] = staff
                            }
                        }
                        
                        lookupService(ModelService)?.staffMembers = staffs
                        self.handleDownloadCompletedWithError(nil, handler: handler)
                    } else {
                        self.handleDownloadCompletedWithError(error, handler: handler)
                    }
                }
            })
            
            outstandingOperationCount = operations.count
            
            for operation in operations {
                queue.addOperationWithBlock(operation)
            }
        } else {
            self.handleDownloadCompletedWithError(NSError(domain: "HospitalPatient", code: -1, userInfo: nil), handler: handler)
        }
    }
    
    func downloadPatientsForUserID(userId: String, handler: DownloaderServiceHandler) {
        isCancelling = false
        
        var operations = [OperationBlock]()
        
        operations.append({ ()->Void in
            Patient2Store.downloadPatientsForUserId(userId, completionHandler: { (patients, error) -> Void in
                if error == nil && patients != nil {
                    lookupService(ModelService)?.patients = patients
                    self.handleDownloadCompletedWithError(nil, handler: handler)
                } else {
                    self.handleDownloadCompletedWithError(error, handler: handler)
                }
            })
        })
        
        outstandingOperationCount = operations.count
        
        for operation in operations {
            queue.addOperationWithBlock(operation)
        }
        
    }
}
