//
//  DataSource.swift
//  HospitalMD
//
//  Created by Saurav on 18/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import Foundation
class DataSource {
    
    struct Static {
        static let SETTING_KEY = "local_data_preference"
    }
    
    
    class func isLocal() -> Bool {
        return NSUserDefaults.standardUserDefaults().boolForKey(Static.SETTING_KEY)
    }
    
    //MARK: Private Method
    private class func fileData(#fileUrl: String) -> NSData? {
        if let url = NSURL(string: fileUrl) {
            let file = url.lastPathComponent
            if file == nil {
                MFLog("Cannot construct local file name for: \(url)")
                return nil
            }
            
            let parent = url.URLByDeletingLastPathComponent
            if parent == nil {
                MFLog("Cannot construct local file name for: \(url)")
                return nil
            }
            let folder = parent!.lastPathComponent
            if folder == nil {
                MFLog("Cannot construct local file name for: \(url)")
                return nil
            }
            
            let fileName = "\(folder!)_\(file!)"
            
            return fileData(fileName: fileName)
        }
        else {
            MFLog("Cannot construct URL from: \(fileUrl)")
            return nil
        }
    }
    
    
    private class func fileData(#fileName: String) -> NSData? {
        if let imageData = DataUtil.dataFromFile(fileName) {
            return imageData
        }
        else {
            MFLog("Local image not found: \(fileName)")
            return nil
        }
    }
    
    
    private class func error(data: ResponseData) -> String {
        if let e = data.error {
            return e.localizedDescription
        }
        else {
            return "Network error"
        }
    }
    
    /**
    This will parse the JSON and return the result either as Dictionary or nil
    
    :param: name - FileName
    :returns: JSON raw data converted to Dictionary or nil
    
    */
    private class func localData(name: String) -> [NSDictionary]? {
        let (data, error) = DataUtil.jsonArrayFromFile(name)
        if let e = error {
            MFLog(e)
            return nil
        }
        if let d = data {
            return d
        }
        else {
            MFLog("Error loading local data")
            return nil
        }
        
    }
    
    //MARK: API's
    class func login(userId: String, pwd: String, callback: (NSDictionary?)->Void) {
        if isLocal() {
            MFLog("local login", level: 1)
            if let users = localData("users") {
                for user in users {
                    if let userId1 = user["userId"] as? String {
                        if let pwd1 = user["password"] as? String {
                            if(userId1 == userId && pwd1 == pwd) {
                                callback(user)
                                return
                            }
                        }
                    }
                }
            }
            callback(nil)
        }
        else {
            MFLog("server login", level: 1)
        }
    }
    
}