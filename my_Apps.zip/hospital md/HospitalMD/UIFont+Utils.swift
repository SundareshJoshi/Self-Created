//
//  UIFont+Utils.swift
//  HospitalMD
//
//  Created by Das on 19/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit

extension UIFont {
    
    class func NOTES_TEXT_FONT() -> UIFont {return UIFont.systemFontOfSize(14) }
    class func ALERT_TEXT_FONT() -> UIFont {return UIFont.systemFontOfSize(14) }
    class func ALERT_HEADER_FONT() -> UIFont {return UIFont.systemFontOfSize(14) }
    class func NOTES_HEADER_FONT() -> UIFont {return UIFont.systemFontOfSize(14) }
    
    class func NOTES_DATE_FONT() -> UIFont {return UIFont.systemFontOfSize(12) }
    
    class func VIEWTESTRESULT_FONT() -> UIFont {return UIFont.systemFontOfSize(17) }
    class func HELVETICANEUE_THIN(size:CGFloat) -> UIFont {return UIFont(name: HELVETICA_NEUE_THIN, size: size)! }
    class func HELVETICANEUE_REGULAR(size:CGFloat) -> UIFont {return UIFont(name: HELVETICA_NEUE, size: size)! }
    class func HELVETICANEUE_MEDIUM(size:CGFloat) -> UIFont {return UIFont(name: HELVETICA_MEDIUM, size: size)! }
    
    class func HELVETICA_NEUE_REGULAR_14() -> UIFont { return UIFont(name: HELVETICA_NEUE, size: 14.0)! }
    class func HELVETICA_NEUE_MEDIUM_14() -> UIFont { return UIFont(name: HELVETICA_MEDIUM_LARGE, size: 14.0)! }
    
    class func HELVETICA_NEUE_BOLD_15() -> UIFont { return UIFont(name: HELVETICA_NEUE_BOLD, size: 15.0)! }
    
    class func HELVETICA_NEUE_REGULAR_16() -> UIFont { return UIFont(name: HELVETICA_NEUE, size: 16.0)! }
    class func CUSTOM_FONT(cutomFontName: String, customFontSize: CGFloat) -> UIFont{ return UIFont(name: cutomFontName, size: customFontSize)!
    }
}
