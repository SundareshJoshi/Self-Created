//
//  AlertViewController.swift
//  HospitalMD
//
//  Created by kamruddin on 5/28/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit
import MFNetworking
import HealthCareData

//Controller for alerts
class AlertViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    //MARK:- IBOutlets
    @IBOutlet weak var alertTableView: UITableView!
    
    //MARK:- Variables
    var patientAlertList: [Alert2] = []
    var patientList: [Patient2] = []
    
    //MARK:- View lifecycle method
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.alertTableView.separatorStyle = UITableViewCellSeparatorStyle.None
        //To register the cell from xib
        self.alertTableView.registerNib(UINib(nibName: XIB_ALERTLISTCELL, bundle: nil),forCellReuseIdentifier: CELLIDENTIFIER_ALERTLSIT)
        self.alertTableView.tableFooterView = UIView(frame: CGRectZero)
        self.automaticallyAdjustsScrollViewInsets = false
        
        //TODO Need to check for response
        self.patientAlertService()
    }
    
    //MARK: - Private Methods
    /**
    Retrive data from database and initialize it in the controller
    */
    private func patientAlertService() {
        if let patients = lookupService(ModelService)?.patients {
            self.patientList = patients
            for patient in patients {
                var alertList = patient.alerts.allObjects as! [Alert2]
                let firstAlert = alertList[0] as Alert2
                self.patientAlertList.append(firstAlert)
            }
            self.alertTableView.reloadData()
        }
    }
    
    //MARK: - UITableViewDataSource
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.patientAlertList.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let alertListCell = tableView.dequeueReusableCellWithIdentifier(CELLIDENTIFIER_ALERTLSIT, forIndexPath: indexPath) as! AlertListCell
        //TODO need to check for response data
        alertListCell.sepratorView.backgroundColor = tableView.separatorColor
        if(self.patientAlertList.count > 0) {
            let alertData = self.patientAlertList[indexPath.row] as Alert2
            var name = self.patientList[indexPath.row].patientFullName
            var bedNumber = self.patientList[indexPath.row].bed.bedNumber
            alertListCell.configureCellData(alertData.longDesc, subTitle: name!, patientBedNumber: bedNumber )
        }
        return alertListCell
    }
    
    //MARK: - UITableViewDelegate
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 70
    }
    
    //MARK: - Done Button action
    @IBAction func disMissAlertView(sender: UIBarButtonItem) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
}
