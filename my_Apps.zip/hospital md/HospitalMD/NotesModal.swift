//
//  NotesModal.swift
//  HospitalMD
//
//  Created by Das on 19/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import Foundation
import MFNetworking

// Modal class for Notes
class NotesModal: Printable {
    
    //MARK:- Variables
    var notesText = ""
    var name = ""
    var date = ""
    var created : NSDate?
    var lastModified : NSDate?
    var dictionary: Dictionary<String, AnyObject> = [:]
    var number : NSNumber?

    init() {
        self.notesText = ""
        self.name = ""
        self.date = ""
    }
    //MARK:- Initialization Method
    convenience init(notes: String, name: String, date:String, actualDate:NSDate?) {
        self.init()
        self.notesText = notes
        self.name = name
        self.date = date
        self.created = actualDate
        self.lastModified = actualDate
    }
    
    //MARK: - Initialize modal data
    init(json: JSON) {
        self.notesText = json["notes"].stringValue
        self.name = json["name"].stringValue
        let responseDateStr = json["date"].stringValue
        
        if let responseDate = NSDate.convertToDate(fromString: responseDateStr, strFormatter: DATEFORMATTER_NOTESWEBSERVICE)
        {
            self.created = responseDate
            self.lastModified = responseDate

            self.date = NSDate.convertToStringWithOrdinalFormat(fromDate: responseDate, strFormatter: DATEFORMATTER_NOTESDATA_ORDINAL)
        }
    }

    var description: String {
        return "Notes Model Class"
    }
}