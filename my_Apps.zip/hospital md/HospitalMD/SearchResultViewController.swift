//
//  SearchResultViewController.swift
//  HospitalMD
//
//  Created by Raja Pratap Singh on 26/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit

//Search patient controller
class SearchResultViewController: SearchPatientViewController, UISearchResultsUpdating {
    
    // MARK: - UISearchResultsUpdating
    func updateSearchResultsForSearchController(searchController: UISearchController) {
        // updateSearchResultsForSearchController(_:) is called when the controller is being dismissed to allow those who are using the controller they are search as the results controller a chance to reset their state. No need to update anything if we're being dismissed.
        if !searchController.active {
            return
        }
        
        filterString = searchController.searchBar.text
    }
}
