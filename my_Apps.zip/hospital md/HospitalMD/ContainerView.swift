//
//  ContainerView.swift
//  HospitalPatient
//
//  Created by Saurav on 08/05/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit

@IBDesignable
class ContainerView : UIView {
    @IBInspectable var storyboardId : String?
    
    func loadStoryboard(parent:UIViewController) {
        if let id = storyboardId {
            if let vc = UIStoryboard(name: id, bundle: nil).instantiateViewControllerWithIdentifier(id) as? UIViewController {
                vc.view.frame = self.bounds
                self.addSubview(vc.view)
                parent.addChildViewController(vc)
                vc.didMoveToParentViewController(parent)
            }
        }
    }
}
