//
//  Global.swift
//  HospitalMD
//
//  Created by G Thomas on 5/17/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

let networkReachability = Reachability.reachabilityForInternetConnection()

//MARK: AlertUtils
let messageTitle = "Error"
let okButtonTitle = "OK"