//
//  AppSettings.swift
//
//  Created by G Thomas on 9/15/14.
//  Copyright (c) 2014 IBM. All rights reserved.
//

import Foundation

class AppSettings {
    
    private struct Defaults {
        static let firstLaunchKey = "AppSettings.Defaults.firstLaunchKey"
        static let localModeKey = "AppSettings.Defaults.localModeKey"
        static let remoteNameKey = "AppSettings.Defaults.remoteNameKey"
    }
    
    class var sharedInstance:AppSettings {
        struct Singleton {
            static let instance = AppSettings()
        }
        
        return Singleton.instance
    }

    var localMode: Bool {
        return NSUserDefaults.standardUserDefaults().boolForKey(Defaults.localModeKey)
    }

    var remoteName: String {
        return NSUserDefaults.standardUserDefaults().stringForKey(Defaults.remoteNameKey) ?? ""
    }
    
    func runHandlerOnFirstLaunch(firstLaunchHandler: Void -> Void) {
        // grab user defaults
        let userDefaults = NSUserDefaults.standardUserDefaults()
        
        // register the default options
        let defaultOptions: [NSObject: AnyObject] = [
            Defaults.firstLaunchKey: true,
            Defaults.localModeKey: true,
            Defaults.remoteNameKey: "APIM1"
        ]
        userDefaults.registerDefaults(defaultOptions)
        
        // check if first launch
        if userDefaults.boolForKey(Defaults.firstLaunchKey) {
            userDefaults.setBool(false, forKey: Defaults.firstLaunchKey)
            
            firstLaunchHandler()
        }
    }
    
    func setSessionTimeOutInSeconds(value: Double) {
        // check if value is positive
        if value > 0 {
            let userDefaults = NSUserDefaults.standardUserDefaults()
            userDefaults.setObject("\(value)", forKey: KEY_TIMEOUT)
            userDefaults.synchronize()
        }
    }
    func getSessionTimeOutInSeconds() -> Double {
        // grab user defaults
        let userDefaults = NSUserDefaults.standardUserDefaults()
        
        if let secs = userDefaults.objectForKey(KEY_TIMEOUT) as? NSString {
            return (secs.doubleValue)
        }else {
            setSessionTimeOutInSeconds(DEFAULT_TIMEOUT)
            let secs = userDefaults.objectForKey(KEY_TIMEOUT) as? NSString
            return (secs!.doubleValue)
        }
    }

}