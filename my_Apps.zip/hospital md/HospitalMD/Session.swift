//
//  Session.swift
//  ShiftHandover
//
//  Created by John Martino on 2015-04-14.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import Foundation
import MFNetworking

class Session {
    let kLastLoginKey = "lastLogin"
    let kTokenKey = "token"
    let kLastSynchronizationDateKey = "lastSynchronizationDate"
    let kLastDownloadTimeKey = "lastDownloadTime"
    let kMediaUploadUrlKey = "mediaUploadUrl"
    let kMediaDownloadUrlKey = "mediaDownloadUrl"
    let kMediaThumbnailDownloadUrlKey = "mediaThumbnailDownloadUrl"
    let kShiftIdKey = "shiftId"
    let kTeamIdKey = "teamId"
    let kShiftStartedKey = "shiftStarted"
    
    init(json: [String : JSON]) {
        lastLogin = json[kLastLoginKey]?.date
        token = json[kTokenKey]?.string
        lastSynchronizationDate = json[kLastSynchronizationDateKey]?.date
        lastDownloadTime = json[kLastDownloadTimeKey]?.date
        mediaUploadUrl = json[kMediaUploadUrlKey]?.string
        mediaDownloadUrl = json[kMediaDownloadUrlKey]?.string
        mediaThumbnailDownloadUrl = json[kMediaThumbnailDownloadUrlKey]?.string
        shiftId = json[kShiftIdKey]?.string
        teamId = json[kTeamIdKey]?.string
        shiftStarted = json[kShiftStartedKey]?.boolValue ?? false
    }
    
    init(json: NSMutableDictionary) {
        lastLogin = json[kLastLoginKey] as? NSDate
        token = json[kTokenKey] as? String
        lastSynchronizationDate = json[kLastSynchronizationDateKey] as? NSDate
        lastDownloadTime = json[kLastDownloadTimeKey] as? NSDate
        mediaUploadUrl = json[kMediaUploadUrlKey] as? String
        mediaDownloadUrl = json[kMediaDownloadUrlKey] as? String
        mediaThumbnailDownloadUrl = json[kMediaThumbnailDownloadUrlKey]?.string
        shiftId = json[kShiftIdKey] as? String
        teamId = json[kTeamIdKey] as? String
        shiftStarted = (json[kShiftStartedKey] as? Bool) ?? false
    }
    
    var lastLogin:NSDate?
    var token:NSString?
    var lastSynchronizationDate:NSDate?
    var lastDownloadTime:NSDate?
    var mediaUploadUrl:String?
    var mediaThumbnailDownloadUrl:String?
    var mediaDownloadUrl:String?
    var shiftId:String!
    var teamId:String!
    var shiftStarted:Bool
    
    var json: [String : AnyObject] {
        var dict = [String : AnyObject]()
        
        if let value = lastLogin {
            dict[kLastLoginKey] = value
        }
        if let value = token {
            dict[kTokenKey] = value
        }
        if let value = lastSynchronizationDate {
            dict[kLastSynchronizationDateKey] = value
        }
        if let value = lastDownloadTime {
            dict[kLastDownloadTimeKey] = value
        }
        if let value = mediaThumbnailDownloadUrl {
            dict[kMediaThumbnailDownloadUrlKey] = value
        }
        if let value = mediaUploadUrl {
            dict[kMediaUploadUrlKey] = value
        }
        if let value = mediaDownloadUrl {
            dict[kMediaDownloadUrlKey] = value
        }
        dict[kShiftIdKey] = shiftId
        dict[kTeamIdKey] = teamId
        dict[kShiftStartedKey] = shiftStarted
        
        return dict
    }
}