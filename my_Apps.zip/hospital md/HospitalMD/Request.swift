//
//  Request.swift
//
//  Created by Jeremy Koch on 12/9/14.
//  Copyright (c) 2014 IBM. All rights reserved.
//

import Foundation
import MFNetworking

enum Request: DataSourceRequest {
    
    typealias MethodAndPath = (method: String, path: String)
    
    typealias Username = String
    typealias Password = String

    case Authentication(Username, Password)
    case DischargeCheckList()
    
    case PatientList()
    case CareTeam()
    case Notes()
    case AlertData()
    case PatientAlertList()

    func execute() -> MFNetworking.Request {
        return DataSourceManager.request(self)
    }
    
    // MARK: - Data source request
    
    func responseForURLRequest(urlRequest: NSURLRequest) -> MFNetworking.Response {
        // create the empty 200 response
        let response = MFNetworking.Response()
        
        // load the response body
        switch self {
        case .Authentication:
            return response.withBodyFromResource("authentication", type: "json")
        case .DischargeCheckList:
            return response.withBodyFromResource("DischargeChecklist", type: "json")
        case .PatientList:
            return response.withBodyFromResource("Patient", type: "json")
        case .CareTeam:
            return response.withBodyFromResource("careTeam", type: "json")
        case .Notes:
            return response.withBodyFromResource("315", type: "json")
        case .AlertData:
            return response.withBodyFromResource("alerts", type: "json")
        case .PatientAlertList:
            return response.withBodyFromResource("PatientAlertList", type: "json")
        default:
            return response.withStatusCode(404)
        }
    }
    
    func urlRequestWithBaseURLString(baseURLString: String?) -> NSURLRequest {
        // Grab the method and path
        let methodAndPath = self.methodAndPath
        
        // Build the URL request
        let url = NSURL(string: (baseURLString ?? "") + methodAndPath.path)!
        let urlRequest = NSMutableURLRequest(URL: url)
        urlRequest.HTTPMethod = methodAndPath.method
        
        // Implement only if you need to add post body parameter
        switch self {
        case .Authentication(let username, let password):
            return ParameterEncoding.JSON.encodeRequest(urlRequest, parameters: ["username": username, "password": password])
        case .DischargeCheckList():
            return ParameterEncoding.JSON.encodeRequest(urlRequest, parameters: ["username": "", "password": ""])
        default:
            return urlRequest
        }
    }

    // MARK: - Private 
    
    private func pathForServiceName(serviceName: String) -> String {
        return DataSourceManager.pathForServiceName(serviceName)
    }
    
    private var methodAndPath: MethodAndPath {
        switch self {
        case .Authentication:
            return ("POST", pathForServiceName("Authenticate"))
        case .DischargeCheckList:
            return ("POST", pathForServiceName("DischargeCheckList"))
        case .Notes:
            return ("POST", pathForServiceName("Notes"))
        case .PatientList:
            return ("POST", pathForServiceName("Patient"))
        case .CareTeam:
            return ("POST", pathForServiceName("CareTeam"))
        case .AlertData:
            return ("POST", pathForServiceName("AlertData"))
        case .PatientAlertList:
            return ("POST", pathForServiceName("PatientAlertList"))
        default:
                return("POST", pathForServiceName("default"))
            
        }
    }
}
