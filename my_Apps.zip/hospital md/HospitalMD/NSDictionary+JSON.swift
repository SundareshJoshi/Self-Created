//
//  NSDictionary+JSON.swift
//  ShiftHandover
//
//  Created by Mike Wang on 2015-04-14.
//  Copyright (c) 2015 IBM. All rights reserved.
//


extension NSDictionary {
    
    func jsonString()->String? {
        
        var stringBody:String?
        
        var err : NSError?
        let data = NSJSONSerialization.dataWithJSONObject(self, options: nil, error: &err)
        if let data = data {
            stringBody = NSString(data:data, encoding:NSUTF8StringEncoding) as? String
        }
        return stringBody
    }
}