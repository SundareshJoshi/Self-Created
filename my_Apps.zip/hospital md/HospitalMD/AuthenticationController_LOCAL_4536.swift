//
//  AuthenticationController.swift
//
//  Created by Jeremy Koch on 9/24/14.
//  Copyright (c) 2014 IBM. All rights reserved.
//

import UIKit
import MFLogin
import MFNetworking

extension UIViewController {
    var authenticationController: AuthenticationController? {
        return (UIApplication.sharedApplication().delegate as! AppDelegate).authenticationController
    }
}

class AuthenticationController: UIViewController, LoginViewControllerDelegate {
    
    private var loginViewController: LoginViewController!
    private var securedRootViewController: UIViewController!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.loadAuthorizationController()
    }
    
    // MARK: - Sign out action
    
    func signOut() {
        flipFromViewController(securedRootViewController, toController: loginViewController, options: UIViewAnimationOptions.TransitionNone)
        self.securedRootViewController = nil
    }

    // MARK: - Private setup and management
    
    private func loadAuthorizationController() {

        // load the app name
        let displayName = NSBundle.mainBundle().infoDictionary?["CFBundleDisplayName"] as? String ?? ""
        
        // create the login controller
        self.loginViewController = LoginViewController.defaultController()
        self.loginViewController.delegate = self
        self.loginViewController.passwordRequired = false
        self.loginViewController.headingText = displayName
        self.loginViewController.enableTouchID = true
        
        // for demo purpose
        self.loginViewController.defaultUserID = "jkoch"
        self.loginViewController.defaultPassword = "mobilefirst"
        
        // updates the footer text
        self.update()
        
        // add login as child view controller
        self.addChildViewController(loginViewController)
        view.addSubview(loginViewController.view)
        loginViewController.didMoveToParentViewController(self)
    }
    
    private func flipFromViewController(fromController: UIViewController, toController: UIViewController, options: UIViewAnimationOptions) {
        toController.view.frame = fromController.view.bounds
        self.addChildViewController(toController)
        fromController.willMoveToParentViewController(nil)
        
        self.transitionFromViewController(fromController, toViewController: toController, duration: 0.2, options: options, animations: {}) { (finished) -> Void in
            fromController.removeFromParentViewController()
            toController.didMoveToParentViewController(self)
        }
    }
    
    func update() {
        let appVersion = NSBundle.mainBundle().infoDictionary?["CFBundleShortVersionString"] as? String ?? ""
        let envMode = AppSettings.sharedInstance.localMode ? "LOCAL" : AppSettings.sharedInstance.remoteName
        self.loginViewController.footerText = "\(appVersion) (\(envMode))"
    }
    
    // MARK: - Login response handling
    
    private func loginSuccessfulWithAuthorizationToken(authToken: String) {
        // store the auth token
        DataSourceManager.addHeaderWithName("Authorization", value: authToken)
        
        // create the root view controller
        
        let notes = UIStoryboard(name: "Notes", bundle: nil).instantiateViewControllerWithIdentifier("NotesViewController") as! UIViewController
        self.securedRootViewController = notes
        
        // perform any additional service request or just load the main view controller
        flipFromViewController(self.loginViewController, toController: self.securedRootViewController, options: UIViewAnimationOptions.TransitionCrossDissolve)
    }
    
    private func loginFailedWithError(error: NSError) {
        // create the error message
        var message: String
        if error.code == 401 {
            message = NSLocalizedString("Your username or password is incorrect.", comment: "Incorrect username/password")
        } else {
            message = NSLocalizedString("Network Error", comment: "Network Error")
        }
        
        // show the alert
        var alert = UIAlertController(title: message, message: "", preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: false, completion: nil)
    }
    
    // MARK: - Login delegate
    
    func loginViewController(loginViewController: LoginViewController, didLoginWithUsername username: String, password: String, completionHandler: (Bool) -> Void) {
        
        // authenticate with the server
        Request.Authentication(username, password).execute().validate().responseJSON { (_, _, json, error) -> Void in
            if let error = error {
                // inform login controller the login is unsuccessfully complete
                completionHandler(false)
                self.loginFailedWithError(error)
            } else {
                // inform login controller the login is successfully complete
                completionHandler(true)
                let authToken = Response.authenticationTokenFromJSON(json)
                self.loginSuccessfulWithAuthorizationToken(authToken)
            }
        }
    }
    
    func loginViewController(loginViewController: LoginViewController, didLoginUsingTouchWithCompletionHandler completionHandler: (Bool) -> Void) {
        // inform login controller the login is successfully complete
        completionHandler(true)
        
        // Up to the app to do something interesting since login occurred with Touch ID, but we'll just fake success with a placeholder token
        self.loginSuccessfulWithAuthorizationToken("TOUCHID")
    }
}

