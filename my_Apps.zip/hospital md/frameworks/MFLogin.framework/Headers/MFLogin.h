//
//  MFLogin.h
//  MFLogin
//
//  Created by Ian Craigmile on 9/12/2014.
//  Copyright (c) 2014 IBM Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MFLogin.
FOUNDATION_EXPORT double MFLoginVersionNumber;

//! Project version string for MFLogin.
FOUNDATION_EXPORT const unsigned char MFLoginVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MFLogin/PublicHeader.h>


