//
//  MFNetworking.h
//  MFNetworking
//
//  Created by Jeremy Koch on 12/15/14.
//  Copyright (c) 2014 IBM. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MFNetworking.
FOUNDATION_EXPORT double MFNetworkingVersionNumber;

//! Project version string for MFNetworking.
FOUNDATION_EXPORT const unsigned char MFNetworkingVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MFNetworking/PublicHeader.h>


