//
//  HealthCareData.h
//  HealthCareData
//
//  Created by Paul Castro on 3/6/15.
//  Copyright (c) 2015 IBM. All rights reserved.//

#import <UIKit/UIKit.h>

//! Project version number for HealthCareData.
FOUNDATION_EXPORT double HealthCareDataVersionNumber;

//! Project version string for HealthCareData.
FOUNDATION_EXPORT const unsigned char HealthCareDataVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HealthCareData/PublicHeader.h>


