//
//  OfflineSupportTests.swift
//  HospitalMD
//
//  Created by Sundaresh Joshi on 5/27/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//


import UIKit
import XCTest

class OfflineSupportTests: XCTestCase{
    
    func testReachability() {
        if networkReachability.isReachable() {
            XCTAssertTrue(networkReachability.currentReachabilityStatus != .NotReachable, "Reachability is not working properly")
        }
    }
}
