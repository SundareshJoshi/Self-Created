//
//  SessionManagementTests.swift
//  HospitalMD
//
//  Created by Sundaresh Joshi on 5/19/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit
import XCTest

class SessionManagementTests: XCTestCase {
    
    // check if setSessionTimeOutInSeconds() is working
    func testSessionTimer() {
        let sharedInstance = AppSettings.sharedInstance
        sharedInstance.setSessionTimeOutInSeconds(5.0)
        let idleSecs = sharedInstance.getSessionTimeOutInSeconds()
        XCTAssertTrue(idleSecs == 5.0, "Session Time out is not being set properly")
    }
    
}

