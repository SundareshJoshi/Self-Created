//
//  AutoSignOutViewControllerTests.swift
//  HospitalPatient
//
//  Created by Sundaresh Joshi on 5/11/15.
//  Copyright (c) 2015 IBM. All rights reserved.
//

import UIKit
import XCTest

class AutoSignOutViewControllerTests: XCTestCase {
    
    func testAutoSignOutControllerActions() {
        // creating an instance of AutoSignOutViewController
        let storyboard:UIStoryboard = UIStoryboard(name: "AutoSignOut", bundle: NSBundle(forClass: self.dynamicType))
        let autoSignOutVC = storyboard.instantiateViewControllerWithIdentifier("AutoSignOutViewController") as! AutoSignOutViewController
        
        // Load the view
        autoSignOutVC.loadView()
        
        // checking whether the timeOut message is nil
        XCTAssertNotNil(autoSignOutVC.timeOutMessage.text, "timeOut Message should not be nil")
        
        // checking whether the target action is signInClicked for signIn button
        XCTAssertTrue(autoSignOutVC.respondsToSelector("signInClicked:"), "signInClicked: selector must be present for action")
        var arr : NSArray = autoSignOutVC.signIn.actionsForTarget(autoSignOutVC, forControlEvent: .TouchUpInside)!
        XCTAssertTrue(arr.containsObject("signInClicked:"), "signIn button is not connected to signInClicked IBAction")
    }
}
