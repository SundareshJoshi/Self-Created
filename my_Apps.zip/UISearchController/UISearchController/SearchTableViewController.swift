//
//  SearchTableViewController.swift
//  UISearchController
//
//  Created by Sundaresh Joshi on 9/4/15.
//  Copyright (c) 2015 Sundaresh Joshi. All rights reserved.
//

import UIKit

class SearchTableViewController: UITableViewController, UISearchResultsUpdating {

    let appleProducts = ["Mac", "iPhone", "iPad", "iWatch"]
    var filteredAppleProducts = [String]()
    var searchResultsController = UISearchController()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        searchResultsController = UISearchController(searchResultsController: nil)
        searchResultsController.searchResultsUpdater = self

        searchResultsController.dimsBackgroundDuringPresentation = false
        searchResultsController.searchBar.sizeToFit()
        self.tableView.tableHeaderView = searchResultsController.searchBar
        self.tableView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searchResultsController.active {
            return filteredAppleProducts.count
        }
        else {
            return appleProducts.count
        }
    }


    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath) as! UITableViewCell

        if searchResultsController.active {
            cell.textLabel?.text = filteredAppleProducts[indexPath.row]
        }
        else {
            cell.textLabel?.text = appleProducts[indexPath.row]
        }

        return cell
    }
    
    func updateSearchResultsForSearchController(searchController: UISearchController) {
        let searchPredicate = NSPredicate(format: "SELF CONTAINS[c] %@", searchController.searchBar.text)
        filteredAppleProducts = (appleProducts as NSArray).filteredArrayUsingPredicate(searchPredicate) as! [String]
        self.tableView.reloadData()
    }

    
}
