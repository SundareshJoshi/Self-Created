//
//  SecondViewController.swift
//  Delegate
//
//  Created by Joshi on 21/01/15.
//  Copyright (c) 2015 Joshi. All rights reserved.
//

import UIKit

protocol SecondViewControllerDelegate  {
    func done(someText:NSString)
}

class SecondViewController: UIViewController {

    
    var delegate: SecondViewControllerDelegate!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBOutlet weak var returnButton: UIButton!
    @IBOutlet weak var someText: UITextField!
    
    
    
    @IBAction func returnButtonPressed(sender: AnyObject) {
       self.delegate.done(someText.text)
    }
    
}
