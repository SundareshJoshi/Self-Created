//
//  ViewController.swift
//  Delegate
//
//  Created by Joshi on 21/01/15.
//  Copyright (c) 2015 Joshi. All rights reserved.
//

import UIKit

class ViewController: UIViewController, SecondViewControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBOutlet weak var userNameTextField: UITextField!
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if (segue.identifier == "segue") {
            let viewController : SecondViewController = segue.destinationViewController as SecondViewController
            viewController.delegate = self
        }
    }
    
    func done(name:NSString) {
        self.dismissViewControllerAnimated(true, completion: nil)
        userNameTextField.text = name
    }

    @IBAction func goPressed(sender: AnyObject) {
        
    }
}

