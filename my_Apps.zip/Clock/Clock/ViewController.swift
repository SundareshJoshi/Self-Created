//
//  ViewController.swift
//  Clock
//
//  Created by Joshi on 04/12/14.
//  Copyright (c) 2014 Joshi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        var localNotification:UILocalNotification = UILocalNotification()
        localNotification.alertAction = "Testing notifications on ios8"
        localNotification.alertBody = "A Mav3rlck Notification"
        localNotification.fireDate = NSDate(timeIntervalSinceNow: 30)
        UIApplication.sharedApplication().scheduleLocalNotification(localNotification)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

