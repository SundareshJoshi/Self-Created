//
//  SearchTableViewController.swift
//  UISearchController
//
//  Created by Sundaresh Joshi on 9/4/15.
//  Copyright (c) 2015 Sundaresh Joshi. All rights reserved.
//

import UIKit

class SearchTableViewController: UITableViewController, UISearchResultsUpdating {

    let appleProducts = []
    var filteredAppleProducts = [String]()
    var searchResultsController = UISearchController()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        searchResultsController = UISearchController(searchResultsController: nil)
        searchResultsController.searchResultsUpdater = self

        searchResultsController.dimsBackgroundDuringPresentation = false
        searchResultsController.searchBar.sizeToFit()
        self.tableView.tableHeaderView = searchResultsController.searchBar
        self.tableView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searchResultsController.active {
            return filteredAppleProducts.count
        }
        else {
            return appleProducts.count
        }
    }


    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath) as! UITableViewCell
        cell.textLabel?.numberOfLines = 3
        if searchResultsController.active {
            if filteredAppleProducts.count > indexPath.row {
            if !filteredAppleProducts[indexPath.row].isEmpty {
            cell.textLabel?.text = filteredAppleProducts[indexPath.row]
            }
            }
        }
        else {
            cell.textLabel?.text = appleProducts[indexPath.row] as? String
        }
        return cell
    }
    
    
    func updateSearchResultsForSearchController(searchController: UISearchController) {
        //self.filteredAppleProducts.removeAll(keepCapacity: false)
        var baseUrl = "https://maps.googleapis.com/maps/api/place/autocomplete/json?input=" + "\(searchController.searchBar.text)" + "&key=AIzaSyCPtGW55AgzX71rRk8LkZjjfZzC8Fkj7t4"
        var url = NSURL(string: baseUrl)
        var request = NSURLRequest(URL: url!)
        NSURLConnection.sendAsynchronousRequest(request, queue: NSOperationQueue.mainQueue()) { (response:NSURLResponse!, data:NSData!, error:NSError!) -> Void in
            var err: NSErrorPointer = nil
            let jsonResult: NSDictionary! = NSJSONSerialization.JSONObjectWithData(data, options:NSJSONReadingOptions.MutableContainers, error: err) as? NSDictionary
            let result = jsonResult["predictions"] as! NSArray
            var arr : [String] = [String]()
            for place in result {
                arr.append(place["description"] as! String)
            }
            self.filteredAppleProducts = arr
        }
//        let searchPredicate = NSPredicate(format: "SELF CONTAINS[c] %@", searchController.searchBar.text)
//        filteredAppleProducts = (appleProducts as NSArray).filteredArrayUsingPredicate(searchPredicate) as! [String]
        self.tableView.reloadData()
    }

    
}
